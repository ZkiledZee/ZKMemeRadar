import Foundation

struct PricePoint: Codable, Identifiable {
    var id: Double { time }
    let time: Double
    let price: Double
    let liquidity: Double
    let volume5: Double
    let buys: Int
    let sells: Int
}
struct SecurityReport: Codable {
    let source: String
    let checked: Double
    let complete: Bool
    let danger: Bool
    let risk: Double?
    let concentration: Double?
    let facts: [String: String]
    let warnings: [String]
}
struct Token: Codable, Identifiable {
    let id: String
    let chain: String
    let address: String
    let pool: String
    let name: String
    let symbol: String
    let price: Double
    let liquidity: Double
    let marketCap: Double?
    let fdv: Double?
    let created: Double?
    let volume5: Double
    let volumeHour: Double
    let buys: Int
    let sells: Int
    let change5: Double?
    let changeHour: Double?
    let fetched: Double
    let source: String
    let category: String
    let metrics: [String: Double?]
    let scores: [String: Double?]
    let security: SecurityReport
    let points: [PricePoint]
    let reasons: [String]
    let risks: [String]
    let unavailable: [String]
    let status: String
    let entryLow: Double?
    let entryHigh: Double?
    let stop: Double?
    let target1: Double?
    let target2: Double?
    let holdSeconds: Int
    let eligible: Bool
    func score(_ key: String) -> Double? { scores[key] ?? nil }
}
struct Signal: Codable, Identifiable {
    let id: String
    let token: Token
    let status: String
    let recommendation: String
    let opened: Double
    let expires: Double
    let initialExpires: Double
    let entry: Double
    let entryLow: Double
    let entryHigh: Double
    let reasons: [String]
    let stop: Double
    let target1: Double
    let target2: Double
    let confidence: Double
    let maxGain: Double
    let maxLoss: Double
    let target1Hit: Bool
    let closed: Double?
    let exit: Double?
    let closeReason: String?
    let lastGood: Double
}
struct ProviderStatus: Codable, Identifiable {
    var id: String { name }
    let name: String
    let ok: Bool
    let at: Double
}
struct RadarState: Codable {
    let serverTime: Double
    let live: Bool
    let scanned: Int
    let potential: Int
    let rejected: Int
    let active: Signal?
    let candidates: [Token]
    let pushConfigured: Bool
    let registeredDevices: Int
    let lastScan: Double?
    let providers: [ProviderStatus]
}
let disclaimer = "Signals are algorithmic market observations and not guaranteed outcomes. Meme coins are highly speculative and can rapidly lose their entire value."
func price(_ value: Double?) -> String {
    guard let v = value, v.isFinite else { return "Unavailable" }
    if v == 0 { return "$0" }
    if abs(v) < 0.0000001 { return String(format: "$%.3g", v) }
    return v.formatted(.currency(code: "USD").precision(.fractionLength(v < 0.01 ? 8 : v < 1 ? 5 : 2)))
}
func compact(_ value: Double?) -> String {
    guard let v = value else { return "Unavailable" }
    if abs(v) >= 1_000_000 { return String(format: "$%.2fM", v / 1_000_000) }
    if abs(v) >= 1000 { return String(format: "$%.1fK", v / 1000) }
    return price(v)
}
