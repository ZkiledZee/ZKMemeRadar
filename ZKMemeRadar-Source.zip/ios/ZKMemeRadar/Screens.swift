import SwiftUI
import UIKit

struct HomeView: View {
    @EnvironmentObject var model: RadarModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack {
                    VStack(alignment: .leading, spacing: 7) { Kicker(text: "Selective market intelligence"); Text("ZK MEME\nRADAR").font(.system(size: 34, weight: .bold, design: .rounded)).tracking(-1) }
                    Spacer(); Badge(text: model.fresh && model.state?.live == true ? "● LIVE" : "● OFFLINE", color: model.fresh && model.state?.live == true ? Palette.mint : .orange)
                }
                HStack(spacing: 10) {
                    Metric(title: "Scanned", value: model.state.map { String($0.scanned) } ?? "—")
                    Metric(title: "Setups", value: model.state.map { String($0.potential) } ?? "—")
                    Metric(title: "Rejected", value: model.state.map { String($0.rejected) } ?? "—")
                }.padding(.top, 8)
                RadarVisual(tokens: model.state?.candidates ?? [], active: model.state?.active?.token, live: model.fresh && model.state?.live == true).frame(height: 285)
                if let s = model.state?.active {
                    Button { model.tab = 1; model.selectedSignal = nil } label: {
                        Panel { HStack(spacing: 14) { TokenAvatar(token: s.token); VStack(alignment: .leading, spacing: 7) { Kicker(text: "Active signal · engine locked"); Text(s.token.symbol).font(.title2.bold()); Text(model.fresh ? s.recommendation : "Cached — reconnect to verify").font(.caption).foregroundStyle(Palette.mint) }; Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(Palette.mint) } }
                    }.buttonStyle(.plain)
                } else {
                    Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Patience is part of the strategy"); Text(model.connected ? "Searching for the\nexceptional setup." : "Your radar,\nready to connect.").font(.system(size: 25, weight: .semibold, design: .rounded)); Text(model.connected ? "No active signal. Candidates must pass entry, liquidity and security gates." : "Connect your cloud scanner once. It keeps monitoring independently of this phone.").font(.subheadline).foregroundStyle(Palette.muted) } }
                }
                HStack { Image(systemName: "lock.shield").foregroundStyle(Palette.mint); Text("One actionable coin at a time").font(.caption); Spacer(); Text("V1.0").font(.caption.monospaced()).foregroundStyle(Palette.muted) }
                Text("Counts show unique tokens observed in the last 6 minutes, within public-feed coverage.").font(.caption2).foregroundStyle(Palette.muted)
                Text(disclaimer).font(.caption2).foregroundStyle(Palette.muted)
            }.padding(22)
        }.background(Palette.background).refreshable { await model.refresh() }
    }
}
struct MarketView: View {
    @EnvironmentObject var model: RadarModel
    @State private var section = "Trending"
    private let sections = ["Trending", "Momentum", "New", "Volume", "Whale Activity", "Watchlist"]
    var filtered: [Token] {
        let tokens = model.state?.candidates ?? []
        switch section {
        case "Momentum": return tokens.sorted { ($0.score("Momentum") ?? 0) > ($1.score("Momentum") ?? 0) }
        case "New": return tokens.filter { $0.created != nil && model.now - $0.created! < 86400 }.sorted { ($0.created ?? 0) > ($1.created ?? 0) }
        case "Volume": return tokens.sorted { $0.volume5 > $1.volume5 }
        case "Whale Activity": return []
        case "Watchlist": return tokens.filter { model.watchlist.contains($0.id) }
        default: return tokens
        }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Market").font(.largeTitle.bold())
                Text("Discovery only. The Signal tab holds the sole actionable setup.").font(.subheadline).foregroundStyle(Palette.muted)
                ScrollView(.horizontal, showsIndicators: false) { HStack { ForEach(sections, id: \.self) { item in Button { section = item } label: { Badge(text: item, color: section == item ? Palette.mint : Palette.muted) } } } }
                if filtered.isEmpty {
                    ContentUnavailableView(section == "Whale Activity" ? "Wallet attribution unavailable" : "No candidates yet", systemImage: section == "Whale Activity" ? "eye.slash" : "dot.radiowaves.left.and.right", description: Text(section == "Whale Activity" ? "V1 does not claim whale flows from transaction counts." : "Verified observations will appear after the cloud scanner connects. Watchlist keeps only currently observed tokens here."))
                }
                ForEach(filtered) { t in
                    NavigationLink { TokenDetail(token: t) } label: {
                        Panel { HStack(spacing: 12) { TokenAvatar(token: t); VStack(alignment: .leading, spacing: 7) { Text(t.symbol).font(.headline); Text(t.chain.uppercased()).font(.caption2.monospaced()).foregroundStyle(Palette.muted) }; Spacer(); VStack(alignment: .trailing, spacing: 7) { Text(price(t.price)).font(.subheadline.monospacedDigit()); Text(t.change5.map { String(format: "%+.1f%% · 5m", $0) } ?? "5m unavailable").font(.caption).foregroundStyle((t.change5 ?? 0) >= 0 ? Palette.mint : .orange) } } }
                    }.buttonStyle(.plain)
                }
            }.padding(20)
        }.background(Palette.background)
    }
}
struct TokenDetail: View {
    let token: Token
    @EnvironmentObject var model: RadarModel
    private var t: Token { model.state?.candidates.first(where: { $0.id == token.id }) ?? token }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack { TokenAvatar(token: t); VStack(alignment: .leading) { Text(t.name).font(.title2.bold()); Text(t.symbol + " · " + t.chain.uppercased()).foregroundStyle(Palette.muted).font(.caption) }; Spacer(); Button { model.toggleWatch(t.id) } label: { Image(systemName: model.watchlist.contains(t.id) ? "star.fill" : "star").foregroundStyle(Palette.mint) }.accessibilityLabel("Toggle watchlist") }
                Badge(text: "ANALYSIS ONLY · \(t.status)", color: Palette.blue)
                Panel { VStack(alignment: .leading, spacing: 14) { Text(price(t.price)).font(.largeTitle.monospacedDigit()); PriceChart(points: t.points); Text("\(t.source) · observed \(Date(timeIntervalSince1970: t.fetched).formatted(date: .omitted, time: .standard))").font(.caption2).foregroundStyle(Palette.muted) } }
                Panel { VStack { Kicker(text: "Factor analysis"); ScoreWheel(token: t); ForEach(["Momentum", "Liquidity", "Volume", "Wallet", "Safety", "Social", "Entry Quality", "Rug Risk", "Risk", "Overall"], id: \.self) { key in HStack { Text(key).font(.caption); Spacer(); Text(t.score(key).map { String(format: "%.0f / 100", $0) } ?? "Unavailable").font(.caption.monospaced()).foregroundStyle(Palette.mint) } }; Text("Wallet score uses concentration only. Social has no contribution. These are heuristic scores, not probabilities.").font(.caption2).foregroundStyle(Palette.muted).padding(.top, 10) } }
                Panel { VStack(spacing: 20) {
                    HStack { Metric(title: "Pool liquidity", value: compact(t.liquidity)); Metric(title: "Market cap", value: compact(t.marketCap)) }
                    HStack { Metric(title: "FDV", value: compact(t.fdv)); Metric(title: "5m volume", value: compact(t.volume5)) }
                    HStack { Metric(title: "5m buy txns", value: String(t.buys)); Metric(title: "5m sell txns", value: String(t.sells)) }
                    HStack { Metric(title: "1h change", value: t.changeHour.map { String(format: "%+.1f%%", $0) } ?? "Unavailable"); Metric(title: "Pool age", value: t.created.map { "\(max(0, Int((model.now - $0)/60))) min" } ?? "Unavailable") }
                } }
                Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Observed metrics"); ForEach(t.metrics.keys.sorted(), id: \.self) { key in HStack { Text(key).font(.caption); Spacer(); Text((t.metrics[key] ?? nil).map { String(format: "%.2f", $0) } ?? "Unavailable").font(.caption.monospaced()).foregroundStyle(Palette.muted) } }; Text("Sampled observations, not tick history. Units are in each label.").font(.caption2).foregroundStyle(Palette.muted) } }
                Panel { VStack(alignment: .leading, spacing: 14) { Kicker(text: "Contract & pool"); Text(t.address).font(.caption.monospaced()).textSelection(.enabled); Text("Pool: " + t.pool).font(.caption2.monospaced()).foregroundStyle(Palette.muted).textSelection(.enabled); Button { UIPasteboard.general.string = t.address } label: { Label("Copy contract", systemImage: "doc.on.doc").font(.caption) } } }
                Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Security · \(t.security.source)"); Badge(text: t.security.complete ? "AVAILABLE CHECKS COMPLETE" : "INCOMPLETE — SIGNAL BLOCKED", color: t.security.complete ? Palette.mint : .orange); ForEach(t.security.facts.keys.sorted(), id: \.self) { key in VStack(alignment: .leading, spacing: 4) { Text(key).font(.caption).foregroundStyle(Palette.muted); Text(t.security.facts[key] ?? "Unavailable").font(.caption) } } } }
                ReasonPanel(title: "Evidence", items: t.reasons, symbol: "checkmark.circle", color: Palette.mint)
                ReasonPanel(title: "Risks", items: t.risks, symbol: "exclamationmark.triangle", color: .orange)
                ReasonPanel(title: "Unavailable data", items: t.unavailable, symbol: "minus.circle", color: Palette.muted)
            }.padding(20)
        }.background(Palette.background).navigationBarTitleDisplayMode(.inline)
    }
}
struct HistoryView: View {
    @EnvironmentObject var model: RadarModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("History").font(.largeTitle.bold())
                Text("Observed signal outcomes, not executed trades. Fees, partial exits and fills are not simulated.").font(.caption).foregroundStyle(Palette.muted)
                if model.history.isEmpty { ContentUnavailableView("A clean start", systemImage: "clock.arrow.circlepath", description: Text("Completed real signals appear here after deployment. No invented track record.")) }
                ForEach(model.history) { s in
                    NavigationLink { SignalView(signal: s) } label: {
                        Panel { VStack(alignment: .leading, spacing: 12) { HStack { Text(s.token.symbol).font(.title3.bold()); Spacer(); Text(s.exit.map { String(format: "%+.1f%%", ($0/s.entry-1)*100) } ?? "Unpriced").font(.headline.monospacedDigit()).foregroundStyle(s.exit.map { $0 >= s.entry } == true ? Palette.mint : .orange) }; Kicker(text: s.closeReason ?? "Closed"); HStack { Text(Date(timeIntervalSince1970: s.opened), style: .date); Spacer(); Text("Score \(Int(s.confidence))/100") }.font(.caption2).foregroundStyle(Palette.muted) } }
                    }.buttonStyle(.plain)
                }
            }.padding(20)
        }.background(Palette.background).task { await model.loadHistory() }.refreshable { await model.loadHistory() }
    }
}
struct SettingsView: View {
    @EnvironmentObject var model: RadarModel
    @State private var address = ""
    @State private var code = ""
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Connection").font(.largeTitle.bold())
                Panel { VStack(alignment: .leading, spacing: 16) {
                    Kicker(text: "Cloud scanner")
                    if model.connected {
                        Badge(text: model.fresh ? "CONNECTED" : "RECONNECTING", color: model.fresh ? Palette.mint : .orange)
                        Text("The cloud service keeps scanning while your phone is closed or offline.").font(.subheadline).foregroundStyle(Palette.muted)
                        Button("Disconnect this phone", role: .destructive) { Task { await model.disconnect() } }
                    } else {
                        Text("Pair once with your deployed backend. No wallet or trading account required.").font(.subheadline).foregroundStyle(Palette.muted)
                        TextField("https://radar.your-domain.com", text: $address).textContentType(.URL).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        SecureField("Server pairing code", text: $code).textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { Task { await model.pair(address: address, code: code); if model.connected { code = "" } } } label: { HStack { Spacer(); if model.loading { ProgressView() } else { Text("Connect radar").fontWeight(.semibold) }; Spacer() }.padding().background(Palette.mint, in: RoundedRectangle(cornerRadius: 14)).foregroundStyle(Palette.background) }.disabled(model.loading || code.count < 16)
                    }
                } }
                Panel { VStack(alignment: .leading, spacing: 14) {
                    Kicker(text: "Remote notifications")
                    Text(model.pushStatus).font(.headline)
                    Text(model.state?.pushConfigured == true ? "Server APNs credentials configured." : "Server APNs credentials are not configured yet.").font(.caption).foregroundStyle(Palette.muted)
                    Text("Apple push-enabled signing is required. Free sideload signing does not supply the APNs entitlement. Delivery also depends on iOS notification permissions and connectivity.").font(.caption).foregroundStyle(Palette.muted)
                    Button("Enable notifications") { Task { await model.enablePush() } }.disabled(!model.connected)
                    Button("Open iPhone settings") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }.font(.caption)
                } }
                if let state = model.state {
                    Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Provider health"); ForEach(state.providers) { p in HStack { Text(p.name).font(.caption); Spacer(); Circle().fill(p.ok ? Palette.mint : .orange).frame(width: 7, height: 7) } }; Text("Public APIs may be delayed or rate-limited. Missing critical evidence blocks new signals.").font(.caption2).foregroundStyle(Palette.muted) } }
                }
                Text(disclaimer).font(.caption).foregroundStyle(Palette.muted)
                Text("Market data: DEX Screener & GeckoTerminal. Security: GoPlus & Solana RPC. No analytics SDKs. Your server stores the device push token and observed signals; the app caches recent observations locally.").font(.caption2).foregroundStyle(Palette.muted)
            }.padding(20)
        }.background(Palette.background)
    }
}
