import SwiftUI
import UIKit

struct MarketView: View {
    @EnvironmentObject var model: RadarModel
    @State private var section = "Trending"
    @State private var search = ""
    @State private var chain = "All chains"
    private let sections = ["Trending", "Momentum", "New", "Volume", "Whale Activity", "Watchlist"]
    var filtered: [Token] {
        let tokens = (model.state?.candidates ?? []).filter { (chain == "All chains" || $0.chain == chain) && (search.isEmpty || $0.symbol.localizedCaseInsensitiveContains(search) || $0.name.localizedCaseInsensitiveContains(search) || $0.address.localizedCaseInsensitiveContains(search)) }
        switch section {
        case "Momentum": return tokens.sorted { ($0.score("Momentum") ?? 0) > ($1.score("Momentum") ?? 0) }
        case "New": return tokens.filter { $0.created != nil && model.now - $0.created! < 86400 }.sorted { ($0.created ?? 0) > ($1.created ?? 0) }
        case "Volume": return tokens.sorted { $0.volume5 > $1.volume5 }
        case "Whale Activity": return []
        case "Watchlist": return tokens.filter { model.watchlist.contains($0.id) }
        default: return tokens
        }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Market").font(.largeTitle.bold())
                Text("Discovery only. The Signal tab holds the sole actionable setup.").font(.subheadline).foregroundStyle(Palette.muted)
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(Palette.muted)
                    TextField("Search token or contract", text: $search).textInputAutocapitalization(.never).autocorrectionDisabled().font(.subheadline)
                    Menu { ForEach(["All chains", "solana", "base", "ethereum", "bsc"], id: \.self) { item in Button(item.uppercased()) { chain = item } } } label: { Image(systemName: "line.3.horizontal.decrease.circle").foregroundStyle(Palette.mint) }
                }.padding(14).background(Palette.card, in: RoundedRectangle(cornerRadius: 16))
                if chain != "All chains" { Badge(text: chain.uppercased(), color: Palette.blue) }
                ScrollView(.horizontal, showsIndicators: false) { HStack { ForEach(sections, id: \.self) { item in Button { section = item } label: { Badge(text: item, color: section == item ? Palette.mint : Palette.muted) } } } }
                if filtered.isEmpty {
                    ContentUnavailableView(section == "Whale Activity" ? "Wallet attribution unavailable" : "No candidates yet", systemImage: section == "Whale Activity" ? "eye.slash" : "dot.radiowaves.left.and.right", description: Text(section == "Whale Activity" ? "V1 does not claim whale flows from transaction counts." : "Live observations load automatically from public market feeds. Watchlist keeps only currently observed tokens here."))
                }
                ForEach(filtered) { t in
                    NavigationLink { TokenDetail(token: t) } label: {
                        CandidateRow(token: t)
                    }.buttonStyle(.plain)
                }
            }.padding(20)
        }.background(Palette.background)
    }
}
struct TokenDetail: View {
    let token: Token
    @EnvironmentObject var model: RadarModel
    private var t: Token { model.state?.candidates.first(where: { $0.id == token.id }) ?? token }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack { TokenAvatar(token: t); VStack(alignment: .leading) { Text(t.name).font(.title2.bold()); Text(t.symbol + " · " + t.chain.uppercased()).foregroundStyle(Palette.muted).font(.caption) }; Spacer(); Button { model.toggleWatch(t.id) } label: { Image(systemName: model.watchlist.contains(t.id) ? "star.fill" : "star").foregroundStyle(Palette.mint) }.accessibilityLabel("Toggle watchlist") }
                Badge(text: "ANALYSIS ONLY · \(t.status)", color: Palette.blue)
                Panel { VStack(alignment: .leading, spacing: 14) { Text(price(t.price)).font(.largeTitle.monospacedDigit()); PriceChart(points: t.points); Text("\(t.source) · observed \(Date(timeIntervalSince1970: t.fetched).formatted(date: .omitted, time: .standard))").font(.caption2).foregroundStyle(Palette.muted) } }
                Panel { VStack { Kicker(text: "Factor analysis"); ScoreWheel(token: t); ForEach(["Momentum", "Liquidity", "Volume", "Wallet", "Safety", "Social", "Entry Quality", "Rug Risk", "Risk", "Overall"], id: \.self) { key in HStack { Text(key).font(.caption); Spacer(); Text(t.score(key).map { String(format: "%.0f / 100", $0) } ?? "Unavailable").font(.caption.monospaced()).foregroundStyle(Palette.mint) } }; Text("Wallet score uses concentration only. Social has no contribution. These are heuristic scores, not probabilities.").font(.caption2).foregroundStyle(Palette.muted).padding(.top, 10) } }
                Panel { VStack(spacing: 20) {
                    HStack { Metric(title: "Pool liquidity", value: compact(t.liquidity)); Metric(title: "Market cap", value: compact(t.marketCap)) }
                    HStack { Metric(title: "FDV", value: compact(t.fdv)); Metric(title: "5m volume", value: compact(t.volume5)) }
                    HStack { Metric(title: "5m buy txns", value: String(t.buys)); Metric(title: "5m sell txns", value: String(t.sells)) }
                    HStack { Metric(title: "1h change", value: t.changeHour.map { String(format: "%+.1f%%", $0) } ?? "Unavailable"); Metric(title: "Pool age", value: t.created.map { "\(max(0, Int((model.now - $0)/60))) min" } ?? "Unavailable") }
                } }
                Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Observed metrics"); ForEach(t.metrics.keys.sorted(), id: \.self) { key in HStack { Text(key).font(.caption); Spacer(); Text((t.metrics[key] ?? nil).map { String(format: "%.2f", $0) } ?? "Unavailable").font(.caption.monospaced()).foregroundStyle(Palette.muted) } }; Text("Sampled observations, not tick history. Units are in each label.").font(.caption2).foregroundStyle(Palette.muted) } }
                Panel { VStack(alignment: .leading, spacing: 14) { Kicker(text: "Contract & pool"); Text(t.address).font(.caption.monospaced()).textSelection(.enabled); Text("Pool: " + t.pool).font(.caption2.monospaced()).foregroundStyle(Palette.muted).textSelection(.enabled); Button { UIPasteboard.general.string = t.address } label: { Label("Copy contract", systemImage: "doc.on.doc").font(.caption) } } }
                Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Security · \(t.security.source)"); Badge(text: t.security.complete ? "AVAILABLE CHECKS COMPLETE" : "INCOMPLETE — SIGNAL BLOCKED", color: t.security.complete ? Palette.mint : .orange); ForEach(t.security.facts.keys.sorted(), id: \.self) { key in VStack(alignment: .leading, spacing: 4) { Text(key).font(.caption).foregroundStyle(Palette.muted); Text(t.security.facts[key] ?? "Unavailable").font(.caption) } } } }
                ReasonPanel(title: "Evidence", items: t.reasons, symbol: "checkmark.circle", color: Palette.mint)
                ReasonPanel(title: "Risks", items: t.risks, symbol: "exclamationmark.triangle", color: .orange)
                ReasonPanel(title: "Unavailable data", items: t.unavailable, symbol: "minus.circle", color: Palette.muted)
            }.padding(20)
        }.background(Palette.background).navigationBarTitleDisplayMode(.inline)
    }
}
struct HistoryView: View {
    @EnvironmentObject var model: RadarModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("History").font(.largeTitle.bold())
                Text("Observed signal outcomes, not executed trades. Fees, partial exits and fills are not simulated.").font(.caption).foregroundStyle(Palette.muted)
                if model.history.isEmpty { ContentUnavailableView("A clean start", systemImage: "clock.arrow.circlepath", description: Text("Completed signals observed on this phone appear here. No invented track record.")) }
                ForEach(model.history) { s in
                    NavigationLink { SignalView(signal: s) } label: {
                        Panel { VStack(alignment: .leading, spacing: 12) { HStack { Text(s.token.symbol).font(.title3.bold()); Spacer(); Text(s.exit.map { String(format: "%+.1f%%", ($0/s.entry-1)*100) } ?? "Unpriced").font(.headline.monospacedDigit()).foregroundStyle(s.exit.map { $0 >= s.entry } == true ? Palette.mint : .orange) }; Kicker(text: s.closeReason ?? "Closed"); HStack { Text(Date(timeIntervalSince1970: s.opened), style: .date); Spacer(); Text("Score \(Int(s.confidence))/100") }.font(.caption2).foregroundStyle(Palette.muted) } }
                    }.buttonStyle(.plain)
                }
            }.padding(20)
        }.background(Palette.background).refreshable { await model.refresh() }
    }
}
struct SettingsView: View {
    @EnvironmentObject var model: RadarModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Scanner status").font(.largeTitle.bold())
                Panel { VStack(alignment: .leading, spacing: 16) {
                    Kicker(text: "On-device radar")
                    Badge(text: model.statusLabel, color: model.fresh && model.state?.live == true ? Palette.mint : .orange)
                    Text("Live feeds connect automatically. Scanning runs while this app is open. Locking your phone or leaving the app pauses monitoring.").font(.subheadline).foregroundStyle(Palette.muted)
                    if let scan = model.state?.lastScan { Text("Last discovery: " + Date(timeIntervalSince1970: scan).formatted(date: .omitted, time: .standard)).font(.caption).foregroundStyle(Palette.muted) }
                    HStack {
                        Button(model.refreshing ? "Scanning…" : "Refresh now") { Task { await model.refresh() } }.disabled(model.refreshing)
                        Spacer()
                        if model.refreshing { ProgressView().tint(Palette.mint) }
                    }
                    Text(model.phaseText).font(.caption).foregroundStyle(Palette.muted)
                    if let error = model.error { Text(error).font(.caption2).foregroundStyle(.orange) }
                    Text("Last scan step: \(model.lastCycleSeconds, specifier: "%.1f")s").font(.caption2.monospaced()).foregroundStyle(Palette.muted)
                } }
                Panel { VStack(alignment: .leading, spacing: 14) {
                    Kicker(text: "Notifications")
                    Text(model.pushStatus).font(.headline)
                    Text("Signal changes use in-app updates and haptics. This version does not scan or send market alerts while closed.").font(.caption).foregroundStyle(Palette.muted)
                    Button("Open iPhone settings") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }.font(.caption)
                } }
                if let state = model.state {
                    Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Market data health"); ForEach(state.providers) { p in HStack { Text(p.name).font(.caption); Spacer(); Circle().fill(p.ok && model.now - p.at < 120 ? Palette.mint : .orange).frame(width: 7, height: 7) } }; Text("Public feeds can be delayed. Missing critical evidence blocks new signals.").font(.caption2).foregroundStyle(Palette.muted) } }
                }
                Text(disclaimer).font(.caption).foregroundStyle(Palette.muted)
                Text("ZK Meme Radar 1.3 · Market data from DEX Screener and GeckoTerminal; security from GoPlus and Solana RPC.").font(.caption2).foregroundStyle(Palette.muted)
            }.padding(20)
        }.background(Palette.background)
    }
}
