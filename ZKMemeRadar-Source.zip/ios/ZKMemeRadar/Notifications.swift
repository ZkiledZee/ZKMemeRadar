import UIKit
import UserNotifications

extension Notification.Name {
    static let radarSignal = Notification.Name("radarSignal")
    static let radarDevice = Notification.Name("radarDevice")
}
@MainActor
final class PushDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    static var pendingSignal: String?
    static var deviceToken: String?
    static var registrationError: String?
    static var enabled: Bool { (Bundle.main.object(forInfoDictionaryKey: "RadarPushEnabled") as? String) == "YES" }
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        if let payload = launchOptions?[.remoteNotification] as? [AnyHashable: Any], let id = payload["signalId"] as? String { Self.pendingSignal = id }
        return true
    }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Self.deviceToken = deviceToken.map { String(format: "%02x", $0) }.joined()
        Self.registrationError = nil
        NotificationCenter.default.post(name: .radarDevice, object: nil)
    }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        Self.registrationError = error.localizedDescription
        NotificationCenter.default.post(name: .radarDevice, object: nil)
    }
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse) async {
        guard let id = response.notification.request.content.userInfo["signalId"] as? String else { return }
        await MainActor.run {
            Self.pendingSignal = id
            NotificationCenter.default.post(name: .radarSignal, object: id)
        }
    }
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification) async -> UNNotificationPresentationOptions { [.banner, .sound, .list] }
}
