import SwiftUI

@main
struct ZKMemeRadarApp: App {
    @UIApplicationDelegateAdaptor(PushDelegate.self) var delegate
    @StateObject private var model = RadarModel()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(model).preferredColorScheme(.dark).tint(Palette.mint) }
    }
}
struct RootView: View {
    @EnvironmentObject var model: RadarModel
    @Environment(\.scenePhase) private var phase
    @State private var settings = false
    var body: some View {
        VStack(spacing: 0) {
            if let error = model.error {
                HStack { Image(systemName: "wifi.exclamationmark"); Text(error).font(.caption); Spacer(); Button("Retry") { Task { await model.refresh() } }.font(.caption.bold()) }.padding(12).foregroundStyle(.orange).background(Palette.card)
            } else if model.cached {
                Text("Cached observations — reconnecting. Do not enter from cached data.").font(.caption).padding(12).frame(maxWidth: .infinity).foregroundStyle(.orange).background(Palette.card)
            }
            TabView(selection: $model.tab) {
                NavigationStack { HomeView().toolbar { connectionButton } }.tabItem { Label("Home", systemImage: "square.grid.2x2") }.tag(0)
                NavigationStack {
                    Group {
                        if let s = model.selectedSignal ?? model.state?.active { SignalView(signal: s) }
                        else { ContentUnavailableView("No active signal", systemImage: "scope", description: Text("The scanner is selective. No entry is better than an unverified one.")).background(Palette.background) }
                    }.toolbar {
                        if model.selectedSignal != nil { ToolbarItem(placement: .topBarTrailing) { Button("Current") { model.selectedSignal = nil } } }
                    }
                }.tabItem { Label("Signal", systemImage: "scope") }.tag(1)
                NavigationStack {
                    ScrollView { VStack(alignment: .leading, spacing: 24) { Text("Radar").font(.largeTitle.bold()); RadarVisual(tokens: model.state?.candidates ?? [], active: model.state?.active?.token, live: model.fresh && model.state?.live == true).frame(height: 350); Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: model.state?.active == nil ? "Discovery mode" : "Signal lock engaged"); Text("Stronger candidates sit closer to the centre. Dots represent real observed tokens, not buy recommendations.").font(.subheadline).foregroundStyle(Palette.muted); Text("SOLANA  /  BASE  /  ETHEREUM  /  BNB").font(.system(size: 9, design: .monospaced)).foregroundStyle(Palette.mint) } } }.padding(22) }.background(Palette.background)
                }.tabItem { Label("Radar", systemImage: "dot.radiowaves.left.and.right") }.tag(2)
                NavigationStack { MarketView() }.tabItem { Label("Market", systemImage: "chart.line.uptrend.xyaxis") }.tag(3)
                NavigationStack { HistoryView() }.tabItem { Label("History", systemImage: "clock") }.tag(4)
            }.toolbarBackground(Palette.background, for: .tabBar).toolbarBackground(.visible, for: .tabBar)
        }.background(Palette.background)
        .sheet(isPresented: $settings) { NavigationStack { SettingsView().toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { settings = false } } } }.environmentObject(model) }
        .task(id: phase) {
            guard phase == .active else { return }
            if !model.connected { settings = true }
            if model.connected { await model.enablePush() }
            while !Task.isCancelled {
                await model.refresh()
                do { try await Task.sleep(for: .seconds(10)) } catch { break }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .radarSignal)) { n in if let id = n.object as? String { Task { await model.openSignal(id) } } }
        .onReceive(NotificationCenter.default.publisher(for: .radarDevice)) { _ in Task { await model.registerDevice() } }
        .onOpenURL { url in
            if url.scheme == "zkmemeradar", url.host == "signal", let id = url.pathComponents.last { PushDelegate.pendingSignal = id; Task { await model.openSignal(id) } }
        }
    }
    @ToolbarContentBuilder var connectionButton: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) { Button { settings = true } label: { Image(systemName: "slider.horizontal.3") }.accessibilityLabel("Connection and notifications") }
    }
}
