import SwiftUI

struct SignalView: View {
    let signal: Signal
    @EnvironmentObject var model: RadarModel
    private var current: Signal {
        if model.state?.active?.id == signal.id { return model.state!.active! }
        return model.history.first(where: { $0.id == signal.id }) ?? signal
    }
    var body: some View {
        let s = current
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack { Kicker(text: s.closed == nil ? "One coin. One focus." : "Recorded observation"); Spacer(); Image(systemName: s.closed == nil ? "lock.fill" : "lock.open").foregroundStyle(Palette.mint) }
                HStack(spacing: 14) {
                    TokenAvatar(token: s.token)
                    VStack(alignment: .leading, spacing: 4) { Text(s.token.symbol).font(.system(size: 32, weight: .bold, design: .rounded)); Text(s.token.name).font(.subheadline).foregroundStyle(Palette.muted) }
                    Spacer(); Badge(text: s.token.chain.uppercased(), color: Palette.blue)
                }
                Panel {
                    VStack(alignment: .leading, spacing: 18) {
                        Badge(text: s.closed != nil ? s.status : model.fresh && model.now - s.lastGood < 60 && model.now < s.expires ? s.recommendation : "STALE — DO NOT ENTER", color: s.closed == nil && model.fresh ? Palette.mint : .orange)
                        Text(price(s.token.price)).font(.system(size: 36, weight: .medium, design: .rounded)).minimumScaleFactor(0.5).lineLimit(1).monospacedDigit().contentTransition(.numericText())
                        PriceChart(points: s.token.points, entry: s.entry, stop: s.stop, target: s.target1)
                        HStack { Metric(title: "Signal reference", value: price(s.entry)); Metric(title: "Invalidation", value: price(s.stop), accent: .orange) }
                        Text("Entry zone: \(price(s.entryLow)) – \(price(s.entryHigh))").font(.caption).foregroundStyle(Palette.muted)
                        Divider().overlay(.white.opacity(0.04))
                        HStack { Metric(title: "Target 1 · 2R", value: price(s.target1)); Metric(title: "Target 2 · 3R", value: price(s.target2), accent: Palette.mint) }
                    }
                }
                if s.closed == nil {
                    Panel {
                        TimelineView(.periodic(from: .now, by: 1)) { _ in
                            let remaining = max(0, Int(s.expires - model.now))
                            VStack(alignment: .leading, spacing: 14) {
                                HStack { Metric(title: "Expected hold", value: "\(Int((s.expires - s.opened) / 60)) MIN"); Metric(title: "Countdown", value: String(format: "%02d:%02d", remaining / 60, remaining % 60), accent: Palette.mint) }
                                ProgressView(value: Double(remaining), total: max(1, s.expires - s.opened)).tint(Palette.mint)
                                Text("Estimate only. Momentum, security and liquidity can trigger an earlier exit.").font(.caption).foregroundStyle(Palette.muted)
                            }
                        }
                    }
                }
                Panel {
                    VStack(spacing: 20) {
                        HStack { Metric(title: "Confidence score", value: String(format: "%.0f/100", s.confidence)); Metric(title: "Rug risk score", value: s.token.score("Rug Risk").map { String(format: "%.0f/100", $0) } ?? "Unavailable", accent: .orange) }
                        HStack {
                            Metric(title: "Target 2 reward", value: String(format: "+%.1f%%", (s.target2/s.entry-1)*100), accent: Palette.mint)
                            Metric(title: "Stop distance", value: String(format: "%.1f%%", (s.stop/s.entry-1)*100), accent: .orange)
                        }
                        Text("Heuristic scores, not win or rug probabilities. Prices exclude fees, tax and slippage. Stops are observations, not placed orders.").font(.caption2).foregroundStyle(Palette.muted)
                    }
                }
                if let reason = s.closeReason {
                    Panel { VStack(alignment: .leading, spacing: 12) { Kicker(text: "Closed — \(reason)"); HStack { Metric(title: "Observed exit", value: price(s.exit)); Metric(title: "Time held", value: "\(Int(((s.closed ?? s.opened) - s.opened)/60)) min") }; HStack { Metric(title: "Max observed gain", value: String(format: "+%.1f%%", s.maxGain)); Metric(title: "Max observed loss", value: String(format: "%.1f%%", s.maxLoss)) } } }
                }
                ReasonPanel(title: "Why this signal", items: s.reasons, symbol: "checkmark.circle", color: Palette.mint)
                ReasonPanel(title: "Risks & invalidation", items: s.token.risks + ["Exit below invalidation, on severe liquidity loss, security deterioration, sell dominance or hold expiry."], symbol: "exclamationmark.triangle", color: .orange)
                NavigationLink { TokenDetail(token: s.token) } label: { Label("Full token analysis", systemImage: "chart.xyaxis.line").frame(maxWidth: .infinity).padding().background(Palette.card, in: RoundedRectangle(cornerRadius: 16)) }
                Text(disclaimer).font(.caption2).foregroundStyle(Palette.muted)
            }.padding(20)
        }.background(Palette.background).navigationTitle("Signal").navigationBarTitleDisplayMode(.inline)
    }
}
struct ReasonPanel: View {
    let title: String
    let items: [String]
    let symbol: String
    let color: Color
    var body: some View {
        Panel { VStack(alignment: .leading, spacing: 14) {
            Kicker(text: title)
            if items.isEmpty { Text("No verified evidence yet").font(.caption).foregroundStyle(Palette.muted) }
            ForEach(Array(items.enumerated()), id: \.offset) { _, item in HStack(alignment: .top, spacing: 10) { Image(systemName: symbol).foregroundStyle(color); Text(item).foregroundStyle(.white.opacity(0.85)) }.font(.caption) }
        } }
    }
}
