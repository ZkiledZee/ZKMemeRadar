import Foundation
import JavaScriptCore

/// Executes only the engine bundled in the signed app. Network responses are data.
@MainActor
final class LocalScanner {
    private var context: JSContext?
    private var pending: CheckedContinuation<Data, Error>?
    private var jobs: [Task<Void, Never>] = []
    private var generation = UUID()
    private let allowedHosts: Set<String> = ["api.dexscreener.com", "api.geckoterminal.com", "api.gopluslabs.io", "api.mainnet-beta.solana.com"]
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 8
        config.timeoutIntervalForResource = 10
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: config)
    }()
    func cancel() {
        generation = UUID()
        jobs.forEach { $0.cancel() }; jobs.removeAll()
        let continuation = pending; pending = nil
        context = nil
        continuation?.resume(throwing: CancellationError())
    }
    private func finish(_ data: Data?, _ message: String) {
        guard let continuation = pending else { return }
        pending = nil
        jobs.forEach { $0.cancel() }; jobs.removeAll()
        context = nil
        if let data { continuation.resume(returning: data) }
        else { continuation.resume(throwing: NSError(domain: "RadarScanner", code: 1, userInfo: [NSLocalizedDescriptionKey: message])) }
    }
    func scan(_ snapshot: Data?) async throws -> Data {
        guard pending == nil else { throw CancellationError() }
        let runID = UUID(); generation = runID
        guard let url = Bundle.main.url(forResource: "Scanner", withExtension: "js") else {
            throw NSError(domain: "RadarScanner", code: 2, userInfo: [NSLocalizedDescriptionKey: "Bundled scanner is missing."])
        }
        let source = try String(contentsOf: url, encoding: .utf8)
        return try await withCheckedThrowingContinuation { continuation in
            pending = continuation
            guard let js = JSContext() else { finish(nil, "Could not start scanner."); return }
            context = js
            js.exceptionHandler = { [weak self] _, exception in self?.finish(nil, exception?.toString() ?? "Scanner error") }
            let uuid: @convention(block) () -> String = { UUID().uuidString }
            js.setObject(uuid, forKeyedSubscript: "nativeUUID" as NSString)
            let complete: @convention(block) (String, String) -> Void = { [weak self] value, error in
                guard let self, self.generation == runID else { return }
                self.finish(error.isEmpty ? value.data(using: .utf8) : nil, error)
            }
            js.setObject(complete, forKeyedSubscript: "nativeComplete" as NSString)
            let delay: @convention(block) (Double, JSValue) -> Void = { [weak self] milliseconds, callback in
                guard let self else { return }
                self.jobs.append(Task { @MainActor [weak self] in
                    do { try await Task.sleep(for: .milliseconds(milliseconds)) } catch { return }
                    guard let self, self.generation == runID, self.pending != nil else { return }
                    callback.call(withArguments: [])
                })
            }
            js.setObject(delay, forKeyedSubscript: "nativeDelay" as NSString)
            let request: @convention(block) (String, String, JSValue) -> Void = { [weak self] address, options, callback in
                guard let self else { return }
                self.jobs.append(Task { @MainActor [weak self] in
                    guard let self, self.generation == runID else { return }
                    do {
                        guard let target = URL(string: address), target.scheme == "https", self.allowedHosts.contains(target.host ?? "") else { throw URLError(.unsupportedURL) }
                        var request = URLRequest(url: target)
                        request.setValue("application/json", forHTTPHeaderField: "Accept")
                        if let bytes = options.data(using: .utf8), let values = try JSONSerialization.jsonObject(with: bytes) as? [String: Any] {
                            request.httpMethod = values["method"] as? String ?? "GET"
                            request.httpBody = (values["body"] as? String)?.data(using: .utf8)
                            if let headers = values["headers"] as? [String: String] { for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) } }
                        }
                        let (data, response) = try await self.session.data(for: request)
                        guard data.count <= 5_000_000, let http = response as? HTTPURLResponse, let text = String(data: data, encoding: .utf8) else { throw URLError(.cannotDecodeContentData) }
                        guard self.generation == runID, self.pending != nil, !Task.isCancelled else { return }
                        callback.call(withArguments: [text, http.statusCode, ""])
                    } catch {
                        guard self.generation == runID, self.pending != nil, !Task.isCancelled else { return }
                        callback.call(withArguments: ["", 0, error.localizedDescription])
                    }
                })
            }
            js.setObject(request, forKeyedSubscript: "nativeRequest" as NSString)
            js.evaluateScript(source)
            guard pending != nil else { return }
            js.objectForKeyedSubscript("run")?.call(withArguments: [snapshot.flatMap { String(data: $0, encoding: .utf8) } ?? "{}"])
            jobs.append(Task { @MainActor [weak self] in
                do { try await Task.sleep(for: .seconds(45)) } catch { return }
                guard let self, self.generation == runID else { return }
                self.finish(nil, "Market feeds timed out. Retrying shortly.")
            })
        }
    }
}
