import SwiftUI
import Charts

enum Palette {
    static let background = Color(red: 0.025, green: 0.04, blue: 0.075)
    static let card = Color(red: 0.055, green: 0.078, blue: 0.12)
    static let mint = Color(red: 0.40, green: 0.96, blue: 0.78)
    static let blue = Color(red: 0.37, green: 0.59, blue: 1)
    static let muted = Color(red: 0.52, green: 0.60, blue: 0.69)
}
struct Panel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [Palette.card, Palette.card.opacity(0.65)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.07), lineWidth: 1))
    }
}
struct Kicker: View {
    let text: String
    var body: some View { Text(text.uppercased()).font(.system(size: 10, weight: .semibold, design: .monospaced)).tracking(2).foregroundStyle(Palette.muted) }
}
struct Badge: View {
    let text: String
    var color: Color = Palette.mint
    var body: some View {
        Text(text).font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(1).padding(.horizontal, 11).padding(.vertical, 7).background(color.opacity(0.10), in: Capsule()).foregroundStyle(color)
    }
}
struct Metric: View {
    let title: String
    let value: String
    var accent: Color = .white
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Kicker(text: title)
            Text(value).font(.system(size: 19, weight: .semibold, design: .rounded)).foregroundStyle(accent).monospacedDigit().contentTransition(.numericText()).minimumScaleFactor(0.65).lineLimit(1)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct TokenAvatar: View {
    let token: Token
    var body: some View {
        Text(String(token.symbol.prefix(2))).font(.system(size: 19, weight: .bold, design: .rounded)).foregroundStyle(Palette.mint)
            .frame(width: 48, height: 48).background(Palette.mint.opacity(0.09), in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Palette.mint.opacity(0.20)))
    }
}
struct PriceChart: View {
    let points: [PricePoint]
    var entry: Double? = nil
    var stop: Double? = nil
    var target: Double? = nil
    var body: some View {
        if points.count >= 2 {
            Chart {
                ForEach(points) { p in
                    LineMark(x: .value("Time", Date(timeIntervalSince1970: p.time)), y: .value("Price", p.price))
                        .foregroundStyle(Palette.mint).interpolationMethod(.linear)
                }
                if let entry { RuleMark(y: .value("Entry", entry)).foregroundStyle(Palette.blue.opacity(0.7)).lineStyle(StrokeStyle(lineWidth: 1, dash: [4])).annotation(position: .top, alignment: .leading) { Text("ENTRY").font(.system(size: 8)).foregroundStyle(Palette.blue) } }
                if let stop { RuleMark(y: .value("Invalidation", stop)).foregroundStyle(.orange.opacity(0.7)).lineStyle(StrokeStyle(lineWidth: 1, dash: [4])) }
                if let target { RuleMark(y: .value("Target", target)).foregroundStyle(Palette.mint.opacity(0.4)).lineStyle(StrokeStyle(lineWidth: 1, dash: [4])) }
            }
            .chartYScale(domain: .automatic(includesZero: false))
            .chartXAxis { AxisMarks(values: .automatic(desiredCount: 3)) { _ in AxisValueLabel().foregroundStyle(Palette.muted) } }
            .chartYAxis(.hidden).frame(height: 160).accessibilityLabel("Observed USD price history; sampled data, not exchange ticks")
        } else {
            VStack(spacing: 12) { Image(systemName: "waveform.path").font(.largeTitle); Text("Building real price history").font(.caption) }.foregroundStyle(Palette.muted).frame(maxWidth: .infinity).frame(height: 160)
        }
    }
}
struct RadarVisual: View {
    let tokens: [Token]
    let active: Token?
    let live: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20, paused: reduceMotion || !live)) { timeline in
            let angle = reduceMotion || !live ? 0.0 : timeline.date.timeIntervalSince1970.truncatingRemainder(dividingBy: 8) / 8 * 360
            GeometryReader { geo in
                let size = min(geo.size.width, geo.size.height)
                ZStack {
                    Circle().fill(RadialGradient(colors: [Palette.mint.opacity(0.07), .clear], center: .center, startRadius: 0, endRadius: size / 2))
                    ForEach(1..<5) { ring in Circle().stroke(Palette.mint.opacity(ring == 4 ? 0.14 : 0.08), lineWidth: 1).padding(size * CGFloat(4-ring) / 9) }
                    Rectangle().fill(Palette.mint.opacity(0.07)).frame(height: 1)
                    Rectangle().fill(Palette.mint.opacity(0.07)).frame(width: 1)
                    if live {
                        Circle().fill(AngularGradient(stops: [.init(color: .clear, location: 0), .init(color: .clear, location: 0.76), .init(color: Palette.mint.opacity(0.16), location: 0.995), .init(color: .clear, location: 1)], center: .center)).rotationEffect(.degrees(angle))
                    }
                    ForEach(Array(tokens.prefix(18).enumerated()), id: \.element.id) { index, token in
                        let a = Double(index) * 2.399963
                        let radius = size * CGFloat(0.46 - (token.score("Overall") ?? 0) / 300)
                        Circle().fill(Palette.mint.opacity(live ? 0.8 : 0.2)).frame(width: 5, height: 5).shadow(color: Palette.mint.opacity(0.5), radius: 6)
                            .offset(x: CGFloat(cos(a)) * radius, y: CGFloat(sin(a)) * radius)
                    }
                    if let active {
                        VStack(spacing: 6) { Image(systemName: "scope").font(.system(size: 26, weight: .light)); Text(active.symbol).font(.system(size: 12, weight: .bold, design: .monospaced)) }
                            .foregroundStyle(Palette.mint).padding(18).background(Palette.background, in: Circle()).overlay(Circle().stroke(Palette.mint.opacity(0.5))).shadow(color: Palette.mint.opacity(0.15), radius: 20).transition(.scale.combined(with: .opacity))
                    } else { Circle().fill(Palette.mint.opacity(live ? 1 : 0.2)).frame(width: 7, height: 7) }
                }.animation(reduceMotion ? nil : .spring(duration: 0.6), value: active?.id).frame(width: size, height: size).frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }.accessibilityLabel(active.map { "Radar locked on \($0.symbol)" } ?? "Market discovery radar")
    }
}
struct ScoreWheel: View {
    let token: Token
    private let names = ["Momentum", "Liquidity", "Volume", "Wallet", "Safety", "Entry Quality"]
    var body: some View {
        Canvas { context, size in
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let radius = min(size.width, size.height) * 0.34
            func point(_ i: Int, _ fraction: Double) -> CGPoint {
                let a = Double(i) * .pi / 3 - .pi / 2
                return CGPoint(x: center.x + cos(a) * radius * fraction, y: center.y + sin(a) * radius * fraction)
            }
            for ring in 1...4 {
                var p = Path(); p.move(to: point(0, Double(ring)/4))
                for i in 1..<6 { p.addLine(to: point(i, Double(ring)/4)) }; p.closeSubpath()
                context.stroke(p, with: .color(.white.opacity(0.08)), lineWidth: 1)
            }
            var shape = Path()
            for i in 0..<6 {
                let p = point(i, (token.score(names[i]) ?? 0) / 100)
                if i == 0 { shape.move(to: p) } else { shape.addLine(to: p) }
                let label = names[i] == "Entry Quality" ? "Entry" : names[i]
                context.draw(Text(label).font(.system(size: 10)).foregroundColor(Palette.muted), at: point(i, 1.25))
            }
            shape.closeSubpath(); context.fill(shape, with: .color(Palette.mint.opacity(0.12))); context.stroke(shape, with: .color(Palette.mint), lineWidth: 1.5)
        }.frame(height: 240).accessibilityLabel("Factor scores; unavailable metrics have no contribution")
    }
}
