import Foundation
import Security

struct RadarError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}
enum Vault {
    static func read(_ key: String) -> String? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "ZKMemeRadar", kSecAttrAccount as String: key, kSecReturnData as String: true]
        var result: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func write(_ value: String?, key: String) throws {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "ZKMemeRadar", kSecAttrAccount as String: key]
        SecItemDelete(q as CFDictionary)
        guard let value else { return }
        var add = q
        add[kSecValueData as String] = Data(value.utf8)
        add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        guard SecItemAdd(add as CFDictionary, nil) == errSecSuccess else { throw RadarError(message: "Could not save secure connection.") }
    }
}
struct API {
    let base: URL
    let bearer: String
    static func validURL(_ input: String) -> URL? {
        guard let u = URL(string: input.trimmingCharacters(in: .whitespacesAndNewlines)), u.scheme == "https", u.host != nil, u.user == nil, u.password == nil, u.query == nil, u.fragment == nil, u.path == "" || u.path == "/" else { return nil }
        return u
    }
    func request(_ path: String, method: String = "GET", body: Data? = nil) async throws -> Data {
        var r = URLRequest(url: base.appendingPathComponent(path))
        r.timeoutInterval = 18
        r.httpMethod = method
        r.httpBody = body
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !bearer.isEmpty { r.setValue("Bearer \(bearer)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await URLSession.shared.data(for: r)
        guard let h = response as? HTTPURLResponse else { throw RadarError(message: "Invalid server response.") }
        guard (200..<300).contains(h.statusCode) else {
            throw RadarError(message: h.statusCode == 401 ? "Connection credentials rejected. Reconnect in Settings." : "Server returned \(h.statusCode). Please retry.")
        }
        return data
    }
    func get<T: Decodable>(_ path: String) async throws -> T { try JSONDecoder().decode(T.self, from: await request(path)) }
}
