import SwiftUI

struct Sparkline: View {
    let points: [PricePoint]
    var color: Color = Palette.mint
    var body: some View {
        GeometryReader { geo in
            let values = Array(points.suffix(40)).map(\.price)
            let low = values.min() ?? 0
            let span = max((values.max() ?? 0) - low, max(abs(low) * 0.00001, 0.000000000001))
            if values.count > 1 {
                Path { path in
                    for (index, value) in values.enumerated() {
                        let point = CGPoint(x: geo.size.width * Double(index) / Double(values.count - 1), y: geo.size.height * (1 - (value - low) / span))
                        if index == 0 { path.move(to: point) } else { path.addLine(to: point) }
                    }
                }.stroke(color, style: StrokeStyle(lineWidth: 1.8, lineCap: .round, lineJoin: .round))
                    .shadow(color: color.opacity(0.2), radius: 4)
            } else {
                Text("WARMING UP").font(.system(size: 7, design: .monospaced)).foregroundStyle(Palette.muted).frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }.frame(width: 65, height: 26).accessibilityLabel("Sampled price trend")
    }
}
struct CandidateRow: View {
    let token: Token
    var body: some View {
        HStack(spacing: 12) {
            TokenAvatar(token: token)
            VStack(alignment: .leading, spacing: 5) {
                Text(token.symbol).font(.system(size: 16, weight: .semibold, design: .rounded)).lineLimit(1)
                Text(token.chain.uppercased() + " · " + compact(token.liquidity) + " LIQ").font(.system(size: 8, design: .monospaced)).foregroundStyle(Palette.muted).lineLimit(1)
            }
            Spacer(minLength: 4)
            Sparkline(points: token.points, color: (token.change5 ?? 0) >= 0 ? Palette.mint : .orange)
            VStack(alignment: .trailing, spacing: 5) {
                Text(price(token.price)).font(.system(size: 12, weight: .medium, design: .rounded)).monospacedDigit().contentTransition(.numericText())
                Text(token.change5.map { String(format: "%+.1f%%", $0) } ?? "—").font(.caption2.monospacedDigit()).foregroundStyle((token.change5 ?? 0) >= 0 ? Palette.mint : .orange)
            }.frame(minWidth: 68, alignment: .trailing)
        }.padding(14).background(Palette.card.opacity(0.7), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.045)))
    }
}
struct ReadinessView: View {
    let tokens: [Token]
    private var sampled: Int { tokens.filter { ($0.points.last?.time ?? 0) - ($0.points.first?.time ?? 0) >= 300 && $0.points.count >= 10 }.count }
    private var secured: Int { tokens.filter { $0.security.complete && !$0.security.danger && Date().timeIntervalSince1970 - $0.security.checked < 180 }.count }
    var body: some View {
        Panel {
            VStack(alignment: .leading, spacing: 16) {
                HStack { Kicker(text: "Entry readiness"); Spacer(); Image(systemName: "checkmark.shield").foregroundStyle(Palette.mint) }
                HStack(spacing: 16) {
                    gate("Observed", count: tokens.count, total: tokens.count)
                    gate("Warmed up", count: sampled, total: tokens.count)
                    gate("Security", count: secured, total: tokens.count)
                }
                Text("A signal needs a confirmed entry pattern and fresh security evidence. Warmup needs at least 5 minutes and 10 samples per coin.").font(.caption2).foregroundStyle(Palette.muted)
            }
        }
    }
    private func gate(_ name: String, count: Int, total: Int) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("\(count)").font(.title2.bold().monospacedDigit()).contentTransition(.numericText())
            ProgressView(value: Double(count), total: Double(max(1, total))).tint(Palette.mint)
            Text(name).font(.caption2).foregroundStyle(Palette.muted)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct ActivityView: View {
    @EnvironmentObject var model: RadarModel
    var body: some View {
        Panel {
            VStack(alignment: .leading, spacing: 14) {
                HStack { Kicker(text: "Scanner activity"); Spacer(); Text("ON DEVICE").font(.system(size: 8, design: .monospaced)).foregroundStyle(Palette.mint) }
                if model.events.isEmpty { Text("Connecting to public market feeds…").font(.caption).foregroundStyle(Palette.muted) }
                ForEach(Array(model.events.prefix(4))) { event in
                    HStack(spacing: 10) {
                        Image(systemName: event.symbol).foregroundStyle(Palette.mint).frame(width: 18)
                        Text(event.text).lineLimit(1)
                        Spacer(minLength: 0)
                        Text(event.time, style: .time).foregroundStyle(Palette.muted).font(.system(size: 9, design: .monospaced))
                    }.font(.caption).transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
        }
    }
}
struct DashboardView: View {
    @EnvironmentObject var model: RadarModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private var tokens: [Token] { model.state?.candidates ?? [] }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("ZK / RADAR").font(.system(size: 25, weight: .bold, design: .rounded)).tracking(-0.8)
                        Text("MEME MARKET INTELLIGENCE").font(.system(size: 8, weight: .medium, design: .monospaced)).tracking(1.6).foregroundStyle(Palette.muted)
                    }
                    Spacer()
                    Badge(text: model.statusLabel, color: model.fresh ? Palette.mint : .orange)
                }
                Panel {
                    VStack(spacing: 4) {
                        HStack {
                            Kicker(text: model.state?.active == nil ? "Searching for an edge" : "One signal · locked")
                            Spacer()
                            Image(systemName: "dot.radiowaves.left.and.right").foregroundStyle(Palette.mint).symbolEffect(.pulse, isActive: model.running && !reduceMotion)
                        }
                        RadarVisual(tokens: tokens, active: model.state?.active?.token, live: model.running).frame(height: 205)
                        Text(model.phaseText).font(.system(size: 12, weight: .medium, design: .monospaced)).foregroundStyle(Palette.mint).lineLimit(1).contentTransition(.opacity)
                        Text(model.refreshing ? "Checking live observations" : "Next scan automatically").font(.caption2).foregroundStyle(Palette.muted).padding(.bottom, 12)
                        HStack {
                            Metric(title: "Observed", value: "\(tokens.count)")
                            Metric(title: "Watching", value: "\(model.state?.potential ?? 0)")
                            Metric(title: "Signal", value: model.state?.active == nil ? "0" : "1", accent: Palette.mint)
                        }.padding(.top, 12).overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.06)).frame(height: 1) }
                    }
                }
                if let signal = model.state?.active {
                    Button { model.selectedSignal = nil; model.tab = 1 } label: {
                        Panel {
                            HStack(spacing: 14) {
                                TokenAvatar(token: signal.token)
                                VStack(alignment: .leading, spacing: 5) { Kicker(text: "Your active signal"); Text(signal.token.symbol).font(.title3.bold()); Text(model.fresh && model.now - signal.lastGood < 60 ? signal.recommendation : "Verifying latest conditions").font(.caption).foregroundStyle(Palette.mint) }
                                Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(Palette.mint)
                            }
                        }
                    }.buttonStyle(.plain)
                } else {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "scope").font(.title2).foregroundStyle(Palette.blue)
                        VStack(alignment: .leading, spacing: 5) { Text("Waiting for confirmation").font(.subheadline.bold()); Text("A qualifying setup opens the Signal tab with its entry, targets and evidence.").font(.caption).foregroundStyle(Palette.muted) }
                    }.padding(.horizontal, 4)
                }
                if let notice = model.signalNotice {
                    HStack { Image(systemName: "bell.badge"); Text(notice).font(.caption); Spacer(); Button { model.signalNotice = nil } label: { Image(systemName: "xmark") } }.foregroundStyle(Palette.mint).padding(14).background(Palette.mint.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
                }
                ReadinessView(tokens: tokens)
                HStack { Kicker(text: "Leading candidates"); Spacer(); Button("All markets →") { model.tab = 3 }.font(.caption).foregroundStyle(Palette.mint) }
                ForEach(Array(tokens.prefix(5))) { token in
                    NavigationLink { TokenDetail(token: token) } label: { CandidateRow(token: token) }.buttonStyle(.plain)
                }
                ActivityView()
                HStack { Image(systemName: "iphone"); Text("Screen stays awake while scanning. Leaving the app pauses monitoring.") }.font(.caption2).foregroundStyle(Palette.muted)
                Text(disclaimer).font(.system(size: 10)).foregroundStyle(Palette.muted)
            }.padding(.horizontal, 20).padding(.bottom, 24)
        }.background {
            ZStack(alignment: .topTrailing) {
                Palette.background
                Circle().fill(Palette.blue.opacity(0.08)).frame(width: 280, height: 280).blur(radius: 90).offset(x: 130, y: -160)
            }.ignoresSafeArea()
        }.refreshable { await model.refresh() }
    }
}
