const env=()=>'';
const randomUUID=()=>nativeUUID();
class URL { constructor(value){this.host=String(value).split('/')[2];} }
const AbortSignal={timeout:()=>undefined};
function setTimeout(fn,delay){nativeDelay(Math.max(0,Math.min(60000,delay)),fn);}
function fetch(url,options={}) {return new Promise((resolve,reject)=>{
 nativeRequest(String(url),JSON.stringify(options),(body,status,error)=>{
  if(error){reject(new Error(error));return;}
  resolve({ok:status>=200&&status<300,status,text:async()=>body});
 });
});}

function time() { return Date.now() / 1000; }
function num(v, d = null) { if (v === null || v === undefined || v === '')
    return d; const n = Number(v); return Number.isFinite(n) ? n : d; }
function clamp(v) { return Math.round(Math.max(0, Math.min(100, v)) * 10) / 10; }
function emptySecurity() { return { source: 'Unavailable', checked: 0, complete: false, danger: false, risk: null, concentration: null, facts: {}, warnings: ['Required security evidence unavailable — signals blocked'] }; }
function evaluate(t, previous, now = time()) {
    const same = previous?.pool === t.pool;
    t.points = same ? [...previous.points] : [];
    t.security = same ? previous.security : emptySecurity();
    if (!t.points.length || t.fetched - t.points.at(-1).time >= 8)
        t.points.push({ time: t.fetched, price: t.price, liquidity: t.liquidity, volume5: t.volume5, buys: t.buys, sells: t.sells });
    t.points = t.points.filter((p) => now - p.time <= 7200).slice(-480);
    t.reasons = [];
    t.risks = [...t.security.warnings];
    t.eligible = false;
    t.entryLow = null;
    t.entryHigh = null;
    t.stop = null;
    t.target1 = null;
    t.target2 = null;
    t.holdSeconds = 900;
    t.unavailable = ['Unique buyers and sellers', 'Buy and sell dollar volume', 'Developer / insider wallet attribution', 'Whale / profitable-wallet flows', 'Social mention and bot statistics', 'Bundled and coordinated supply', 'Rug-pull probability (not calibrated)', 'LP lock expiry / pool-specific sell simulation'];
    const sec = t.security, fresh = sec.complete && now - sec.checked < 180, cap = t.marketCap || t.fdv, ratio = cap > 0 ? t.liquidity / cap : null;
    const activity = t.buys + t.sells, share = t.buys / Math.max(1, activity), vr = t.volume5 / Math.max(1, t.volumeHour / 12), change = t.change5 || 0;
    const liq = clamp(45 + 20 * Math.log10(Math.max(1, t.liquidity) / 100000) + (ratio ? Math.min(ratio, .3) * 100 : 0));
    const vol = clamp(30 + Math.min(vr, 3) * 15 + Math.min(activity, 150) / 6 + Math.max(0, share - .5) * 50);
    let momentum = clamp(45 + change * 3 + Math.max(0, share - .5) * 60), entry = 0, setup = false;
    if (change > 20) {
        momentum = clamp(momentum - (change - 20) * 3);
        t.risks.push('Overextended vertical move');
    }
    const points = t.points, enough = points.length >= 10 && points.at(-1).time - points[0].time >= 300;
    if (enough) {
        const old = points.filter((p) => p.time >= now - 900 && p.time < now - 90), recent = points.filter((p) => p.time >= now - 90);
        if (old.length >= 5 && recent.length >= 3) {
            const r = Math.max(...old.map((p) => p.price));
            const retest = recent.slice(0, -2).some((p, i) => p.price > r * 1.004 && recent.slice(i + 1, -1).some((q) => q.price >= r * .992 && q.price <= r * 1.01 && q.price < p.price * .998));
            setup = retest && t.price > points.at(-2).price && t.price >= r && t.price <= r * 1.018;
            entry = setup ? 92 : Math.abs(t.price / r - 1) < .025 ? 55 : 25;
            t.entryLow = r * .998;
            t.entryHigh = r * 1.018;
            const returns = points.slice(1).map((p, i) => Math.abs(p.price / points[i].price - 1)).sort((a, b) => a - b);
            const width = Math.max(.025, Math.min(.08, returns[Math.floor(returns.length / 2)] * 5));
            t.stop = Math.min(t.entryLow * .985, t.price * (1 - width));
            const risk = t.price - t.stop;
            t.target1 = t.price + 2 * risk;
            t.target2 = t.price + 3 * risk;
            t.holdSeconds = width >= .06 ? 300 : width >= .035 ? 900 : 1800;
            if (setup)
                t.reasons.push('Sampled breakout, later retest and recovery confirmed');
        }
        if (t.liquidity < points[0].liquidity * .8) {
            setup = false;
            t.risks.push('Liquidity has declined more than 20%');
        }
        if (t.volume5 > points.at(-2).volume5 * 1.1)
            t.reasons.push('Rolling volume accelerating');
        if (t.buys > points.at(-2).buys)
            t.reasons.push('Buy transaction count increasing');
    }
    else
        t.risks.push('Collecting at least five minutes of price observations');
    if (!fresh)
        t.risks.push('Required security evidence missing or stale');
    if (sec.danger)
        t.risks.push('Security gate failed');
    if (vr >= 1.5)
        t.reasons.push('Volume above the hourly baseline');
    if (t.liquidity >= 100000)
        t.reasons.push('Selected pool liquidity above $100k');
    if (share >= .58)
        t.reasons.push('Buy transactions outweigh sells');
    if (!t.created)
        t.risks.push('Pool age unavailable');
    else if (now - t.created < 3600)
        t.risks.push('Pool younger than one hour');
    const wash = t.volume5 / Math.max(1, t.liquidity) > 3;
    if (wash)
        t.risks.push('Abnormal volume versus liquidity');
    const safety = fresh && sec.risk !== null ? clamp(100 - sec.risk) : null, wallet = fresh && sec.concentration !== null ? clamp(100 - sec.concentration * 100) : null;
    const overall = clamp(.22 * momentum + .16 * liq + .2 * vol + .1 * (wallet || 0) + .16 * (safety || 0) + .16 * entry);
    t.scores = { Momentum: momentum, Liquidity: liq, Volume: vol, Wallet: wallet, Safety: safety, Social: null, 'Entry Quality': entry, 'Rug Risk': fresh ? sec.risk : null, Overall: overall, Risk: clamp(.55 * (fresh ? sec.risk : 100) + .25 * (100 - liq) + .2 * (100 - entry)) };
    const observed = (seconds) => { const p = points.filter((p) => p.time <= now - seconds).at(-1); return p && now - seconds - p.time <= 45 ? (t.price / p.price - 1) * 100 : null; };
    t.metrics = { 'Observed 1m change': observed(60), 'Observed 15m change': observed(900), 'Buy transaction share percent': share * 100, 'Transactions per minute': activity / 5, 'Volume versus hourly baseline': vr, 'Liquidity / cap percent': ratio === null ? null : ratio * 100 };
    t.eligible = !!(setup && fresh && !sec.danger && overall >= 78 && t.liquidity >= 100000 && ratio !== null && ratio >= .03 && t.created && now - t.created >= 1800 && activity >= 30 && share >= .58 && vr >= 1.4 && vr <= 8 && change > 0 && change <= 18 && !wash && now - t.fetched < 45 && t.stop && t.target2);
    t.status = sec.danger ? 'RUG/DANGER' : setup ? 'ENTRY APPROACHING' : enough ? 'WATCHING' : 'WAIT';
    return t;
}
function activate(t, now = time()) { return { id: randomUUID(), token: t, status: 'SIGNAL ACTIVE', recommendation: 'BUY ZONE', opened: now, expires: now + t.holdSeconds, initialExpires: now + t.holdSeconds, entry: t.price, entryLow: t.entryLow, entryHigh: t.entryHigh, reasons: [...t.reasons], stop: t.stop, target1: t.target1, target2: t.target2, confidence: t.scores.Overall, maxGain: 0, maxLoss: 0, target1Hit: false, closed: null, exit: null, closeReason: null, lastGood: t.fetched }; }
function monitor(s, t, now = time()) {
    if (s.closed)
        return [s, null];
    let event = null;
    const close = (reason, price, title) => { Object.assign(s, { closed: now, closeReason: reason, status: 'CLOSED — ' + reason, exit: price, recommendation: price === null ? 'EXIT — DATA UNAVAILABLE' : 'EXIT NOW' }); return [s, title]; };
    if (!t || now - t.fetched > 60) {
        if (now - s.lastGood >= 120)
            return close('DATA UNAVAILABLE', null, 'MONITORING LOST — EXIT');
        if (now >= s.expires)
            return close('HOLD EXPIRED', null, 'SIGNAL EXPIRED');
        s.recommendation = 'DATA DELAYED — DO NOT ENTER';
        return [s, null];
    }
    if (t.pool !== s.token.pool)
        return close('POOL CHANGED', null, 'SIGNAL INVALIDATED');
    const previous = s.token;
    s.token = t;
    s.lastGood = t.fetched;
    const gain = (t.price / s.entry - 1) * 100;
    s.maxGain = Math.max(s.maxGain, gain);
    s.maxLoss = Math.min(s.maxLoss, gain);
    if (t.security.danger || (t.security.risk !== null && previous.security.risk !== null && t.security.risk - previous.security.risk >= 20))
        return close('RUG WARNING', t.price, 'RUG WARNING — EXIT');
    if (t.liquidity < previous.liquidity * .65 || t.liquidity < 50000)
        return close('LIQUIDITY WARNING', t.price, 'LIQUIDITY WARNING — EXIT');
    if (t.price <= s.stop)
        return close('INVALIDATED', t.price, 'EXIT SIGNAL');
    if (t.price >= s.target2)
        return close('PROFIT TARGET', t.price, 'TARGET HIT — EXIT');
    if (now >= s.expires)
        return close('HOLD EXPIRED', t.price, 'SIGNAL EXPIRED');
    if (!t.security.complete || now - t.security.checked > 300)
        return close('SECURITY DATA LOST', t.price, 'SECURITY MONITORING LOST');
    if (t.sells > Math.max(15, t.buys * 1.8) && (t.change5 || 0) < -3)
        return close('MOMENTUM LOST', t.price, 'MOMENTUM LOST — EXIT');
    if (!s.target1Hit && t.price >= s.target1) {
        s.target1Hit = true;
        s.stop = Math.max(s.stop, s.entry * 1.003);
        s.recommendation = 'TAKE 50% PROFIT · INVALIDATION RAISED';
        event = 'TAKE PROFIT';
    }
    else if (t.buys < t.sells && now - s.opened > 60) {
        s.expires = Math.min(s.expires, now + 120);
        if (s.recommendation !== 'MOMENTUM WEAKENING')
            event = 'MOMENTUM WEAKENING';
        s.recommendation = 'MOMENTUM WEAKENING';
    }
    else
        s.recommendation = now - s.opened > 30 ? 'HOLD' : 'BUY ZONE';
    return [s, event];
}

function chains() { return { solana: 'solana', base: 'base', ethereum: 'eth', bsc: 'bsc' }; }
function valid(chain, address) { return (chain === 'solana' ? /^[1-9A-HJ-NP-Za-km-z]{32,44}$/ : /^0x[0-9a-fA-F]{40}$/).test(address || ''); }
class Providers {
    constructor() {
        this.health = {};
        this.next = {};
    }
    async get(url, options = {}) {
        const host = new URL(url).host;
        if ((this.next[host] || 0) - Date.now() > 1500)
            throw new Error('Provider cooling down');
        await new Promise(r => setTimeout(r, Math.max(0, (this.next[host] || 0) - Date.now())));
        this.next[host] = Date.now() + (host.includes('geckoterminal') ? 7000 : 1100);
        try {
            const r = await fetch(url, { ...options, signal: AbortSignal.timeout(9000) });
            if (r.status === 429)
                this.next[host] = Date.now() + 60000;
            if (!r.ok)
                throw new Error('HTTP ' + r.status);
            const text = await r.text();
            if (text.length > 5e6)
                throw new Error('Oversized');
            const j = JSON.parse(text);
            this.health[host] = { name: host, ok: true, at: time() };
            return j;
        }
        catch (e) {
            this.health[host] = { name: host, ok: false, at: time() };
            throw e;
        }
    }
    async discover(rotation) {
        const out = [];
        let refs = [];
        for (const path of ['token-profiles/latest/v1', 'token-boosts/top/v1'])
            try {
                const r = await this.get('https://api.dexscreener.com/' + path);
                if (Array.isArray(r))
                    refs.push(...r);
            }
            catch { }
        for (const chain of Object.keys(chains())) {
            const addresses = [...new Set(refs.filter(x => x.chainId === chain && valid(chain, x.tokenAddress)).map(x => x.tokenAddress))].slice(0, 30);
            if (!addresses.length)
                continue;
            try {
                const rows = await this.get(`https://api.dexscreener.com/tokens/v1/${chain}/${addresses.join(',')}`);
                for (const p of rows) {
                    const t = parse(p);
                    if (t)
                        out.push(t);
                }
            }
            catch { }
        }
        const chain = Object.keys(chains())[rotation % 4], kind = Math.floor(rotation / 4) % 2 ? 'new_pools' : 'trending_pools';
        try {
            const j = await this.get(`https://api.geckoterminal.com/api/v2/networks/${chains()[chain]}/${kind}?include=base_token`);
            out.push(...parseGecko(j, chain, kind === 'new_pools' ? 'New' : 'Trending'));
        }
        catch { }
        const by = new Map();
        for (const t of out)
            if (!by.has(t.id) || t.liquidity > by.get(t.id).liquidity)
                by.set(t.id, t);
        return [...by.values()];
    }
    async gecko(t) { const j = await this.get(`https://api.geckoterminal.com/api/v2/networks/${chains()[t.chain]}/pools/${t.pool}?include=base_token`); return parseGecko(j, t.chain, t.category).find(q => q.id === t.id && q.pool === t.pool) || null; }
    async quote(t) {
        try {
            const j = await this.get(`https://api.dexscreener.com/latest/dex/pairs/${t.chain}/${t.pool}`);
            const q = (j.pairs || []).map(p => parse(p, t.category)).find(q => q && q.id === t.id && q.pool === t.pool);
            if (q)
                return q;
        }
        catch { }
        try {
            return await this.gecko(t);
        }
        catch {
            return null;
        }
    }
    async rpc(method, params) { const j = await this.get(env('SOLANA_RPC_URL') || 'https://api.mainnet-beta.solana.com', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }) }); if (j.error)
        throw new Error('RPC failure'); return j.result.value; }
    async security(t) { try {
        return t.chain === 'solana' ? await this.solana(t) : await this.evm(t);
    }
    catch {
        return emptySecurity();
    } }
    async solana(t) {
        const account = await this.rpc('getAccountInfo', [t.address, { encoding: 'jsonParsed', commitment: 'confirmed' }]), info = account.data.parsed.info;
        const accounts = await this.rpc('getTokenLargestAccounts', [t.address, { commitment: 'confirmed' }]);
        const amounts = accounts.map(x => num(x.amount)), supply = num(info.supply);
        let concentration = amounts.length && amounts.every(x => x !== null && x >= 0) && supply > 0 ? amounts.reduce((a, b) => a + b, 0) / supply : null;
        if (concentration !== null && (concentration > 1.001 || concentration < 0))
            concentration = null;
        const legacy = account.owner === 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', complete = ['supply', 'mintAuthority', 'freezeAuthority'].every(k => k in info) && concentration !== null;
        const danger = !!(info.mintAuthority || info.freezeAuthority || !legacy || concentration > .5);
        return { source: 'Solana RPC', checked: time(), complete, danger, risk: danger ? 95 : complete ? Math.max(30, concentration * 100) : null, concentration, facts: { 'Mint authority': 'mintAuthority' in info ? (info.mintAuthority ? 'Enabled' : 'Revoked') : 'Unavailable', 'Freeze authority': 'freezeAuthority' in info ? (info.freezeAuthority ? 'Enabled' : 'Revoked') : 'Unavailable', 'Top 20 token accounts': concentration === null ? 'Unavailable' : (concentration * 100).toFixed(1) + '%', 'Token program': legacy ? 'Legacy SPL' : 'Unsupported / Token-2022', 'LP lock / sell simulation': 'Unavailable' }, warnings: ['Token-account concentration includes pools; it is not unique-owner concentration.', 'LP lock, sell simulation and developer attribution unavailable.'] };
    }
    async evm(t) {
        const chain = { ethereum: 1, base: 8453, bsc: 56 }[t.chain], token = env('GOPLUS_TOKEN');
        const r = await this.get(`https://api.gopluslabs.io/api/v1/token_security/${chain}?contract_addresses=${t.address}`, token ? { headers: { Authorization: 'Bearer ' + token } } : {});
        const a = r.result?.[t.address.toLowerCase()];
        if (!a)
            throw new Error('No coverage');
        const checks = ['is_honeypot', 'is_mintable', 'is_blacklisted', 'is_proxy', 'can_take_back_ownership', 'owner_change_balance', 'cannot_sell_all', 'transfer_pausable', 'slippage_modifiable', 'personal_slippage_modifiable', 'hidden_owner', 'selfdestruct', 'cannot_buy', 'anti_whale_modifiable', 'trading_cooldown'];
        const taxes = [num(a.buy_tax), num(a.sell_tax)], fractions = Array.isArray(a.holders) ? a.holders.slice(0, 10).map(x => num(x.percent)) : [];
        let concentration = fractions.length && fractions.every(x => x !== null && x >= 0 && x <= 1) ? fractions.reduce((a, b) => a + b, 0) : null;
        if (concentration > 1.001)
            concentration = null;
        const complete = checks.every(k => ['0', '1'].includes(a[k])) && a.is_open_source === '1' && taxes.every(x => x !== null && x >= 0 && x <= 1) && concentration !== null;
        const flags = checks.filter(k => a[k] === '1'), danger = !!(flags.length || taxes.some(x => x !== null && x > .03) || concentration > .5);
        const facts = Object.fromEntries(checks.map(k => [k.replaceAll('_', ' '), a[k] === '1' ? 'Detected' : a[k] === '0' ? 'Not reported' : 'Unavailable']));
        for (const k of ['buy_tax', 'sell_tax', 'holder_count', 'creator_percent', 'owner_percent', 'total_supply'])
            facts[k.replaceAll('_', ' ')] = String(a[k] ?? 'Unavailable');
        return { source: 'GoPlus', checked: time(), complete, danger, risk: danger ? 95 : complete ? Math.max(25, concentration * 100) : null, concentration, facts, warnings: [...flags.map(k => k.replaceAll('_', ' ')), 'Static checks cannot guarantee a sell. LP lock expiry and insider attribution are unverified.'] };
    }
}
function parse(p, category = 'Trending') {
    try {
        const chain = p.chainId, b = p.baseToken || {}, address = b.address || '', price = num(p.priceUsd), liquidity = num(p.liquidity?.usd);
        if (!Object.keys(chains()).includes(chain) || !valid(chain, address) || !price || price <= 0 || liquidity === null || liquidity < 0 || !/^\w{20,90}$/.test(p.pairAddress || ''))
            return null;
        if (['USDC', 'USDT', 'DAI', 'WETH', 'WBTC', 'WBNB', 'WSOL'].includes((b.symbol || '').toUpperCase()))
            return null;
        const tx = p.txns?.m5 || {}, v = p.volume || {}, change = p.priceChange || {};
        return { id: chain + ':' + (chain === 'solana' ? address : address.toLowerCase()), chain, address, pool: p.pairAddress, iconURL: typeof p.info?.imageUrl === 'string' ? p.info.imageUrl : null, name: String(b.name || 'Unknown').slice(0, 80), symbol: String(b.symbol || '?').slice(0, 24), price, liquidity, marketCap: num(p.marketCap), fdv: num(p.fdv), created: num(p.pairCreatedAt) ? Number(p.pairCreatedAt) / 1000 : null, volume5: Math.max(0, num(v.m5, 0)), volumeHour: Math.max(0, num(v.h1, 0)), buys: Math.max(0, Math.floor(num(tx.buys, 0))), sells: Math.max(0, Math.floor(num(tx.sells, 0))), change5: num(change.m5), changeHour: num(change.h1), fetched: time(), source: 'DEX Screener', category, points: [], security: emptySecurity(), metrics: {}, scores: {}, reasons: [], risks: [], unavailable: [], status: 'WAIT', entryLow: null, entryHigh: null, stop: null, target1: null, target2: null, holdSeconds: 900, eligible: false };
    }
    catch {
        return null;
    }
}
function parseGecko(data, chain, category) {
    const included = Object.fromEntries((data.included || []).map(x => [x.id, x.attributes || {}]));
    const rows = Array.isArray(data.data) ? data.data : [data.data];
    const out = [];
    for (const row of rows)
        try {
            const a = row.attributes, id = row.relationships.base_token.data.id, b = included[id] || {}, address = b.address || id.slice(id.indexOf('_') + 1);
            const t = parse({ chainId: chain, baseToken: { address, name: b.name || a.name?.split('/')[0].trim(), symbol: b.symbol || a.name?.split('/')[0].trim() }, pairAddress: a.address, info: { imageUrl: b.image_url }, priceUsd: a.base_token_price_usd, liquidity: { usd: a.reserve_in_usd }, marketCap: a.market_cap_usd, fdv: a.fdv_usd, volume: a.volume_usd, txns: a.transactions, priceChange: a.price_change_percentage, pairCreatedAt: a.pool_created_at ? Date.parse(a.pool_created_at) : null }, category);
            if (t) {
                t.source = 'GeckoTerminal';
                out.push(t);
            }
        }
        catch { }
    return out;
}

// Each foreground tick commits bounded work. A failing provider cannot discard
// another provider's earlier observations or keep a long discovery batch open.
async function cycle(s) {
 const started=time(),p=new Providers();
 s=s||{};s.active=s.active||null;s.tokens=s.tokens||[];s.history=s.history||[];
 s.rotation=s.rotation||0;s.stage=s.stage||0;s.refs=s.refs||[];s.cursor=s.cursor||0;
 p.next=s.backoff||{};p.health=s.health||{};
 const hadActive=!!s.active;
 const refreshSecurity=async(raw,previous)=>{
  const next=await p.security(raw);
  // An outage may retain a dated report, never extend its validity.
  return next.checked>0?next:previous;
 };
 const merge=(raw,security)=>{
  let prev=s.tokens.find(t=>t.id===raw.id&&t.pool===raw.pool);
  if(prev&&!security&&Math.abs(raw.price/prev.price-1)>.6)return prev;
  if(security)prev=prev?{...prev,security}:{...raw,security,points:[]};
  const t=evaluate(raw,prev,time());s.tokens=s.tokens.filter(q=>q.id!==t.id);s.tokens.push(t);return t;
 };
 const closeInterrupted=()=>{
  Object.assign(s.active,{closed:time(),closeReason:'MONITORING INTERRUPTED',status:'CLOSED — MONITORING INTERRUPTED',recommendation:'REASSESS — UNOBSERVED INTERVAL',exit:null});
  s.history.unshift(s.active);s.active=null;s.lastClosed=time();
 };
 if(s.active&&started-s.active.lastGood>90)closeInterrupted();
 let activeUpdated=false;
 if(s.active){
  const old=s.active.token;let q=await p.quote(old);
  if(q&&Math.abs(q.price/old.price-1)>.6){const check=await p.gecko(old).catch(()=>null);if(!check||Math.abs(check.price/q.price-1)>.15)q=null;}
  let t=null;
  if(q){const sec=time()-old.security.checked>120?await refreshSecurity(q,old.security):old.security;t=merge(q,sec);activeUpdated=true;}
  [s.active]=monitor(s.active,t,time());
  if(s.active.closed){s.history.unshift(s.active);s.active=null;s.lastClosed=time();}
 }
 // Discovery is one request at a time, round-robin across chains and providers.
 if(time()-started<8&&time()-(s.discoveryAttempt||0)>12){
  s.discoveryAttempt=time();const stage=s.stage++%7;
  try {
   let rows=[];
   if(stage===0||stage===6){
    const refs=await p.get('https://api.dexscreener.com/'+(stage===0?'token-profiles/latest/v1':'token-boosts/top/v1'));
    if(Array.isArray(refs))s.refs=[...s.refs,...refs].filter(r=>Object.keys(chains()).includes(r.chainId)&&valid(r.chainId,r.tokenAddress)).slice(-200);
    s.phase='Discovering tokens';
   } else if(stage<=4){
    const chain=Object.keys(chains())[stage-1];
    const addresses=[...new Set(s.refs.filter(r=>r.chainId===chain).map(r=>r.tokenAddress))].slice(-30);
    if(addresses.length){const r=await p.get(`https://api.dexscreener.com/tokens/v1/${chain}/${addresses.join(',')}`);if(Array.isArray(r))rows=r.map(q=>parse(q)).filter(Boolean);}
    s.phase='Updating '+chain+' pools';
   } else {
    const chain=Object.keys(chains())[s.rotation++%4],kind=s.rotation%2?'trending_pools':'new_pools';
    const r=await p.get(`https://api.geckoterminal.com/api/v2/networks/${chains()[chain]}/${kind}?include=base_token`);
    rows=parseGecko(r,chain,kind==='new_pools'?'New':'Trending');s.phase='Discovering '+chain+' pools';
   }
   const best=new Map();for(const t of rows)if(!best.has(t.id)||best.get(t.id).liquidity<t.liquidity)best.set(t.id,t);
   for(const raw of best.values()){
    if(raw.id===s.active?.token.id)continue;
    const prior=s.tokens.find(t=>t.id===raw.id);
    if(prior&&prior.pool!==raw.pool&&prior.liquidity>=raw.liquidity)continue;
    merge(raw);
   }
   if(rows.length)s.lastDiscovery=time();
  }catch {s.phase='Feed retry scheduled';}
 }
 if(!hadActive&&time()-started<8){
  const ranked=s.tokens.filter(t=>time()-t.fetched<660).sort((a,b)=>b.scores.Overall-a.scores.Overall).slice(0,4);
  if(ranked.length){
   const old=ranked[s.cursor++%ranked.length];let raw=await p.quote(old);
   if(raw&&Math.abs(raw.price/old.price-1)>.6){const c=await p.gecko(old).catch(()=>null);if(!c||Math.abs(c.price/raw.price-1)>.15)raw=null;}
   if(raw){
    // Save quote progress even when security is unavailable. Missing evidence blocks entry.
    const sec=time()-old.security.checked>120&&time()-started<12?await refreshSecurity(raw,old.security):old.security;
    merge(raw,sec);s.phase='Analysing '+raw.symbol;
   }
  }
 }
 s.tokens=s.tokens.filter(t=>time()-t.fetched<660).sort((a,b)=>b.scores.Overall-a.scores.Overall).slice(0,120);
 if(!hadActive&&!s.active&&time()-(s.lastClosed||0)>60){
  const candidate=s.tokens.find(t=>t.eligible&&time()-t.fetched<45&&time()-t.security.checked<180&&!s.history.some(h=>h.token.id===t.id&&time()-h.closed<1800));
  if(candidate){s.active=activate(candidate,time());s.phase='Signal locked · '+candidate.symbol;}
 }
 s.history=s.history.slice(0,200);s.backoff=p.next;s.health=p.health;
 const fresh=s.tokens.filter(t=>time()-t.fetched<90);
 s.state={serverTime:time(),live:fresh.length>0,scanned:s.tokens.length,potential:s.tokens.filter(t=>t.scores.Overall>=60).length,rejected:s.tokens.filter(t=>t.scores.Overall<60).length,active:s.active||null,candidates:s.tokens,pushConfigured:false,registeredDevices:0,lastScan:s.lastDiscovery||null,providers:Object.values(p.health)};
 if(s.active&&activeUpdated)s.phase='Monitoring '+s.active.token.symbol;
 return s;
}
function run(input){cycle(JSON.parse(input)).then(s=>nativeComplete(JSON.stringify(s),'')).catch(e=>nativeComplete('',String(e)));}
