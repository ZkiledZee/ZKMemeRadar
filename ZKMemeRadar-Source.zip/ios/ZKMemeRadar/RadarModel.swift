import SwiftUI
import UIKit

@MainActor
final class RadarModel: ObservableObject {
    @Published var state: RadarState?
    @Published var history: [Signal] = []
    @Published var selectedSignal: Signal?
    @Published var tab = 0
    @Published var error: String?
    @Published var pushStatus = "In-app alerts while scanning"
    @Published var connected = true
    @Published var loading = true
    @Published var cached = false
    @Published var lastReceived: Date?
    @Published var watchlist: Set<String> = []
    @Published var running = false
    @Published var phaseText = "Opening market feeds"
    @Published var events: [ScanEvent] = []
    @Published var lastCycleSeconds: Double = 0
    @Published var signalNotice: String?
    private var loopTask: Task<Void, Never>?
    @Published private(set) var refreshing = false
    private var revision = 0
    private let scanner = LocalScanner()
    private var snapshot: Data?
    private var storageFailed = false
    private let cacheURL = URL.applicationSupportDirectory.appendingPathComponent("radar-local-v12.json")
    private struct Saved: Decodable { let state: RadarState; let history: [Signal]; let phase: String? }
    init() {
        watchlist = Set(UserDefaults.standard.stringArray(forKey: "watchlist") ?? [])
        do {
            try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: cacheURL.path) {
                let data = try Data(contentsOf: cacheURL)
                let saved = try JSONDecoder().decode(Saved.self, from: data)
                snapshot = data; state = saved.state; history = saved.history; cached = true
            }
        } catch {
            storageFailed = true
            self.error = "Saved signal state could not be read. Scanning is paused to preserve the one-signal lock."
        }
    }
    var now: Double { Date().timeIntervalSince1970 }
    var fresh: Bool { running && !cached && error == nil && lastReceived.map { Date().timeIntervalSince($0) < 90 } == true }
    func toggleWatch(_ id: String) {
        if watchlist.contains(id) { watchlist.remove(id) } else { watchlist.insert(id) }
        UserDefaults.standard.set(Array(watchlist), forKey: "watchlist")
    }
    var statusLabel: String {
        if !running { return "PAUSED" }
        if fresh && state?.live == true { return "LIVE" }
        if error != nil { return "RETRYING" }
        return state?.candidates.isEmpty != false ? "DISCOVERING" : "UPDATING"
    }
    func log(_ text: String, symbol: String = "waveform.path") {
        if events.first?.text == text { return }
        events.insert(ScanEvent(id: UUID(), time: Date(), text: text, symbol: symbol), at: 0)
        events = Array(events.prefix(12))
    }
    func pause() {
        running = false; cached = state != nil; revision += 1
        loopTask?.cancel(); loopTask = nil
        scanner.cancel(); refreshing = false; loading = false
        phaseText = "Monitoring paused while away"
        UIApplication.shared.isIdleTimerDisabled = false
    }
    func resume() {
        guard loopTask == nil else { return }
        running = true
        UIApplication.shared.isIdleTimerDisabled = true
        loopTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self, self.running else { return }
                await self.performRefresh()
                do { try await Task.sleep(for: .seconds(self.state?.active == nil ? 3 : 2)) } catch { return }
            }
        }
    }
    // Manual refresh never owns or cancels the persistent foreground scanner.
    func refresh() async { resume() }
    private func performRefresh() async {
        guard running, !refreshing, !storageFailed else { return }
        refreshing = true
        let started = revision
        let began = Date()
        defer { if revision == started { refreshing = false; loading = false } }
        do {
            let data = try await scanner.scan(snapshot)
            guard running, revision == started, !Task.isCancelled else { return }
            let saved = try JSONDecoder().decode(Saved.self, from: data)
            // Persist the whole lifecycle atomically before showing any new entry.
            try data.write(to: cacheURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            let previous = state?.active
            snapshot = data
            withAnimation(.easeInOut(duration: 0.35)) { state = saved.state; history = saved.history }
            lastCycleSeconds = Date().timeIntervalSince(began)
            phaseText = saved.phase ?? "Scanning market"
            log(phaseText)
            cached = false; lastReceived = Date()
            error = saved.state.live || saved.state.providers.contains(where: { $0.ok && now - $0.at < 120 }) ? nil : "Market feeds are unavailable or delayed. Retrying automatically."
            if let signal = saved.state.active, previous?.id != signal.id {
                signalNotice = "Setup confirmed · " + signal.token.symbol
                selectedSignal = nil; tab = 1
                log(signalNotice!, symbol: "scope")
            } else if let old = previous, saved.state.active == nil {
                signalNotice = history.first(where: { $0.id == old.id })?.status
            }
            if previous?.id != saved.state.active?.id || previous?.recommendation != saved.state.active?.recommendation {
                UINotificationFeedbackGenerator().notificationOccurred(.warning)
            }
            if let id = selectedSignal?.id { selectedSignal = saved.state.active?.id == id ? saved.state.active : history.first { $0.id == id } }
        } catch is CancellationError { }
        catch { if revision == started { self.error = "Feed interrupted — retrying automatically. " + error.localizedDescription; phaseText = "Recovering market feed"; log("Connection retry scheduled", symbol: "arrow.clockwise"); cached = state != nil } }
    }
    func openSignal(_ id: String) async {
        guard UUID(uuidString: id) != nil else { return }
        selectedSignal = state?.active?.id == id ? state?.active : history.first { $0.id == id }
        tab = 1
    }
}

struct ScanEvent: Identifiable { let id: UUID; let time: Date; let text: String; let symbol: String }
