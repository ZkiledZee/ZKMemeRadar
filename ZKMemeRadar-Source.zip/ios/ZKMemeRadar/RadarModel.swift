import SwiftUI
import UIKit

@MainActor
final class RadarModel: ObservableObject {
    @Published var state: RadarState?
    @Published var history: [Signal] = []
    @Published var selectedSignal: Signal?
    @Published var tab = 0
    @Published var error: String?
    @Published var pushStatus = "In-app alerts while scanning"
    @Published var connected = true
    @Published var loading = true
    @Published var cached = false
    @Published var lastReceived: Date?
    @Published var watchlist: Set<String> = []
    @Published var running = true
    private var refreshing = false
    private var revision = 0
    private let scanner = LocalScanner()
    private var snapshot: Data?
    private var storageFailed = false
    private let cacheURL = URL.applicationSupportDirectory.appendingPathComponent("radar-local-v12.json")
    private struct Saved: Decodable { let state: RadarState; let history: [Signal] }
    init() {
        watchlist = Set(UserDefaults.standard.stringArray(forKey: "watchlist") ?? [])
        do {
            try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: cacheURL.path) {
                let data = try Data(contentsOf: cacheURL)
                let saved = try JSONDecoder().decode(Saved.self, from: data)
                snapshot = data; state = saved.state; history = saved.history; cached = true
            }
        } catch {
            storageFailed = true
            self.error = "Saved signal state could not be read. Scanning is paused to preserve the one-signal lock."
        }
    }
    var now: Double { Date().timeIntervalSince1970 }
    var fresh: Bool { running && !cached && error == nil && lastReceived.map { Date().timeIntervalSince($0) < 90 } == true }
    func toggleWatch(_ id: String) {
        if watchlist.contains(id) { watchlist.remove(id) } else { watchlist.insert(id) }
        UserDefaults.standard.set(Array(watchlist), forKey: "watchlist")
    }
    func pause() {
        running = false; cached = state != nil; revision += 1
        scanner.cancel(); refreshing = false
    }
    func resume() { running = true }
    func refresh() async {
        guard running, !refreshing, !storageFailed else { return }
        refreshing = true
        let started = revision
        defer { if revision == started { refreshing = false; loading = false } }
        do {
            let data = try await scanner.scan(snapshot)
            guard running, revision == started, !Task.isCancelled else { return }
            let saved = try JSONDecoder().decode(Saved.self, from: data)
            // Persist the whole lifecycle atomically before showing any new entry.
            try data.write(to: cacheURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            let previous = state?.active
            snapshot = data; state = saved.state; history = saved.history
            cached = false; lastReceived = Date()
            error = saved.state.live ? nil : "Market feeds are unavailable or delayed. Retrying automatically."
            if previous?.id != saved.state.active?.id || previous?.recommendation != saved.state.active?.recommendation {
                UINotificationFeedbackGenerator().notificationOccurred(.warning)
            }
            if let id = selectedSignal?.id { selectedSignal = saved.state.active?.id == id ? saved.state.active : history.first { $0.id == id } }
        } catch is CancellationError { }
        catch { if revision == started { self.error = "Scanner paused. Retrying automatically. " + error.localizedDescription; cached = state != nil } }
    }
    func openSignal(_ id: String) async {
        guard UUID(uuidString: id) != nil else { return }
        selectedSignal = state?.active?.id == id ? state?.active : history.first { $0.id == id }
        tab = 1
    }
}
