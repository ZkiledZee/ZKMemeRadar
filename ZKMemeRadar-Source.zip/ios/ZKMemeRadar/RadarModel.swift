import SwiftUI
import UIKit
import UserNotifications

@MainActor
final class RadarModel: ObservableObject {
    @Published var state: RadarState?
    @Published var history: [Signal] = []
    @Published var selectedSignal: Signal?
    @Published var tab = 0
    @Published var error: String?
    @Published var pushStatus = "Not registered"
    @Published var connected = false
    @Published var loading = false
    @Published var cached = false
    @Published var lastReceived: Date?
    @Published var watchlist: Set<String> = []
    var serverOffset: Double = 0
    private var api: API?
    private var registeredToken: String?
    private var generation = 0
    private let cacheURL = URL.cachesDirectory.appendingPathComponent("radar-state.json")
    init() {
        watchlist = Set(UserDefaults.standard.stringArray(forKey: "watchlist") ?? [])
        if let address = Vault.read("url"), let url = API.validURL(address), let token = Vault.read("token") {
            api = API(base: url, bearer: token); connected = true
            if let data = try? Data(contentsOf: cacheURL), let saved = try? JSONDecoder().decode(RadarState.self, from: data) { state = saved; cached = true }
        }
    }
    var now: Double { Date().timeIntervalSince1970 + serverOffset }
    var fresh: Bool { !cached && error == nil && lastReceived.map { Date().timeIntervalSince($0) < 35 } == true }
    func toggleWatch(_ id: String) {
        if watchlist.contains(id) { watchlist.remove(id) } else { watchlist.insert(id) }
        UserDefaults.standard.set(Array(watchlist), forKey: "watchlist")
    }
    func pair(address: String, code: String) async {
        guard let url = API.validURL(address) else { error = "Enter the HTTPS server address, without a path."; return }
        loading = true; defer { loading = false }
        do {
            struct PairResponse: Decodable { let token: String }
            let client = API(base: url, bearer: "")
            let data = try await client.request("v1/pair", method: "POST", body: JSONEncoder().encode(["code": code]))
            let reply = try JSONDecoder().decode(PairResponse.self, from: data)
            try Vault.write(url.absoluteString, key: "url"); try Vault.write(reply.token, key: "token")
            api = API(base: url, bearer: reply.token); generation += 1; connected = true; error = nil
            await refresh(); await enablePush()
        } catch { self.error = error.localizedDescription }
    }
    func refresh() async {
        guard let api else { return }
        let version = generation
        do {
            let next: RadarState = try await api.get("v1/state")
            guard generation == version else { return }
            let prior = state?.active?.id
            serverOffset = next.serverTime - Date().timeIntervalSince1970
            state = next; lastReceived = Date(); error = nil; cached = false
            if next.active?.id != prior, next.active != nil { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
            if let data = try? JSONEncoder().encode(next) { try? data.write(to: cacheURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]) }
            if let selected = selectedSignal, next.active?.id != selected.id {
                let updated: Signal = try await api.get("v1/signals/\(selected.id)")
                guard generation == version else { return }
                selectedSignal = updated
            }
            await registerDevice()
            if let pending = PushDelegate.pendingSignal { await openSignal(pending) }
        } catch { if generation == version { self.error = error.localizedDescription } }
    }
    func loadHistory() async {
        guard let api else { return }
        do { history = try await api.get("v1/history") } catch { self.error = error.localizedDescription }
    }
    func openSignal(_ id: String) async {
        guard UUID(uuidString: id) != nil else { return }
        tab = 1
        guard let api else { return }
        do {
            selectedSignal = try await api.get("v1/signals/\(id)")
            PushDelegate.pendingSignal = nil
        } catch { self.error = error.localizedDescription }
    }
    func enablePush() async {
        guard PushDelegate.enabled else { pushStatus = "Push requires the Apple-signed build"; return }
        do {
            let allowed = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
            pushStatus = allowed ? "Registering with Apple…" : "Notifications disabled in iPhone Settings"
            if allowed { UIApplication.shared.registerForRemoteNotifications() }
        } catch { pushStatus = error.localizedDescription }
    }
    func registerDevice() async {
        if let message = PushDelegate.registrationError { pushStatus = message; return }
        guard let token = PushDelegate.deviceToken, let api, registeredToken != token else { return }
        do {
            let environment = (Bundle.main.object(forInfoDictionaryKey: "RadarAPNSEnvironment") as? String) ?? "production"
            _ = try await api.request("v1/devices", method: "POST", body: JSONEncoder().encode(["token": token, "environment": environment == "development" ? "sandbox" : "production"]))
            registeredToken = token; pushStatus = "Device registered"
        } catch { pushStatus = "Registration failed — will retry" }
    }
    func disconnect() async {
        if let api, let token = registeredToken { _ = try? await api.request("v1/devices/\(token)", method: "DELETE") }
        generation += 1; api = nil; connected = false; state = nil; history = []; selectedSignal = nil; registeredToken = nil; cached = false; error = nil
        try? Vault.write(nil, key: "url"); try? Vault.write(nil, key: "token"); try? FileManager.default.removeItem(at: cacheURL)
    }
}
