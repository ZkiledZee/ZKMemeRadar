import XCTest
import JavaScriptCore
@testable import ZKMemeRadar

final class ContractTests: XCTestCase {
    @MainActor
    func testBundledEngineLoadsInJavaScriptCore() throws {
        let url = try XCTUnwrap(Bundle.main.url(forResource: "Scanner", withExtension: "js"))
        let context = try XCTUnwrap(JSContext())
        context.evaluateScript(try String(contentsOf: url, encoding: .utf8))
        XCTAssertNil(context.exception)
        XCTAssertEqual(context.evaluateScript("typeof cycle")?.toString(), "function")
        XCTAssertEqual(context.evaluateScript("typeof evaluate")?.toString(), "function")
        XCTAssertEqual(context.evaluateScript("emptySecurity().complete")?.toBool(), false)
    }
    func testBackendContractAndNullableScores() throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "state", withExtension: "json"))
        let data = try Data(contentsOf: url)
        let state = try JSONDecoder().decode(RadarState.self, from: data)
        let signal = try XCTUnwrap(state.active)
        XCTAssertEqual(signal.token.symbol, "TEST")
        XCTAssertNil(signal.token.score("Social"))
        XCTAssertGreaterThan(signal.target2, signal.target1)
        XCTAssertGreaterThan(signal.entry, signal.stop)
        XCTAssertLessThan(signal.entryLow, signal.entryHigh)
        XCTAssertGreaterThan(signal.expires, signal.opened)
        XCTAssertNil(signal.closed)
        XCTAssertFalse(signal.token.points.isEmpty)
        let roundtrip = try JSONEncoder().encode(state)
        XCTAssertEqual(try JSONDecoder().decode(RadarState.self, from: roundtrip).active?.id, signal.id)
    }
    func testSafeServerURL() {
        XCTAssertNotNil(API.validURL("https://radar.example.org"))
        XCTAssertNil(API.validURL("http://radar.example.org"))
        XCTAssertNil(API.validURL("https://name:secret@radar.example.org"))
        XCTAssertNil(API.validURL("https://radar.example.org/wrong/path"))
        XCTAssertNil(API.validURL("https://radar.example.org?token=secret"))
    }
    func testPricePrecisionAndUnavailableValues() {
        XCTAssertEqual(price(nil), "Unavailable")
        XCTAssertEqual(price(.nan), "Unavailable")
        XCTAssertNotEqual(price(0.00000000012), "$0.00")
        XCTAssertEqual(price(0), "$0")
    }
}
