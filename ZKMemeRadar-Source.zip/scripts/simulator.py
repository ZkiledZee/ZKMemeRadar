import json, subprocess
r=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','--json']))
for runtime,devices in sorted(r['devices'].items(),reverse=True):
    if 'iOS' in runtime:
        for d in devices:
            if d['name'].startswith('iPhone') and d.get('isAvailable'):
                print(d['udid']); raise SystemExit(0)
raise SystemExit('No available iPhone simulator')
