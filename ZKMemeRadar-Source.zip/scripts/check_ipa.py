import plistlib, sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None, 'Corrupt archive'
    root='Payload/ZKMemeRadar.app/'
    info=plistlib.loads(z.read(root+'Info.plist'))
    assert info['CFBundlePackageType']=='APPL'
    assert root+info['CFBundleExecutable'] in z.namelist(), 'Missing executable'
    assert info['CFBundleIdentifier'], 'Missing bundle identifier'
    assert root+'Assets.car' in z.namelist(), 'Missing compiled app assets'
    print('IPA structure verified:',info['CFBundleIdentifier'],info['CFBundleShortVersionString'])
