"""Only runs on GitHub macOS. Never prints signing material."""
import base64, datetime, os, pathlib, plistlib, secrets, subprocess

def run(args): return subprocess.check_output(args,stderr=subprocess.STDOUT)
temp=pathlib.Path(os.environ['RUNNER_TEMP']); build=pathlib.Path('build'); build.mkdir(exist_ok=True)
for var in ['CERTIFICATE_BASE64','CERTIFICATE_PASSWORD','PROFILE_BASE64']:
    if not os.getenv(var): raise SystemExit(f'Missing GitHub secret for {var}')
cert=temp/'radar.p12'; profile=temp/'radar.mobileprovision'; keychain=temp/'radar-signing.keychain-db'
cert.write_bytes(base64.b64decode(os.environ['CERTIFICATE_BASE64'],validate=True)); profile.write_bytes(base64.b64decode(os.environ['PROFILE_BASE64'],validate=True))
info=plistlib.loads(run(['security','cms','-D','-i',str(profile)]))
ent=info['Entitlements']; team=info['TeamIdentifier'][0]; bundle=os.environ['BUNDLE_ID']
if ent.get('aps-environment')!='production': raise SystemExit('Use a distribution provisioning profile with production APNs enabled.')
if ent.get('application-identifier')!=team+'.'+bundle: raise SystemExit('Profile bundle ID does not match IOS_BUNDLE_ID.')
if not info.get('ProvisionedDevices'): raise SystemExit('Use an Ad Hoc profile containing your iPhone UDID.')
if info['ExpirationDate']<datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None): raise SystemExit('Provisioning profile expired.')
password=secrets.token_urlsafe(32)
run(['security','create-keychain','-p',password,str(keychain)])
run(['security','set-keychain-settings','-lut','21600',str(keychain)])
run(['security','unlock-keychain','-p',password,str(keychain)])
run(['security','import',str(cert),'-P',os.environ['CERTIFICATE_PASSWORD'],'-A','-t','cert','-f','pkcs12','-k',str(keychain)])
run(['security','set-key-partition-list','-S','apple-tool:,apple:,codesign:','-s','-k',password,str(keychain)])
run(['security','list-keychains','-d','user','-s',str(keychain)])
dest=pathlib.Path.home()/'Library/MobileDevice/Provisioning Profiles'; dest.mkdir(parents=True,exist_ok=True)
(dest/'radar.mobileprovision').write_bytes(profile.read_bytes())
with open(os.environ['GITHUB_ENV'],'a') as f: f.write(f'SIGNING_TEAM={team}\nPROFILE_UUID={info["UUID"]}\n')
with open(build/'ExportOptions.plist','wb') as f:
    plistlib.dump({'method':'release-testing','teamID':team,'signingStyle':'manual','signingCertificate':'Apple Distribution','provisioningProfiles':{bundle:info['UUID']},'stripSwiftSymbols':True,'manageAppVersionAndBuildNumber':False},f)
cert.unlink(); profile.unlink()
