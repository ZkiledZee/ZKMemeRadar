# ZK Meme Radar 1.3 — resilient foreground scanner

Upload `ZKMemeRadar-Source.zip` to the root of your existing GitHub repository, replacing the older ZIP. Keep the exact filename and your current fast `.github/workflows/build.yml`. Download the new IPA from the completed Actions run and install it over the previous app.

No Netlify, server address, pairing code, wallet or API key is required by this build. The native SwiftUI app calls public DEX Screener and GeckoTerminal endpoints directly and runs its bundled deterministic scoring engine on your iPhone through JavaScriptCore. Only data is downloaded; executable scanner code is bundled in the app.

## Behaviour

- Opens into real token discovery, with token images where available, charts, radar, analysis and local watchlist.
- Prioritises Solana, Base, Ethereum and BNB. Trending/profile feeds contain tokens beyond meme coins; they are discovery candidates, not verified meme classifications.
- Waits for at least five minutes and sufficient samples before an entry can qualify. Public-feed coverage is partial; counts are actual unique observed tokens.
- Requires fresh available security checks (GoPlus or Solana RPC); missing evidence blocks signals. Whale flows, developer attribution, social evidence, pool sell simulations and rug probabilities are explicitly unavailable.
- Keeps one active signal, monitors it before other candidates, records observed exits and applies cooldowns before the next signal.
- Saves state and history atomically on this phone before displaying a new entry. Keeps 200 closed observations. There is no shared cloud history in this version.
- Scans while open, with adaptive request pacing, provider fallback and bounded timeouts. Uses in-app updates and haptics for signal changes.
- Pauses when the app becomes inactive. On return after more than 90 seconds without monitoring, closes the interrupted observation without inventing an exit price. No trades or orders are executed.

**Keep the app open to scan.** This version does not provide continuous scanning or market alerts when closed, backgrounded or screen-locked. Native remote push has no backend in this mode, regardless of signing.

## Build and checks

The fast workflow compiles the iPhone target and packages `ZKMemeRadar.ipa`; simulator tests remain optional. Packaging validates that `Scanner.js` and app assets are present. iOS 17 or later.

Local checks: 10 model tests and 11 app-only orchestration/bridge tests passed. Swift syntax and project files were inspected. Updated Swift typechecking, JavaScriptCore integration and physical-device network access still require the GitHub Xcode build/device check. Public API smoke requests from the development environment returned HTTP 403 / Cloudflare 1010, so a live feed check from this environment could not be completed. The app handles provider rejection as unavailable data rather than fabricated results.

## Development

Version 1.3 changes: the foreground loop is owned by the app model rather than refreshable views. Manual refresh cannot cancel it. Discovery runs as small saved steps; one failing provider does not discard earlier progress. Rate-limit cooldowns persist between steps and fail fast instead of blocking for a minute. The active signal is checked first; the four leading candidates receive focused observation sampling. Temporary security outages may retain the original dated report but never extend its validity. Expired evidence continues to block signals and terminate monitoring when required.

The dashboard now includes a compact animated radar, real sparklines, entry-readiness counts, scanner activity and candidate cards. Market includes search and chain filters. Qualifying signals open their detail screen automatically with evidence. The screen stays awake while scanning and restores normal locking when the app becomes inactive. External outages still cannot be prevented; automatic retry does not mean prices remain live during an outage.

`ios/` is the app. `mobile-engine/` contains the local orchestration and bridge generator; the generated scanner is already included, so the IPA build needs no Node installation. To regenerate after editing the shared engine: run `npm ci` inside `cloud/`, then `node mobile-engine/build.cjs` from the project root. Test with `node --test mobile-engine/test.cjs` and, inside `cloud/`, `node --test tests/model.mts`.

`cloud/` and `backend/` are retained as alternative implementations for a future always-on version; neither is used by this IPA. The earlier Netlify deployment was blocked by account credits and remains inactive.

Scores are heuristics, not calibrated win or rug probabilities. Stops are displayed observations, not exchange orders. Liquidity, tax, slippage and gaps can make prices unachievable.

Signals are algorithmic market observations and not guaranteed outcomes. Meme coins are highly speculative and can rapidly lose their entire value.
