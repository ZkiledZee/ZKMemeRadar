# ZK Meme Radar — V1

Native SwiftUI iPhone client + independently running cloud scanner. One active signal globally, persistent SQLite state, deterministic entry/exit model, durable APNs delivery queue, and GitHub Actions IPA builds.

**This is a runnable V1 source release, not a claim of validated trading performance or completed production certification.** No server has been deployed by creating this ZIP. No fake signals or historical returns ship in the production app. See [verification](docs/VERIFICATION.md) for exactly what was tested.

## Build your IPA on GitHub

1. Upload `ZKMemeRadar-Source.zip` to your GitHub repository root. Do not extract it or rename it.
2. Add the separately supplied workflow as `.github/workflows/build.yml` (GitHub: Add file → Create new file → enter that full path → paste the contents of build.yml → Commit changes).
3. GitHub automatically runs Build IPA on either file changing. You can also use Actions → Build IPA → Run workflow.
4. Leave the Apple-signed option off for the usual unsigned sideload build.
5. Download ZKMemeRadar-IPA from the completed run's Artifacts. Extract that artifact download to obtain ZKMemeRadar.ipa.

The workflow unpacks the source ZIP on GitHub, creates the Xcode project, compiles/tests the app and packages the IPA. You do not need to upload the individual source folders.

Building the IPA does not deploy the cloud scanner. Backend deployment and push-enabled signing are explained in README.md and docs/APPLE-PUSH.md. The default unsigned build needs sideload signing and does not provide native APNs capability.

31 backend tests passed in source preparation. Xcode compilation still takes place on GitHub, not in the packaging environment.

## Make the scanner live

Deploy the backend once on an **always-on Linux host with Docker Compose and a persistent volume**, and configure a domain pointing to it. A sleeping/free web service or GitHub Actions job is not an always-on scanner.

```bash
cp .env.example .env
openssl rand -hex 16
```

Put the generated value in `PAIRING_CODE`, and set `RADAR_DOMAIN` to your domain. Leave optional provider/APNs fields empty initially. Create the secret mount directory:

```bash
mkdir -p secrets
docker compose up -d --build
docker compose logs --tail=100 radar
```

Open TCP 80/443 to Caddy, point your domain's DNS to the host, and allow outbound HTTPS to market providers, Solana RPC and APNs. Caddy manages HTTPS certificates. Do not expose port 8000 publicly.

On your iPhone, open Connection and enter `https://your-domain` and your pairing code once. This is deployment pairing, not trading settings. There are no strategy settings to choose and no wallet/private key to supply. The server issues a bearer credential stored in the iOS Keychain; provider keys never enter Swift source.

The app will initially show zero signals and warm up using real observations. It can remain without an active signal for long periods. Provider failure or incomplete security checks can legitimately leave it in watching mode indefinitely. Do not loosen gates simply to force signals.

Detailed [deployment, backups and recovery](docs/OPERATIONS.md).

## What V1 does

- Discovers public profile/boost candidates through DEX Screener and rotating new/trending pools through GeckoTerminal across Solana, Base, Ethereum and BNB Chain. Common stable/wrapped-native symbols are excluded. This is a bounded speculative-token discovery universe, **not an exhaustive or authoritative meme-token classification**. Paid boosts supply discovery only, never social confidence.
- Deduplicates token identities and selects the deepest observed pool. EVM addresses normalize to lowercase; Solana addresses preserve case. Active monitoring pins the original pool.
- Uses 5m/1h price changes, rolling volume, transaction counts, selected-pool liquidity, market cap/FDV, pool age, sampled price structure and supported security/concentration checks.
- Records sampled observations and derives 1m/15m changes once enough timestamped history exists. It does not fabricate candles or reconstruct predeployment history.
- Requires a sampled breakout/retest/recovery, adequate activity/liquidity, favourable gross target distance, fresh security coverage and a score of at least 78/100.
- Locks to one active coin in a transactional database constraint. Continues discovery without releasing another actionable coin.
- Monitors for first target, raised invalidation, second target, stop, severe liquidity loss, security danger, sell dominance, expiry and monitoring loss. Hold estimates can shorten as momentum deteriorates.
- Persists lifecycle, countdown deadline, observed high/low excursions, entry/exit references and notification events. Restart does not reset the lock or timer.
- Queues selected-coin notifications; retries temporary APNs failures, removes invalid device tokens and expires obsolete entry alerts. Deep links resolve the specific signal, including a closed signal when opened later.
- Offers Home, Signal, Radar, Market, token analysis, Watchlist and History with dark styling, charts, score wheel, efficient radar animation, haptics, reduced-motion support and visible offline/cached state.

## Honest limits

**Scores are heuristics, not probabilities.** “Confidence 85/100” does not mean an 85% win rate. “Rug risk 30/100” does not mean a 30% rug probability. The latter probability is explicitly unavailable. There is no trained model, backtested edge or guaranteed return.

V1 implements **one entry pattern: sampled breakout + retest + recovery**. It does not pretend to implement every market-structure strategy in the brief. Expected holds are 5, 15 or 30 minutes based on observed volatility, with earlier closure; they are not statistically fitted forecasts. Targets are 2R/3R before taxes, gas and slippage. Short-period data from public APIs may lag. Stops and “take 50%” are observations; no orders are submitted and no portfolio is tracked.

Wallet analysis is concentration evidence only: GoPlus's returned EVM holder list, or Solana's top token accounts (which may include pools and are not distinct beneficial owners). Missing holder evidence blocks new signals. Solana legacy SPL mint/freeze checks are supported; Token-2022 is rejected conservatively. Solana LP-lock and sell simulation are unavailable. EVM LP facts are displayed when returned but lock duration and pool-specific coverage are not certified. Unavailable evidence is never treated as a clean security check.

Unique buyers/sellers, dollar buy/sell volume, developer/insider identity, bundled wallets, whale/profitable-wallet flows, live social statistics and calibrated rug probabilities are unavailable in this V1. The Whale Activity section explicitly says so. Developer selling cannot trigger an attributed alert without that evidence; price/liquidity/security deterioration can still trigger an exit.

Continuous scanning is independent of iPhone state. **Notification receipt is best effort, not guaranteed when force-quit or offline.** Apple controls delivery and app execution. Alert pushes are used; the system does not fake an iOS background worker. Open the app once after installation, grant permission, and perform the real device tests in [APPLE-PUSH.md](docs/APPLE-PUSH.md).

## Repository

| Path | Purpose |
|---|---|
| `ios/ZKMemeRadar` | SwiftUI app, MVVM state, network client, Keychain, notifications, assets |
| `ios/ZKMemeRadarTests` | Contract/URL/format tests; test-only synthetic JSON |
| `ios/project.yml` | XcodeGen project and schemes |
| `backend/radar/providers.py` | Market/security adapters, pacing, normalization |
| `backend/radar/engine.py` | Deterministic scoring and lifecycle |
| `backend/radar/store.py` | SQLite state, single-active constraint, durable outbox |
| `backend/radar/scanner.py` | Independent discovery, candidate and active loops |
| `backend/radar/push.py` | JWT-authenticated APNs HTTP/2 delivery |
| `backend/radar/api.py` | Pairing, authentication, state, history and device API |
| `.github/workflows/build.yml` | Simulator tests and signed/unsigned IPA artifacts |
| `.github/workflows/backend.yml` | Backend tests and Docker build |

## Tests

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements-dev.txt
PYTHONPATH=backend python -m pytest backend/tests -q
```

On a Mac with Xcode and XcodeGen:

```bash
cd ios
xcodegen generate
open ZKMemeRadar.xcodeproj
```

Select the ZKMemeRadar scheme and an iPhone simulator, then Product → Test. The workflow runs this automatically before creating the IPA.

## Provider and platform references

- [DEX Screener API](https://docs.dexscreener.com/api/reference)
- [GeckoTerminal API](https://apiguide.geckoterminal.com/)
- [GoPlus field definitions](https://docs.gopluslabs.io/reference/response-details)
- [Solana getAccountInfo](https://solana.com/docs/rpc/http/getaccountinfo)
- [Solana getTokenLargestAccounts](https://solana.com/docs/rpc/http/gettokenlargestaccounts)
- [APNs registration](https://developer.apple.com/documentation/usernotifications/registering-your-app-with-apns)
- [APNs token authentication](https://developer.apple.com/documentation/usernotifications/establishing-a-token-based-connection-to-apns)
- [Apple remote notification lifecycle guidance](https://developer.apple.com/library/archive/documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/HandlingRemoteNotifications.html)

Signals are algorithmic market observations and not guaranteed outcomes. Meme coins are highly speculative and can rapidly lose their entire value.
