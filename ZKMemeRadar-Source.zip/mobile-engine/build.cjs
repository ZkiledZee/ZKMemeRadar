const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const ts=require(path.join(root,'cloud/node_modules/typescript'));
let code=fs.readFileSync(path.join(__dirname,'bridge.js'),'utf8');
for(const name of ['model','providers']){
 let source=fs.readFileSync(path.join(root,'cloud/netlify/functions/_shared',name+'.mts'),'utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
 code+='\n'+ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.None}}).outputText;
}
code+='\n'+fs.readFileSync(path.join(__dirname,'cycle.js'),'utf8');
fs.writeFileSync(path.join(root,'ios/ZKMemeRadar/Scanner.js'),code);
