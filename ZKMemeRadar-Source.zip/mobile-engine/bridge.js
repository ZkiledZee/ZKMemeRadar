const env=()=>'';
const randomUUID=()=>nativeUUID();
class URL { constructor(value){this.host=String(value).split('/')[2];} }
const AbortSignal={timeout:()=>undefined};
function setTimeout(fn,delay){nativeDelay(Math.max(0,Math.min(60000,delay)),fn);}
function fetch(url,options={}) {return new Promise((resolve,reject)=>{
 nativeRequest(String(url),JSON.stringify(options),(body,status,error)=>{
  if(error){reject(new Error(error));return;}
  resolve({ok:status>=200&&status<300,status,text:async()=>body});
 });
});}
