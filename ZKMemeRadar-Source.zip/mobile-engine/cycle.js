// Each foreground tick commits bounded work. A failing provider cannot discard
// another provider's earlier observations or keep a long discovery batch open.
async function cycle(s) {
 const started=time(),p=new Providers();
 s=s||{};s.active=s.active||null;s.tokens=s.tokens||[];s.history=s.history||[];
 s.rotation=s.rotation||0;s.stage=s.stage||0;s.refs=s.refs||[];s.cursor=s.cursor||0;
 p.next=s.backoff||{};p.health=s.health||{};
 const hadActive=!!s.active;
 const refreshSecurity=async(raw,previous)=>{
  const next=await p.security(raw);
  // An outage may retain a dated report, never extend its validity.
  return next.checked>0?next:previous;
 };
 const merge=(raw,security)=>{
  let prev=s.tokens.find(t=>t.id===raw.id&&t.pool===raw.pool);
  if(prev&&!security&&Math.abs(raw.price/prev.price-1)>.6)return prev;
  if(security)prev=prev?{...prev,security}:{...raw,security,points:[]};
  const t=evaluate(raw,prev,time());s.tokens=s.tokens.filter(q=>q.id!==t.id);s.tokens.push(t);return t;
 };
 const closeInterrupted=()=>{
  Object.assign(s.active,{closed:time(),closeReason:'MONITORING INTERRUPTED',status:'CLOSED — MONITORING INTERRUPTED',recommendation:'REASSESS — UNOBSERVED INTERVAL',exit:null});
  s.history.unshift(s.active);s.active=null;s.lastClosed=time();
 };
 if(s.active&&started-s.active.lastGood>90)closeInterrupted();
 let activeUpdated=false;
 if(s.active){
  const old=s.active.token;let q=await p.quote(old);
  if(q&&Math.abs(q.price/old.price-1)>.6){const check=await p.gecko(old).catch(()=>null);if(!check||Math.abs(check.price/q.price-1)>.15)q=null;}
  let t=null;
  if(q){const sec=time()-old.security.checked>120?await refreshSecurity(q,old.security):old.security;t=merge(q,sec);activeUpdated=true;}
  [s.active]=monitor(s.active,t,time());
  if(s.active.closed){s.history.unshift(s.active);s.active=null;s.lastClosed=time();}
 }
 // Discovery is one request at a time, round-robin across chains and providers.
 if(time()-started<8&&time()-(s.discoveryAttempt||0)>12){
  s.discoveryAttempt=time();const stage=s.stage++%7;
  try {
   let rows=[];
   if(stage===0||stage===6){
    const refs=await p.get('https://api.dexscreener.com/'+(stage===0?'token-profiles/latest/v1':'token-boosts/top/v1'));
    if(Array.isArray(refs))s.refs=[...s.refs,...refs].filter(r=>Object.keys(chains()).includes(r.chainId)&&valid(r.chainId,r.tokenAddress)).slice(-200);
    s.phase='Discovering tokens';
   } else if(stage<=4){
    const chain=Object.keys(chains())[stage-1];
    const addresses=[...new Set(s.refs.filter(r=>r.chainId===chain).map(r=>r.tokenAddress))].slice(-30);
    if(addresses.length){const r=await p.get(`https://api.dexscreener.com/tokens/v1/${chain}/${addresses.join(',')}`);if(Array.isArray(r))rows=r.map(q=>parse(q)).filter(Boolean);}
    s.phase='Updating '+chain+' pools';
   } else {
    const chain=Object.keys(chains())[s.rotation++%4],kind=s.rotation%2?'trending_pools':'new_pools';
    const r=await p.get(`https://api.geckoterminal.com/api/v2/networks/${chains()[chain]}/${kind}?include=base_token`);
    rows=parseGecko(r,chain,kind==='new_pools'?'New':'Trending');s.phase='Discovering '+chain+' pools';
   }
   const best=new Map();for(const t of rows)if(!best.has(t.id)||best.get(t.id).liquidity<t.liquidity)best.set(t.id,t);
   for(const raw of best.values()){
    if(raw.id===s.active?.token.id)continue;
    const prior=s.tokens.find(t=>t.id===raw.id);
    if(prior&&prior.pool!==raw.pool&&prior.liquidity>=raw.liquidity)continue;
    merge(raw);
   }
   if(rows.length)s.lastDiscovery=time();
  }catch {s.phase='Feed retry scheduled';}
 }
 if(!hadActive&&time()-started<8){
  const ranked=s.tokens.filter(t=>time()-t.fetched<660).sort((a,b)=>b.scores.Overall-a.scores.Overall).slice(0,4);
  if(ranked.length){
   const old=ranked[s.cursor++%ranked.length];let raw=await p.quote(old);
   if(raw&&Math.abs(raw.price/old.price-1)>.6){const c=await p.gecko(old).catch(()=>null);if(!c||Math.abs(c.price/raw.price-1)>.15)raw=null;}
   if(raw){
    // Save quote progress even when security is unavailable. Missing evidence blocks entry.
    const sec=time()-old.security.checked>120&&time()-started<12?await refreshSecurity(raw,old.security):old.security;
    merge(raw,sec);s.phase='Analysing '+raw.symbol;
   }
  }
 }
 s.tokens=s.tokens.filter(t=>time()-t.fetched<660).sort((a,b)=>b.scores.Overall-a.scores.Overall).slice(0,120);
 if(!hadActive&&!s.active&&time()-(s.lastClosed||0)>60){
  const candidate=s.tokens.find(t=>t.eligible&&time()-t.fetched<45&&time()-t.security.checked<180&&!s.history.some(h=>h.token.id===t.id&&time()-h.closed<1800));
  if(candidate){s.active=activate(candidate,time());s.phase='Signal locked · '+candidate.symbol;}
 }
 s.history=s.history.slice(0,200);s.backoff=p.next;s.health=p.health;
 const fresh=s.tokens.filter(t=>time()-t.fetched<90);
 s.state={serverTime:time(),live:fresh.length>0,scanned:s.tokens.length,potential:s.tokens.filter(t=>t.scores.Overall>=60).length,rejected:s.tokens.filter(t=>t.scores.Overall<60).length,active:s.active||null,candidates:s.tokens,pushConfigured:false,registeredDevices:0,lastScan:s.lastDiscovery||null,providers:Object.values(p.health)};
 if(s.active&&activeUpdated)s.phase='Monitoring '+s.active.token.symbol;
 return s;
}
function run(input){cycle(JSON.parse(input)).then(s=>nativeComplete(JSON.stringify(s),'')).catch(e=>nativeComplete('',String(e)));}
