// Bundled deterministic engine. No remote code execution or generated signals.
async function cycle(s) {
 const now=time(), p=new Providers();
 s=s||{};s.active=s.active||null;s.tokens=s.tokens||[];s.history=s.history||[];s.rotation=s.rotation||0;
 const starting=s.tokens.length===0;
 let hadActive=!!s.active;
 if(s.active&&now-s.active.lastGood>90){
  Object.assign(s.active,{closed:now,closeReason:'MONITORING INTERRUPTED',status:'CLOSED — MONITORING INTERRUPTED',recommendation:'REASSESS — UNOBSERVED INTERVAL',exit:null});
  s.history.unshift(s.active);s.active=null;s.lastClosed=now;
 }
 const merge=(raw,security)=>{
  let prev=s.tokens.find(t=>t.id===raw.id);
  if(prev&&prev.pool!==raw.pool){prev=null;}
  if(security){prev=prev?{...prev,security}:{...raw,security,points:[]};}
  if(prev&&!security&&Math.abs(raw.price/prev.price-1)>.6)return prev;
  const t=evaluate(raw,prev,time());
  s.tokens=s.tokens.filter(q=>q.id!==t.id);s.tokens.push(t);return t;
 };
 if(s.active){
  const old=s.active.token;let q=await p.quote(old);
  if(q&&Math.abs(q.price/old.price-1)>.6){const confirm=await p.gecko(old).catch(()=>null);if(!confirm||Math.abs(confirm.price/q.price-1)>.15)q=null;}
  let t=null;
  if(q){const sec=time()-old.security.checked>90?await p.security(q):old.security;t=merge(q,sec);}
  [s.active]=monitor(s.active,t,time());
  if(s.active.closed){s.history.unshift(s.active);s.active=null;s.lastClosed=time();}
 }
 if(now-(s.lastDiscovery||0)>180||s.tokens.length===0){
  const rows=await p.discover(s.rotation++);
  if(rows.length){for(const raw of rows){if(raw.id!==s.active?.token.id)merge(raw);}s.lastDiscovery=time();}
 }
 const ranked=s.tokens.filter(t=>time()-t.fetched<660&&t.id!==s.active?.token.id).sort((a,b)=>b.scores.Overall-a.scores.Overall).slice(0,16);
 const index=s.cursor||0;
 for(let i=0;i<Math.min(starting?0:3,ranked.length);i++){
  const old=ranked[(index+i)%ranked.length];let raw=await p.quote(old);if(!raw)continue;
  if(Math.abs(raw.price/old.price-1)>.6){const confirm=await p.gecko(old).catch(()=>null);if(!confirm||Math.abs(confirm.price/raw.price-1)>.15)continue;}
  const sec=time()-old.security.checked>120?await p.security(raw):old.security;merge(raw,sec);
 }
 s.cursor=index+3;
 s.tokens=s.tokens.filter(t=>time()-t.fetched<660).sort((a,b)=>b.scores.Overall-a.scores.Overall).slice(0,120);
 if(!hadActive&&!s.active&&time()-(s.lastClosed||0)>60){
  const candidate=s.tokens.find(t=>t.eligible&&time()-t.fetched<45&&time()-t.security.checked<180&&!s.history.some(h=>h.token.id===t.id&&time()-h.closed<1800));
  if(candidate)s.active=activate(candidate,time());
 }
 s.history=s.history.slice(0,200);
 const providers=Object.values(p.health),fresh=s.tokens.filter(t=>time()-t.fetched<90);
 s.state={serverTime:time(),live:fresh.length>0,scanned:s.tokens.length,potential:s.tokens.filter(t=>t.scores.Overall>=60).length,rejected:s.tokens.filter(t=>t.scores.Overall<60).length,active:s.active||null,candidates:s.tokens,pushConfigured:false,registeredDevices:0,lastScan:s.lastDiscovery||null,providers};
 return s;
}
function run(input){cycle(JSON.parse(input)).then(s=>nativeComplete(JSON.stringify(s),'')).catch(e=>nativeComplete('',String(e)));}
