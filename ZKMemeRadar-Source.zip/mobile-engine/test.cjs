const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const fixture=JSON.parse(fs.readFileSync(path.join(root,'ios/ZKMemeRadarTests/state.json')));
function engine(){const ctx=vm.createContext({nativeUUID:()=>require('node:crypto').randomUUID(),nativeDelay:(ms,cb)=>setTimeout(cb,0),nativeRequest:()=>{throw Error('Network must be explicitly stubbed in tests');}});vm.runInContext(fs.readFileSync(path.join(root,'ios/ZKMemeRadar/Scanner.js'),'utf8'),ctx);ctx.clock=fixture.serverTime;vm.runInContext('time=()=>clock',ctx);return ctx;}
function ready(ctx){const now=ctx.clock,t=structuredClone(fixture.active.token),offset=now-fixture.serverTime;t.fetched+=offset;t.created+=offset;t.security.checked+=offset;t.points.forEach(p=>p.time+=offset);ctx.input=t;return vm.runInContext('evaluate(input,input)',ctx);}
function offline(ctx){vm.runInContext('Providers.prototype.discover=async()=>[];Providers.prototype.quote=async()=>null;Providers.prototype.security=async()=>emptySecurity();',ctx);}
test('bundled model preserves validated entry and nullable scores',()=>{const c=engine(),t=ready(c);assert.equal(t.eligible,true);assert.equal(t.scores.Social,null);});
test('one active signal survives serialized restart; no new signal on missing quote',async()=>{const c=engine();offline(c);c.t=ready(c);c.s=vm.runInContext('({tokens:[t],active:activate(t),history:[],lastDiscovery:time()})',c);const id=c.s.active.id;c.s=JSON.parse(JSON.stringify(c.s));const result=await vm.runInContext('cycle(s)',c);assert.equal(result.active.id,id);assert.equal(result.active.recommendation,'DATA DELAYED — DO NOT ENTER');assert.equal(result.history.length,0);});
test('resume after gap closes unpriced and does not replace immediately',async()=>{const c=engine();offline(c);c.t=ready(c);c.s=vm.runInContext('({tokens:[t],active:activate(t),history:[],lastDiscovery:time()})',c);c.s.active.lastGood-=100;const r=await vm.runInContext('cycle(s)',c);assert.equal(r.active,null);assert.equal(r.history.length,1);assert.equal(r.history[0].exit,null);assert.equal(r.history[0].closeReason,'MONITORING INTERRUPTED');});
test('missing feeds return honest non-live empty state',async()=>{const c=engine();offline(c);const r=await vm.runInContext('cycle({})',c);assert.equal(r.state.live,false);assert.equal(r.state.scanned,0);assert.equal(r.state.active,null);});
test('unknown security never activates a candidate',async()=>{const c=engine();offline(c);c.t=ready(c);vm.runInContext('t.security=emptySecurity();t=evaluate(t,t)',c);c.s={tokens:[c.t],history:[],lastDiscovery:c.clock};const r=await vm.runInContext('cycle(s)',c);assert.equal(r.active,null);});
test('bridged fetch parses HTTP response data',async()=>{const c=engine();c.nativeRequest=(url,opts,cb)=>cb('{"pairs":[]}',200,'');const r=await vm.runInContext('new Providers().get("https://api.dexscreener.com/latest/dex/pairs/solana/test")',c);assert.equal(r.pairs.length,0);});
test('malformed, negative and unsupported token quotes are rejected',()=>{const c=engine();for(const p of [{},{chainId:'unknown'},{chainId:'solana',priceUsd:-1}]){c.p=p;assert.equal(vm.runInContext('parse(p)',c),null);}});
test('rate-limited host fails fast and its cooldown survives the next tick',async()=>{
 const c=engine();let calls=0;c.nativeRequest=(url,opts,cb)=>{calls++;cb('{}',429,'');};
 vm.runInContext('provider=new Providers()',c);
 await assert.rejects(vm.runInContext('provider.get("https://api.dexscreener.com/token-profiles/latest/v1")',c));
 vm.runInContext('nextProvider=new Providers();nextProvider.next=JSON.parse(JSON.stringify(provider.next))',c);
 await assert.rejects(vm.runInContext('nextProvider.get("https://api.dexscreener.com/token-profiles/latest/v1")',c),/cooling down/);
 assert.equal(calls,1);
});
test('failed discovery preserves observations; following quote recovers without reinstall',async()=>{
 const c=engine();offline(c);c.t=ready(c);c.s={tokens:[c.t],history:[],stage:0};
 let r=await vm.runInContext('cycle(s)',c);assert.equal(r.tokens.length,1);assert.ok(r.state.candidates.length);
 c.s=r;c.clock+=15;c.q=structuredClone(c.t);c.q.fetched=c.clock;c.q.price*=1.0001;
 vm.runInContext('Providers.prototype.quote=async()=>q',c);
 r=await vm.runInContext('cycle(s)',c);assert.equal(r.state.live,true);assert.equal(r.tokens[0].fetched,c.clock);
});
test('discovery step commits profiles independently of later token fetches',async()=>{
 const c=engine();offline(c);c.reference={chainId:fixture.active.token.chain,tokenAddress:fixture.active.token.address};
 vm.runInContext('Providers.prototype.get=async()=>[reference]',c);
 const r=await vm.runInContext('cycle({})',c);assert.equal(r.stage,1);assert.equal(r.refs.length,1);assert.equal(r.state.active,null);
});
test('temporary security outage retains its original timestamp and expiry',async()=>{
 const c=engine();offline(c);c.t=ready(c);c.t.security.checked=c.clock-130;c.s={tokens:[c.t],active:vm.runInContext('activate(t)',c),history:[],discoveryAttempt:c.clock};
 c.q=structuredClone(c.t);c.q.fetched=c.clock;
 vm.runInContext('Providers.prototype.quote=async()=>q',c);
 const r=await vm.runInContext('cycle(s)',c);
 assert.equal(r.active.token.security.checked,c.clock-130);
 assert.equal(r.active.closed,null);
 c.s=r;c.clock+=180;c.q.fetched=c.clock;c.s.active.lastGood=c.clock-10;
 const expired=await vm.runInContext('cycle(s)',c);
 assert.equal(expired.active,null);assert.equal(expired.history[0].closeReason,'SECURITY DATA LOST');
});
