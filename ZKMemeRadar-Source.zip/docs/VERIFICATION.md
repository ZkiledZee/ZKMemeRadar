# V1 verification record

This record separates checks actually run during source preparation from deployment checks that still require your infrastructure. This source package must not be represented as a tested profitable system or as already deployed.

## Completed

- **31 backend tests passed**, covering selective entry, security freshness, missing security, liquidity/age/volume/overextension gates, warm-up, migration, chronological breakout/retest, concurrent single-signal activation, restart-safe deadlines, atomic notification enqueueing, TP1/trailing invalidation, TP2, stop, rug/security/liquidity exits, momentum exits, timer shortening, unpriced outage closure, malformed prices, pool deduplication, invalid holder data, APNs retry/obsolete-entry suppression, API authentication, pairing rate limits, device validation/removal, missing signal and liveness failure.
- Python compilation passed for backend and build/admin scripts.
- All **nine Swift source files** passed a Swift grammar parser. This checks syntax only; it does not typecheck Apple framework calls.
- Info.plist, push entitlements and privacy manifest parsed successfully.
- XcodeGen, Compose and both GitHub workflow YAML files parsed successfully.
- Shared test-only backend JSON is included in the iOS test bundle, and XCTest verifies decoding of nullable factor scores and lifecycle fields.
- Real public endpoint requests returned HTTP 200 from DEX Screener and GeckoTerminal. A follow-up adapter smoke check normalized **21 DEX candidates and 20 Gecko pools**, obtained a matching pinned-pool DEX quote, and parsed a GoPlus security response. The observed EVM response lacked all required fields, so the security gate correctly remained incomplete. These were read-only smoke checks; no market signal or phone notification was generated.
- Production code starts with an empty database and contains no test-coin results. Synthetic fixtures are confined to `backend/tests` and `ios/ZKMemeRadarTests`.

## Not run in this environment

- **Xcode compilation, simulator XCTest execution, iOS UI rendering and IPA creation.** This environment does not have macOS/Xcode. The GitHub Build IPA workflow performs compilation and simulator tests and refuses to upload an IPA if they fail. Source parsing is not a substitute for compilation.
- Apple certificate/profile import, signed export, installation, APNs registration, push delivery and notification deep linking on a physical iPhone. These require your Apple signing assets and device.
- Docker image/Compose execution, domain/TLS provisioning, host restarts, production backup restoration, and a 24-hour provider/latency soak test.
- Full live Solana RPC security coverage across multiple tokens and long-lived provider quota behaviour.
- Independent security audit, live execution/slippage simulation, historical strategy validation, calibrated probabilities, profitability or an App Store submission review.

## Required before relying on a live installation

1. Pass the GitHub iOS and backend workflows. Keep their results as the actual build record.
2. Deploy on a persistent always-on host, pair the app, and verify health/provider freshness.
3. Restart the backend while a real signal is active; confirm the same signal ID/deadline is restored and no second active coin appears.
4. Validate APNs with the explicitly labelled connection test and actual signed iPhone build.
5. Confirm foreground/background/locked/force-quit behaviour and stale-data presentation on that device.
6. Observe the scanner without committing funds first. Review real outcomes, missing-data rates, timing and executable liquidity. V1's thresholds are engineering defaults, not evidence of an edge.
