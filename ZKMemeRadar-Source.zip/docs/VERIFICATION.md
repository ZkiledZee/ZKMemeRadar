# Version 1.2 verification

- Shared deterministic model: 10 tests passed.
- Bundled JavaScript engine: 7 tests passed, including serialization/restart, one-signal lock, monitoring-gap closure, outage state, missing security, native-fetch callback shape and malformed token rejection.
- Swift syntax parsed; native typechecking and JavaScriptCore execution await Xcode on GitHub. Optional simulator tests include bundled JavaScriptCore loading.
- IPA packaging now requires the bundled Scanner.js resource.
- Info.plist, entitlements, app icon assets, project resources and archive structure checked.
- Live API smoke requests from this development environment were rejected with Cloudflare HTTP 403 / error 1010. Live-device connectivity is not verified; no successful end-to-end data check is claimed.
- No cloud service or APNs dependency in the app-only build. Historical backend deployment records describe an unused alternative.
