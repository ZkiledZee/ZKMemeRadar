# Deployment and operation

## Supported topology

One always-on Linux Docker Compose deployment, one backend process, one local persistent SQLite volume, one owner (optionally several of that owner's devices). The signal lock is global for this personal installation. Run **one replica and one Uvicorn worker**. A file lock refuses a second process sharing the database; a partial unique index and immediate transactions prevent concurrent signal creation.

This is not a multitenant hosted service. Do not scale replicas onto separate volumes: they would hold independent signal engines. Do not put SQLite on an unreliable network filesystem. Use a PostgreSQL/advisory-lock redesign before horizontal scaling.

## Scheduling and quotas

| Work | Default pacing |
|---|---|
| DEX profile/boost discovery | Approximately every 5 minutes, up to 30 addresses per chain per token batch |
| Gecko discovery | One network/new-or-trending endpoint per broad cycle; full rotation about 40 minutes |
| Higher-ranked candidates | Top 12, cycle pause 30 seconds plus request time |
| Active coin | Target every 10 seconds including request time; network failures may lengthen it |
| Security | Refresh around 2 minutes for ranked/active coins |
| Gecko HTTP requests | At least 7 seconds apart, including fallback |
| Other provider requests | At least 1.1 seconds apart per host |
| 429 response | Respect numeric Retry-After with a 30–300 second bounded cooldown |

Discovery, candidate work and active monitoring run independently. Shared provider pacing prevents simultaneous bursts. Missing data is retried on the next cycle with alternate price providers. Public endpoints can still rate-limit shared hosts; supply a dedicated Solana RPC URL if needed. `GOPLUS_TOKEN` is optional and must be a valid provider-issued bearer credential when set.

Public price payloads do not supply exchange tick timestamps consistently. `fetched` means “received observation at”, not an assurance the upstream price changed this second. Price charts are sampled and have no made-up predeployment data.

## Entry model

Model version: 1.0.0 in `engine.py`. Weighted score:

| Component | Weight |
|---|---:|
| Momentum | 22% |
| Selected-pool liquidity | 16% |
| Rolling volume/activity | 20% |
| Wallet concentration evidence | 10% |
| Supported security evidence | 16% |
| Entry structure | 16% |

Social has no contribution without data. Missing components do not renormalize the remaining weights. Eligibility additionally requires: score ≥78, selected-pool liquidity ≥$100k, liquidity/cap ratio ≥3%, pool age ≥30 minutes, ≥30 transactions/5m, buy share ≥58%, rolling 5m volume 1.4–8 times the hourly average five-minute volume, a positive 5m change ≤18%, fresh required security fields, and a confirmed sampled breakout/retest/recovery.

History must include ≥10 observations spanning ≥5 minutes. A prior sampled high forms resistance; recent samples must break it, touch the retest band and recover inside the narrow entry zone. The implementation is deliberately conservative but not a backtested strategy.

A source-matched pool is pinned while active. Price moves >45% during active monitoring require cross-provider agreement; unexplained discontinuities become a monitoring outage rather than a fabricated exit. Large candidate moves are independently checked before eligibility. Pool migrations reset candidate history. Never combine migrated pools into a continuous chart.

## Lifecycle

Activation persists entry zone, original reasons, targets, initial expiry, current expiry and selected token. TP1 advises a 50% reduction and raises invalidation above the reference entry. TP2 closes the observation. Weakening buy/sell balance shortens the remaining hold to at most two minutes; it never extends indefinitely. Severe sell dominance, security danger, liquidity loss, stop or expiry closes the lifecycle.

If price cannot be verified for two minutes, close **DATA UNAVAILABLE**, with a null exit and no invented return. Max gain/loss are sampled observations relative to entry, not tick extrema, executable fills or realized P&L. The UI labels them accordingly. After closure, wait 60 seconds globally and 30 minutes before reselecting the same token.

## Health and logs

- `GET /healthz`: public liveness; HTTP 503 if scanner heartbeat is >90 seconds old. Docker reports health; this alone does not prove every provider works.
- Authenticated `/v1/state`: scanner freshness, last discovery, per-provider status, counts and device-registration count.
- `docker compose logs --tail=100 radar`: structured timestamps and exception categories; credentials/device URLs are not logged by HTTPX.
- Docker `restart: unless-stopped` restarts exited processes. Docker does not automatically restart solely because health turns unhealthy. Configure your host's monitoring to alert on health failure.

Store retention: candidate rows expire after 24 hours; chart points retain up to 2 hours/480 observations; API lists recent candidates; device rows expire after 90 days without refresh; notification records retain 7 days. Signal history stays in SQLite; the app shows the most recent 200 closed signals.

## Backup, restore and session revocation

Create a consistent SQLite backup with the running container:

```bash
docker compose exec radar python -m radar.admin backup /data/radar-backup.sqlite3
```

Copy the backup from the container/volume into your encrypted host backup system. Do not copy only the live SQLite file while ignoring its WAL. To restore, stop the service, replace the database from a verified backup, ensure UID 10001 owns it, remove obsolete WAL/SHM files for the replaced database, and start the service. A retained active signal is resumed or expired; restoring an older backup can replay an older lifecycle, so review its timestamp before enabling alerts.

To revoke all paired devices after credential exposure:

```bash
docker compose exec radar python -m radar.admin revoke
```

This rotates the stored bearer credential and deletes device tokens/pending deliveries. Also change `PAIRING_CODE` and restart the container. Re-pair the phone. Back up the data volume before host migration. Never use `docker compose down -v` unless intentionally deleting all state.

## API

| Method | Route | Authentication | Result |
|---|---|---|---|
| POST | `/v1/pair` | Long server pairing code; rate limited | Device bearer session |
| GET | `/healthz` | None | Liveness only |
| GET | `/v1/state` | Bearer | Current state + candidates + health |
| GET | `/v1/history` | Bearer | Most recent 200 closures |
| GET | `/v1/signals/{uuid}` | Bearer | Exact current/historical signal |
| POST | `/v1/devices` | Bearer | Token/environment registration |
| DELETE | `/v1/devices/{token}` | Bearer | Device removal |

Pairing payload: `{"code":"your-long-pairing-code"}`. Device payload: `{"token":"APNs hex token","environment":"production"}`. Authenticated requests use `Authorization: Bearer …`. All responses disable caching. Caddy caps request bodies to 4KB. Production app connections require HTTPS and reject credentials embedded in URLs.

## Push delivery semantics

A signal state change and its event are committed in one SQLite transaction. A persistent per-device delivery row retries errors with exponential backoff. APNs IDs are stable across retries; collapse IDs group one signal. Delivery is **at least once/best effort**, not exactly once. New-entry notifications become obsolete after 60 seconds or closure. Other alerts expire after five minutes. Invalid device tokens are removed. A crashed server resumes pending work from the database.

## Adding providers/chains

Implement the `MarketProvider` protocol and normalize into `Token`. Preserve missing fields as null, chain-qualified identity, verified pool identity and observation timestamps. Add supported chain identifiers to `CHAINS`, provider chain mappings, address validation and security coverage. Do not permit a new chain to emit signals before implementing and testing its required security gates. Raw data/scoring remain authoritative if an optional explanatory LLM is added later.
