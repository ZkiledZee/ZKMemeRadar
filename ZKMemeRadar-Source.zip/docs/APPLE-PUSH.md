# Apple signing and remote alerts

The cloud scanner does not need the phone to run. Sending a native iOS alert requires APNs credentials **and a correctly signed app installed on the registered device**. Creating an IPA alone cannot create these credentials.

## Required assets

1. Apple Developer Program access with an explicit App ID for `com.zk.memeradar` (or your own unique bundle ID) and **Push Notifications** enabled.
2. Your iPhone's UDID registered in the developer account.
3. An Apple Distribution certificate and its private key, exported as a password-protected `.p12`.
4. An **Ad Hoc distribution provisioning profile** for that App ID, certificate and iPhone. It must include `aps-environment=production`.
5. An APNs signing key `.p8`, Key ID and Team ID. This signing key belongs on the server only, never in the app.

## GitHub configuration

Repository → Settings → Secrets and variables → Actions.

| Secret | Value |
|---|---|
| `IOS_CERTIFICATE_P12_BASE64` | Base64 contents of the distribution `.p12` |
| `IOS_CERTIFICATE_PASSWORD` | Its export password |
| `IOS_PROFILE_BASE64` | Base64 contents of the Ad Hoc `.mobileprovision` |

If you use a different bundle identifier, add repository **variable** `IOS_BUNDLE_ID`. Also set the server `APNS_TOPIC` to exactly the same identifier. It must match the Apple App ID and profile.

Create base64 values locally and paste into GitHub Secrets; do not commit them. On macOS:

```bash
base64 -i Distribution.p12 | pbcopy
base64 -i Radar.mobileprovision | pbcopy
```

Run **Build IPA** with **Apple-signed IPA with push** enabled. The workflow validates profile expiry, app identifier, production APNs entitlement and registered devices, imports the certificate into an ephemeral keychain, archives and exports using `release-testing` (Ad Hoc), then removes signing assets.

Install the signed IPA onto the registered iPhone using a method that preserves its Ad Hoc signing (for example Apple Configurator on a Mac). Re-signing it with a free account can remove required entitlements. Do not assume that a sideload tool preserves push capability.

## Server configuration

Copy the APNs key to `secrets/AuthKey.p8` on the server. Allow container UID 10001 to read it without making the key public. Set in `.env`:

```dotenv
APNS_KEY_ID=your-key-id
APNS_TEAM_ID=your-team-id
APNS_TOPIC=com.zk.memeradar
APNS_KEY_PATH=/run/secrets/AuthKey.p8
```

Apply with `docker compose up -d`. The key signs short-lived ES256 provider JWTs. A device registers the APNs environment corresponding to the build. The included signed workflow is production/Ad Hoc; development builds must use both a development profile and `APS_ENVIRONMENT=development`.

## Device acceptance test

1. Launch the correctly signed app, connect your backend, and allow notifications.
2. Connection should say **Device registered**, and APNs server credentials should be configured. A configured key alone does not prove delivery.
3. Use `docker compose exec radar python -m radar.admin test-push` to send a clearly labelled connection test. This does not create a signal or bypass entry gates.
4. Verify delivery with the app open, in the background, and with the screen locked.
5. Test force-quit separately on the actual installed iOS version. The server still scans, but iOS may suppress delivery/app callbacks; no code can guarantee it.
6. Once a genuine signal occurs, tapping its notification should open that signal. If it has already closed, the historical closed lifecycle should appear rather than a new buy recommendation.
7. Disconnect the phone to remove its registered token. For lost devices, rotate all sessions using the administration command.

APNs can delay, collapse or drop notifications. Focus, disabled permissions, expired provisioning, revoked keys, network failure and force-quit state can all affect the experience. Never use notification delivery as a guaranteed stop-loss mechanism.
