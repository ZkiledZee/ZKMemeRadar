# Deployment handoff — prepared, not yet live

Dedicated Netlify project: zk-meme-radar
Project ID: 7df22206-0f43-46eb-a269-715e11a15bac
App API origin: https://zk-meme-radar.netlify.app
Upload/build root: cloud/
Build: npm ci, then npm run build
Publish: public/
Functions: netlify/functions/
Database migrations: netlify/database/migrations/

The worker credential is configured as a Netlify secret environment variable. It is not embedded in Swift or included in this source. Deploy using the authenticated Netlify integration. Do not copy credentials from tool output into source.

The user explicitly approved source upload and deployment. Source upload succeeded on 2026-09-12, but Netlify skipped deployment 6aa4ad5bcfe1373db1f65116 because account credit usage was exceeded. No build or database migration ran. Restore available credits on the existing account before retrying; do not create another account or project to evade this limit.

After credits are restored: redeploy the cloud project, inspect build/database migration results, confirm the production deployment, then verify health, automatic installation/session acquisition, state decoding and independent scheduled heartbeat advances. Verify the single-active constraint and durable state. The deployment is not complete until those checks pass.

APNs environment keys: APNS_TEAM_ID, APNS_KEY_ID, APNS_PRIVATE_KEY, APNS_TOPIC. These are not supplied by this package. Do not invent Apple credentials or claim remote push is working without signing and a real-device check.
