# Upload one ZIP and one workflow

1. Upload `ZKMemeRadar-Source.zip` to your GitHub repository root. Do not extract it or rename it.
2. Add the separately supplied workflow as `.github/workflows/build.yml` (GitHub: Add file → Create new file → enter that full path → paste the contents of build.yml → Commit changes).
3. GitHub automatically runs Build IPA on either file changing. You can also use Actions → Build IPA → Run workflow.
4. Leave the Apple-signed option off for the usual unsigned sideload build.
5. Download ZKMemeRadar-IPA from the completed run's Artifacts. Extract that artifact download to obtain ZKMemeRadar.ipa.

The workflow unpacks the source ZIP on GitHub, creates the Xcode project, compiles/tests the app and packages the IPA. You do not need to upload the individual source folders.

Building the IPA does not deploy the cloud scanner. Backend deployment and push-enabled signing are explained in README.md and docs/APPLE-PUSH.md. The default unsigned build needs sideload signing and does not provide native APNs capability.

31 backend tests passed in source preparation. Xcode compilation still takes place on GitHub, not in the packaging environment.
