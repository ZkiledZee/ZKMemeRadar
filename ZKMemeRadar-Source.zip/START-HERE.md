# Install the app-only update

1. Upload this ZIP as `ZKMemeRadar-Source.zip` to your existing GitHub repository root, replacing the old ZIP. Do not extract or rename it.
2. Keep the existing fast `.github/workflows/build.yml`.
3. Download `ZKMemeRadar.ipa` from the successful Actions run and install it through your usual signing method.
4. Open the app with internet access. It requests live feeds automatically. No connection details are needed.

Keep the app open for scanning. Signals require price-history warmup and available security data; candidate listings are not buy recommendations. This version does not monitor or send market alerts while closed or locked.
