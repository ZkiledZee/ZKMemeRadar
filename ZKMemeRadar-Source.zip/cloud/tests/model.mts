import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {evaluate,activate,monitor} from '../netlify/functions/_shared/model.mts';
const fixture=JSON.parse(readFileSync('../ios/ZKMemeRadarTests/state.json','utf8'));
const now=fixture.serverTime;
function ready(){const t=structuredClone(fixture.active.token);return evaluate(t,t,now);}
test('selective fixture passes and nullable factors remain unknown',()=>{const t=ready();assert.equal(t.eligible,true);assert.equal(t.scores.Social,null);assert.ok(t.entryLow<t.price&&t.entryHigh>t.price);});
test('missing security blocks entries',()=>{const t=ready();t.security.complete=false;assert.equal(evaluate(t,t,now).eligible,false);});
test('missing market cap and FDV blocks entries',()=>{const t=ready();t.marketCap=null;t.fdv=null;assert.equal(evaluate(t,t,now).eligible,false);});
test('thin liquidity and vertical pumps rejected',()=>{for(const data of [{liquidity:9000},{change5:50}]){const t=Object.assign(ready(),data);assert.equal(evaluate(t,t,now).eligible,false);}});
test('first target raises stop and second closes',()=>{let s=activate(ready(),now),q=structuredClone(s.token);q.price=s.target1;q.fetched=now+10;let event;[s,event]=monitor(s,q,now+10);assert.equal(event,'TAKE PROFIT');assert.ok(s.stop>s.entry);q=structuredClone(q);q.price=s.target2;q.fetched=now+20;[s,event]=monitor(s,q,now+20);assert.equal(s.closeReason,'PROFIT TARGET');});
test('outage never invents a fill',()=>{let s=activate(ready(),now);[s]=monitor(s,null,now+121);assert.equal(s.closeReason,'DATA UNAVAILABLE');assert.equal(s.exit,null);});
test('restart restores deadline',()=>{let s=JSON.parse(JSON.stringify(activate(ready(),now)));const q=structuredClone(s.token);q.fetched=s.expires+1;q.security.checked=q.fetched;[s]=monitor(s,q,q.fetched);assert.equal(s.closeReason,'HOLD EXPIRED');});
test('later retest required',()=>{const t=ready();t.points=t.points.filter(p=>p.time<now-90);for(let i=0;i<4;i++)t.points.push({time:now-90+i*30,price:1.004+i*.002,liquidity:400000,volume5:40000,buys:100,sells:30});t.price=1.010;assert.equal(evaluate(t,t,now).eligible,false);});
test('migrated pool resets history',()=>{const t=ready(),old=structuredClone(t);old.pool='different';assert.equal(evaluate(t,old,now).eligible,false);assert.equal(t.points.length,1);});
test('danger and liquidity exits',()=>{for(const reason of ['RUG WARNING','LIQUIDITY WARNING']){let s=activate(ready(),now);const q=structuredClone(s.token);q.fetched=now+10;if(reason==='RUG WARNING')q.security.danger=true;else q.liquidity=100;[s]=monitor(s,q,now+10);assert.equal(s.closeReason,reason);}});
