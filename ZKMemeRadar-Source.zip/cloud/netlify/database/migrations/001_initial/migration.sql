CREATE TABLE IF NOT EXISTS radar_state (id integer PRIMARY KEY CHECK(id=1), body jsonb NOT NULL DEFAULT '{"tokens":[],"active":null,"heartbeat":0,"discovered":0,"providers":[]}', owner text, lease_until timestamptz);
INSERT INTO radar_state(id) VALUES(1) ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS radar_signals(id text PRIMARY KEY, body jsonb NOT NULL, closed double precision);
CREATE UNIQUE INDEX IF NOT EXISTS radar_one_active ON radar_signals((1)) WHERE closed IS NULL;
CREATE TABLE IF NOT EXISTS radar_clients(id text PRIMARY KEY, credential_hash text UNIQUE NOT NULL, device_token text, environment text, updated timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS radar_limits(key text PRIMARY KEY, hits integer NOT NULL, expires timestamptz NOT NULL);
CREATE TABLE IF NOT EXISTS radar_events(id text PRIMARY KEY, signal_id text NOT NULL, title text NOT NULL, body text NOT NULL, created double precision NOT NULL);
CREATE TABLE IF NOT EXISTS radar_delivery(event text NOT NULL, client text NOT NULL, attempts integer NOT NULL DEFAULT 0, retry_at timestamptz NOT NULL DEFAULT now(), delivered timestamptz, PRIMARY KEY(event,client));
