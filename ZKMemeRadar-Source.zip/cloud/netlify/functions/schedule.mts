import type {Config} from '@netlify/functions';
import {env} from './_shared/db.mts';
export default async()=>{
 const url=env('URL');if(!url||!env('RADAR_WORKER_KEY'))throw new Error('Scanner deployment not configured');
 const r=await fetch(url+'/.netlify/functions/scan-background',{method:'POST',headers:{'x-radar-worker':env('RADAR_WORKER_KEY')},signal:AbortSignal.timeout(12000)});
 if(!r.ok)throw new Error('Scanner start rejected: '+r.status);
};
export const config:Config={schedule:'* * * * *'};
