import type {Config,Context} from '@netlify/functions';
import {randomUUID} from 'node:crypto';
import {db,response,authorized,limit,secret,hash} from './_shared/db.mts';
import {time} from './_shared/model.mts';
import {pushReady} from './_shared/push.mts';
export default async(req:Request,context:Context)=>{
 try{
  const path=new URL(req.url).pathname;
  if(path==='/healthz'){const r=await db().query('SELECT body FROM radar_state WHERE id=1');const s=r.rows[0]?.body;return response({status:s&&time()-s.heartbeat<120?'live':'starting',heartbeat:s?.heartbeat||0},s&&time()-s.heartbeat<120?200:503);}
  if(Number(req.headers.get('content-length')||0)>4096)return response({error:'Request too large'},413);
  if(path==='/v1/install'&&req.method==='POST'){
   if(!await limit('install:'+context.ip,6))return response({error:'Please retry shortly'},429);
   const token=secret(),id=randomUUID();await db().query('INSERT INTO radar_clients(id,credential_hash) VALUES($1,$2)',[id,hash(token)]);return response({token});
  }
  const client=await authorized(req);if(!client)return response({error:'Session expired'},401);
  if(path==='/v1/state'&&req.method==='GET'){
   const r=await db().query('SELECT body FROM radar_state WHERE id=1');const s=r.rows[0]?.body||{},tokens=(s.tokens||[]).filter(t=>time()-t.fetched<660),potential=tokens.filter(t=>t.scores.Overall>=60).length;
   return response({serverTime:time(),live:time()-(s.heartbeat||0)<100&&time()-(s.discovered||0)<660&&s.discoveryOK===true,scanned:tokens.length,potential,rejected:tokens.length-potential,active:s.active||null,candidates:tokens.slice(0,60),pushConfigured:pushReady(),registeredDevices:client.device_token?1:0,lastScan:s.discovered||null,providers:s.providers||[]});
  }
  if(path==='/v1/history'&&req.method==='GET'){const r=await db().query('SELECT body FROM radar_signals WHERE closed IS NOT NULL ORDER BY closed DESC LIMIT 200');return response(r.rows.map(x=>x.body));}
  if(path.startsWith('/v1/signals/')&&req.method==='GET'){const r=await db().query('SELECT body FROM radar_signals WHERE id=$1',[path.split('/').at(-1)]);return r.rows.length?response(r.rows[0].body):response({error:'Signal not found'},404);}
  if(path==='/v1/devices'&&req.method==='POST'){
   const raw=await req.text();if(raw.length>4096)return response({error:'Too large'},413);const data=JSON.parse(raw);
   if(!/^[a-fA-F0-9]{64,200}$/.test(data.token)||!['production','sandbox'].includes(data.environment))return response({error:'Invalid device token'},422);
   await db().query('UPDATE radar_clients SET device_token=$2,environment=$3,updated=now() WHERE id=$1',[client.id,data.token.toLowerCase(),data.environment]);return new Response(null,{status:204});
  }
  if(path.startsWith('/v1/devices/')&&req.method==='DELETE'){await db().query('UPDATE radar_clients SET device_token=NULL,updated=now() WHERE id=$1',[client.id]);return new Response(null,{status:204});}
  return response({error:'Not found'},404);
 }catch(e){console.error('Radar API request failed',e instanceof Error?e.message:'unknown');return response({error:'Scanner service temporarily unavailable'},503);}
};
export const config:Config={path:['/healthz','/v1/install','/v1/state','/v1/history','/v1/signals/:id','/v1/devices','/v1/devices/:token']};
