import {connect} from 'node:http2';
import {sign,randomUUID} from 'node:crypto';
import {db,env} from './db.mts';
import {time} from './model.mts';
export function pushReady(){return ['APNS_TEAM_ID','APNS_KEY_ID','APNS_PRIVATE_KEY','APNS_TOPIC'].every(k=>!!env(k));}
function jwt(){const b=(v:any)=>Buffer.from(JSON.stringify(v)).toString('base64url');const unsigned=b({alg:'ES256',kid:env('APNS_KEY_ID')})+'.'+b({iss:env('APNS_TEAM_ID'),iat:Math.floor(time())});return unsigned+'.'+sign('sha256',Buffer.from(unsigned),{key:env('APNS_PRIVATE_KEY').replaceAll('\\n','\n'),dsaEncoding:'ieee-p1363'}).toString('base64url');}
async function send(row:any,s:any){
 const host=row.environment==='sandbox'?'https://api.sandbox.push.apple.com':'https://api.push.apple.com';
 return await new Promise<{status:number,reason:string}>((resolve,reject)=>{
  const client=connect(host);const timer=setTimeout(()=>{client.destroy();reject(new Error('APNs timeout'));},8000);
  client.on('error',e=>{clearTimeout(timer);client.destroy();reject(e);});
  const request=client.request({':method':'POST',':path':'/3/device/'+row.device_token,'authorization':'bearer '+jwt(),'apns-topic':env('APNS_TOPIC'),'apns-push-type':'alert','apns-priority':'10','apns-expiration':String(Math.floor(row.created+300)),'apns-collapse-id':s.id,'apns-id':row.event});let status=0,body='';
  request.on('response',h=>{status=Number(h[':status']);});request.on('data',d=>{body+=d;});request.on('error',reject);request.on('end',()=>{clearTimeout(timer);client.close();let reason='';try{reason=JSON.parse(body).reason||'';}catch{}resolve({status,reason});});
  request.end(JSON.stringify({aps:{alert:{title:row.title,body:row.body},sound:'default','thread-id':s.id},signalId:s.id}));
 });
}
export async function flushPush(){
 if(!pushReady())return;const rows=await db().query('SELECT d.*,e.signal_id,e.title,e.body,e.created,c.device_token,c.environment,s.body AS signal FROM radar_delivery d JOIN radar_events e ON e.id=d.event JOIN radar_clients c ON c.id=d.client JOIN radar_signals s ON s.id=e.signal_id WHERE d.delivered IS NULL AND d.attempts<8 AND d.retry_at<now() AND c.device_token IS NOT NULL ORDER BY e.created LIMIT 10');
 for(const r of rows.rows){const s=r.signal;let done=time()-r.created>300||(r.title==='NEW MEME SIGNAL'&&(s.closed||time()-s.opened>60||s.recommendation!=='BUY ZONE'||s.token.price<s.entryLow||s.token.price>s.entryHigh))||(s.closed&&['TAKE PROFIT','MOMENTUM WEAKENING'].includes(r.title));
  if(!done)try{const reply=await send(r,s);done=reply.status===200;if(reply.status===410||['BadDeviceToken','DeviceTokenNotForTopic'].includes(reply.reason)){await db().query('UPDATE radar_clients SET device_token=NULL WHERE id=$1',[r.client]);done=true;}}catch{console.warn('APNs delivery will retry');}
  await db().query("UPDATE radar_delivery SET attempts=attempts+1,retry_at=now()+($3::integer*interval '1 second'),delivered=CASE WHEN $4 THEN now() ELSE NULL END WHERE event=$1 AND client=$2",[r.event,r.client,Math.min(300,2**(r.attempts+2)),!!done]);
 }
}
