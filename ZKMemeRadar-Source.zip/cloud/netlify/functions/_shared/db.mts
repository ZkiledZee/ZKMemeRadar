import {getDatabase} from '@netlify/database';
import {createHash, randomBytes, timingSafeEqual} from 'node:crypto';
export function db(){return getDatabase().pool;}
export function env(key:string){return Netlify.env.get(key)||'';}
export function hash(v:string){return createHash('sha256').update(v).digest('hex');}
export function secret(){return randomBytes(32).toString('hex');}
export function same(a:string,b:string){return !!a&&a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));}
export async function limit(key:string,max=6){
 const k=hash(key+':'+Math.floor(Date.now()/60000));
 const r=await db().query('INSERT INTO radar_limits(key,hits,expires) VALUES($1,1,now()+interval \'2 minutes\') ON CONFLICT(key) DO UPDATE SET hits=radar_limits.hits+1 RETURNING hits',[k]);
 return r.rows[0].hits<=max;
}
export function response(data:any,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});}
export async function authorized(req:Request){
 const token=req.headers.get('authorization')?.replace(/^Bearer /,'')||'';
 if(token.length<32)return null;
 const r=await db().query('SELECT id,device_token,environment FROM radar_clients WHERE credential_hash=$1',[hash(token)]);
 return r.rows[0]||null;
}
