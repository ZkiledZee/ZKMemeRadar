import {randomUUID} from 'node:crypto';
import {db,env} from './db.mts';
import {Providers} from './providers.mts';
import {evaluate,activate,monitor,time} from './model.mts';
import {flushPush} from './push.mts';
export async function runScanner(){
 const owner=randomUUID();const claimed=await db().query("UPDATE radar_state SET owner=$1,lease_until=now()+interval '100 seconds' WHERE id=1 AND (lease_until IS NULL OR lease_until<now()) RETURNING body",[owner]);
 if(!claimed.rows.length)return;
 const end=Date.now()+50000;const providers=new Providers();
 try{
  let initial=true;
  do{
   const read=await db().query('SELECT body FROM radar_state WHERE id=1 AND owner=$1',[owner]);if(!read.rows.length)return;
   const before=read.rows[0].body;let discovered:any[]=[],updates:any[]=[];let discoveryAttempt=false;
   if(initial&&time()-(before.discovered||0)>270){discoveryAttempt=true;discovered=await providers.discover(before.rotation||0);}
   const active=before.active;
   if(active){
    let q=await providers.quote(active.token);
    if(q&&Math.abs(q.price/active.token.price-1)>.45){try{const other=await providers.gecko(active.token);if(!other||Math.abs(q.price/other.price-1)>.10)q=null;}catch{q=null;}}
    if(q){q=evaluate(q,active.token);if(time()-q.security.checked>120){q.security=await providers.security(q);q=evaluate(q,q);}updates.push(q);}
   }
   const merged=new Map((before.tokens||[]).map((t:any)=>[t.id,t]));for(const t of discovered){const prior:any=merged.get(t.id);if(active?.token.id===t.id&&active.token.pool!==t.pool)continue;merged.set(t.id,evaluate(t,prior));}
   const ranked:any[]=Array.from(merged.values()).sort((a:any,b:any)=>(b.scores.Overall||0)-(a.scores.Overall||0)).slice(0,12);
   const start=(before.watchCursor||0)%Math.max(1,ranked.length);
   for(let i=0;i<3&&ranked.length&&Date.now()<end-13000;i++){
    const t=ranked[(start+i)%ranked.length];if(active?.token.id===t.id)continue;let q=await providers.quote(t);if(!q)continue;
    if(Math.abs(q.price/t.price-1)>.25){try{const other=await providers.gecko(t);if(!other||Math.abs(q.price/other.price-1)>.1)continue;}catch{continue;}}
    q=evaluate(q,t);if(q.scores.Overall>=60&&time()-q.security.checked>120){q.security=await providers.security(q);q=evaluate(q,q);}updates.push(q);
   }
   const client=await db().connect();
   try{
    await client.query('BEGIN');const row=await client.query('SELECT body FROM radar_state WHERE id=1 AND owner=$1 AND lease_until>now() FOR UPDATE',[owner]);if(!row.rows.length){await client.query('ROLLBACK');return;}
    const state=row.rows[0].body;const tokens=new Map((state.tokens||[]).map((t:any)=>[t.id,t]));
    for(const t of discovered){const old:any=tokens.get(t.id);if(state.active?.token.id===t.id&&state.active.token.pool!==t.pool)continue;tokens.set(t.id,evaluate(t,old));}
    for(const q of updates)tokens.set(q.id,q);
    let event:string|null=null,changed:any=null;
    if(state.active){
     const q=updates.find(t=>t.id===state.active.token.id)||null;[changed,event]=monitor(state.active,q);
     await client.query('UPDATE radar_signals SET body=$2,closed=$3 WHERE id=$1',[changed.id,JSON.stringify(changed),changed.closed]);
     state.active=changed.closed?null:changed;if(changed.closed)state.lastClosed=time();
    }else if(time()-(state.lastClosed||0)>60){
     const recent=await client.query('SELECT body FROM radar_signals WHERE closed>$1',[time()-1800]);const cooldown=new Set(recent.rows.map(r=>r.body.token.id));
     const t=updates.filter(t=>t.eligible&&!cooldown.has(t.id)).sort((a,b)=>b.scores.Overall-a.scores.Overall)[0];
     if(t){changed=activate(t);state.active=changed;event='NEW MEME SIGNAL';await client.query('INSERT INTO radar_signals(id,body,closed) VALUES($1,$2,NULL)',[changed.id,JSON.stringify(changed)]);}
    }
    if(event&&changed){const id=randomUUID(),body=`${changed.token.symbol} · ${changed.recommendation} · score ${Math.round(changed.confidence)}/100`;
     await client.query('INSERT INTO radar_events VALUES($1,$2,$3,$4,$5)',[id,changed.id,event,body,time()]);await client.query('INSERT INTO radar_delivery(event,client) SELECT $1,id FROM radar_clients WHERE device_token IS NOT NULL',[id]);}
    state.tokens=Array.from(tokens.values()).filter((t:any)=>time()-t.fetched<3600).sort((a:any,b:any)=>(b.scores.Overall||0)-(a.scores.Overall||0)).slice(0,120);
    state.heartbeat=time();state.watchCursor=start+3;
    if(discoveryAttempt){state.discoveryOK=discovered.length>0;state.discovered=time();state.rotation=(state.rotation||0)+1;}
    const health=new Map((state.providers||[]).map((p:any)=>[p.name,p]));for(const p of Object.values(providers.health) as any[])health.set(p.name,p);state.providers=Array.from(health.values());
    await client.query('UPDATE radar_state SET body=$2 WHERE id=1 AND owner=$1',[owner,JSON.stringify(state)]);await client.query('COMMIT');
   }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
   await flushPush();initial=false;
   if(Date.now()<end-18000)await new Promise(r=>setTimeout(r,10000));else break;
  }while(Date.now()<end-14000);
  await db().query('DELETE FROM radar_limits WHERE expires<now()');
  await db().query("DELETE FROM radar_clients WHERE updated<now()-interval '90 days'");
  await db().query('DELETE FROM radar_delivery WHERE event IN(SELECT id FROM radar_events WHERE created<$1)',[time()-604800]);
  await db().query('DELETE FROM radar_events WHERE created<$1',[time()-604800]);
 }finally{await db().query('UPDATE radar_state SET owner=NULL,lease_until=NULL WHERE id=1 AND owner=$1',[owner]);}
}
