import {randomUUID} from 'node:crypto';
export function time(){return Date.now()/1000;}
export function num(v:any,d:any=null){if(v===null||v===undefined||v==='')return d;const n=Number(v);return Number.isFinite(n)?n:d;}
export function clamp(v:number){return Math.round(Math.max(0,Math.min(100,v))*10)/10;}
export function emptySecurity(){return {source:'Unavailable',checked:0,complete:false,danger:false,risk:null,concentration:null,facts:{},warnings:['Required security evidence unavailable — signals blocked']};}
export function evaluate(t:any,previous:any,now=time()){
 const same=previous?.pool===t.pool;
 t.points=same?[...previous.points]:[];t.security=same?previous.security:emptySecurity();
 if(!t.points.length||t.fetched-t.points.at(-1).time>=8)t.points.push({time:t.fetched,price:t.price,liquidity:t.liquidity,volume5:t.volume5,buys:t.buys,sells:t.sells});
 t.points=t.points.filter((p:any)=>now-p.time<=7200).slice(-480);
 t.reasons=[];t.risks=[...t.security.warnings];t.eligible=false;t.entryLow=null;t.entryHigh=null;t.stop=null;t.target1=null;t.target2=null;t.holdSeconds=900;
 t.unavailable=['Unique buyers and sellers','Buy and sell dollar volume','Developer / insider wallet attribution','Whale / profitable-wallet flows','Social mention and bot statistics','Bundled and coordinated supply','Rug-pull probability (not calibrated)','LP lock expiry / pool-specific sell simulation'];
 const sec=t.security,fresh=sec.complete&&now-sec.checked<180,cap=t.marketCap||t.fdv,ratio=cap>0?t.liquidity/cap:null;
 const activity=t.buys+t.sells,share=t.buys/Math.max(1,activity),vr=t.volume5/Math.max(1,t.volumeHour/12),change=t.change5||0;
 const liq=clamp(45+20*Math.log10(Math.max(1,t.liquidity)/100000)+(ratio?Math.min(ratio,.3)*100:0));
 const vol=clamp(30+Math.min(vr,3)*15+Math.min(activity,150)/6+Math.max(0,share-.5)*50);
 let momentum=clamp(45+change*3+Math.max(0,share-.5)*60),entry=0,setup=false;
 if(change>20){momentum=clamp(momentum-(change-20)*3);t.risks.push('Overextended vertical move');}
 const points=t.points,enough=points.length>=10&&points.at(-1).time-points[0].time>=300;
 if(enough){
  const old=points.filter((p:any)=>p.time>=now-900&&p.time<now-90),recent=points.filter((p:any)=>p.time>=now-90);
  if(old.length>=5&&recent.length>=3){
   const r=Math.max(...old.map((p:any)=>p.price));
   const retest=recent.slice(0,-2).some((p:any,i:number)=>p.price>r*1.004&&recent.slice(i+1,-1).some((q:any)=>q.price>=r*.992&&q.price<=r*1.01&&q.price<p.price*.998));
   setup=retest&&t.price>points.at(-2).price&&t.price>=r&&t.price<=r*1.018;
   entry=setup?92:Math.abs(t.price/r-1)<.025?55:25;t.entryLow=r*.998;t.entryHigh=r*1.018;
   const returns=points.slice(1).map((p:any,i:number)=>Math.abs(p.price/points[i].price-1)).sort((a:number,b:number)=>a-b);
   const width=Math.max(.025,Math.min(.08,returns[Math.floor(returns.length/2)]*5));
   t.stop=Math.min(t.entryLow*.985,t.price*(1-width));const risk=t.price-t.stop;t.target1=t.price+2*risk;t.target2=t.price+3*risk;t.holdSeconds=width>=.06?300:width>=.035?900:1800;
   if(setup)t.reasons.push('Sampled breakout, later retest and recovery confirmed');
  }
  if(t.liquidity<points[0].liquidity*.8){setup=false;t.risks.push('Liquidity has declined more than 20%');}
  if(t.volume5>points.at(-2).volume5*1.1)t.reasons.push('Rolling volume accelerating');
  if(t.buys>points.at(-2).buys)t.reasons.push('Buy transaction count increasing');
 }else t.risks.push('Collecting at least five minutes of price observations');
 if(!fresh)t.risks.push('Required security evidence missing or stale');if(sec.danger)t.risks.push('Security gate failed');
 if(vr>=1.5)t.reasons.push('Volume above the hourly baseline');if(t.liquidity>=100000)t.reasons.push('Selected pool liquidity above $100k');if(share>=.58)t.reasons.push('Buy transactions outweigh sells');
 if(!t.created)t.risks.push('Pool age unavailable');else if(now-t.created<3600)t.risks.push('Pool younger than one hour');
 const wash=t.volume5/Math.max(1,t.liquidity)>3;if(wash)t.risks.push('Abnormal volume versus liquidity');
 const safety=fresh&&sec.risk!==null?clamp(100-sec.risk):null,wallet=fresh&&sec.concentration!==null?clamp(100-sec.concentration*100):null;
 const overall=clamp(.22*momentum+.16*liq+.2*vol+.1*(wallet||0)+.16*(safety||0)+.16*entry);
 t.scores={Momentum:momentum,Liquidity:liq,Volume:vol,Wallet:wallet,Safety:safety,Social:null,'Entry Quality':entry,'Rug Risk':fresh?sec.risk:null,Overall:overall,Risk:clamp(.55*(fresh?sec.risk:100)+.25*(100-liq)+.2*(100-entry))};
 const observed=(seconds:number)=>{const p=points.filter((p:any)=>p.time<=now-seconds).at(-1);return p&&now-seconds-p.time<=45?(t.price/p.price-1)*100:null;};
 t.metrics={'Observed 1m change':observed(60),'Observed 15m change':observed(900),'Buy transaction share percent':share*100,'Transactions per minute':activity/5,'Volume versus hourly baseline':vr,'Liquidity / cap percent':ratio===null?null:ratio*100};
 t.eligible=!!(setup&&fresh&&!sec.danger&&overall>=78&&t.liquidity>=100000&&ratio!==null&&ratio>=.03&&t.created&&now-t.created>=1800&&activity>=30&&share>=.58&&vr>=1.4&&vr<=8&&change>0&&change<=18&&!wash&&now-t.fetched<45&&t.stop&&t.target2);
 t.status=sec.danger?'RUG/DANGER':setup?'ENTRY APPROACHING':enough?'WATCHING':'WAIT';return t;
}
export function activate(t:any,now=time()){return {id:randomUUID(),token:t,status:'SIGNAL ACTIVE',recommendation:'BUY ZONE',opened:now,expires:now+t.holdSeconds,initialExpires:now+t.holdSeconds,entry:t.price,entryLow:t.entryLow,entryHigh:t.entryHigh,reasons:[...t.reasons],stop:t.stop,target1:t.target1,target2:t.target2,confidence:t.scores.Overall,maxGain:0,maxLoss:0,target1Hit:false,closed:null,exit:null,closeReason:null,lastGood:t.fetched};}
export function monitor(s:any,t:any,now=time()):[any,string|null]{
 if(s.closed)return [s,null];let event=null;
 const close=(reason:string,price:any,title:string):[any,string]=>{Object.assign(s,{closed:now,closeReason:reason,status:'CLOSED — '+reason,exit:price,recommendation:price===null?'EXIT — DATA UNAVAILABLE':'EXIT NOW'});return [s,title];};
 if(!t||now-t.fetched>60){if(now-s.lastGood>=120)return close('DATA UNAVAILABLE',null,'MONITORING LOST — EXIT');if(now>=s.expires)return close('HOLD EXPIRED',null,'SIGNAL EXPIRED');s.recommendation='DATA DELAYED — DO NOT ENTER';return [s,null];}
 if(t.pool!==s.token.pool)return close('POOL CHANGED',null,'SIGNAL INVALIDATED');const previous=s.token;s.token=t;s.lastGood=t.fetched;
 const gain=(t.price/s.entry-1)*100;s.maxGain=Math.max(s.maxGain,gain);s.maxLoss=Math.min(s.maxLoss,gain);
 if(t.security.danger||(t.security.risk!==null&&previous.security.risk!==null&&t.security.risk-previous.security.risk>=20))return close('RUG WARNING',t.price,'RUG WARNING — EXIT');
 if(t.liquidity<previous.liquidity*.65||t.liquidity<50000)return close('LIQUIDITY WARNING',t.price,'LIQUIDITY WARNING — EXIT');
 if(t.price<=s.stop)return close('INVALIDATED',t.price,'EXIT SIGNAL');if(t.price>=s.target2)return close('PROFIT TARGET',t.price,'TARGET HIT — EXIT');if(now>=s.expires)return close('HOLD EXPIRED',t.price,'SIGNAL EXPIRED');
 if(!t.security.complete||now-t.security.checked>300)return close('SECURITY DATA LOST',t.price,'SECURITY MONITORING LOST');
 if(t.sells>Math.max(15,t.buys*1.8)&&(t.change5||0)<-3)return close('MOMENTUM LOST',t.price,'MOMENTUM LOST — EXIT');
 if(!s.target1Hit&&t.price>=s.target1){s.target1Hit=true;s.stop=Math.max(s.stop,s.entry*1.003);s.recommendation='TAKE 50% PROFIT · INVALIDATION RAISED';event='TAKE PROFIT';}
 else if(t.buys<t.sells&&now-s.opened>60){s.expires=Math.min(s.expires,now+120);if(s.recommendation!=='MOMENTUM WEAKENING')event='MOMENTUM WEAKENING';s.recommendation='MOMENTUM WEAKENING';}
 else s.recommendation=now-s.opened>30?'HOLD':'BUY ZONE';return [s,event];
}
