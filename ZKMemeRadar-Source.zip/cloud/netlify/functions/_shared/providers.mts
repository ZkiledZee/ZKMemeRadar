import {env} from './db.mts';
import {time,num,emptySecurity} from './model.mts';
export function chains(){return {solana:'solana',base:'base',ethereum:'eth',bsc:'bsc'};}
export function valid(chain:string,address:string){return (chain==='solana'?/^[1-9A-HJ-NP-Za-km-z]{32,44}$/:/^0x[0-9a-fA-F]{40}$/).test(address||'');}
export class Providers{
 health:any={};next:any={};
 async get(url:string,options:any={}){
  const host=new URL(url).host;await new Promise(r=>setTimeout(r,Math.max(0,(this.next[host]||0)-Date.now())));
  this.next[host]=Date.now()+(host.includes('geckoterminal')?7000:1100);
  try{const r=await fetch(url,{...options,signal:AbortSignal.timeout(9000)});if(r.status===429)this.next[host]=Date.now()+60000;if(!r.ok)throw new Error('HTTP '+r.status);const text=await r.text();if(text.length>5e6)throw new Error('Oversized');const j=JSON.parse(text);this.health[host]={name:host,ok:true,at:time()};return j;}
  catch(e){this.health[host]={name:host,ok:false,at:time()};throw e;}
 }
 async discover(rotation:number){
  const out:any[]=[];let refs:any[]=[];
  for(const path of ['token-profiles/latest/v1','token-boosts/top/v1'])try{const r=await this.get('https://api.dexscreener.com/'+path);if(Array.isArray(r))refs.push(...r);}catch{}
  for(const chain of Object.keys(chains())){
   const addresses=[...new Set(refs.filter(x=>x.chainId===chain&&valid(chain,x.tokenAddress)).map(x=>x.tokenAddress))].slice(0,30);
   if(!addresses.length)continue;
   try{const rows=await this.get(`https://api.dexscreener.com/tokens/v1/${chain}/${addresses.join(',')}`);for(const p of rows){const t=parse(p);if(t)out.push(t);}}catch{}
  }
  const chain=Object.keys(chains())[rotation%4],kind=Math.floor(rotation/4)%2?'new_pools':'trending_pools';
  try{const j=await this.get(`https://api.geckoterminal.com/api/v2/networks/${chains()[chain]}/${kind}?include=base_token`);out.push(...parseGecko(j,chain,kind==='new_pools'?'New':'Trending'));}catch{}
  const by=new Map();for(const t of out)if(!by.has(t.id)||t.liquidity>by.get(t.id).liquidity)by.set(t.id,t);return [...by.values()];
 }
 async gecko(t:any){const j=await this.get(`https://api.geckoterminal.com/api/v2/networks/${chains()[t.chain]}/pools/${t.pool}?include=base_token`);return parseGecko(j,t.chain,t.category).find(q=>q.id===t.id&&q.pool===t.pool)||null;}
 async quote(t:any){
  try{const j=await this.get(`https://api.dexscreener.com/latest/dex/pairs/${t.chain}/${t.pool}`);const q=(j.pairs||[]).map(p=>parse(p,t.category)).find(q=>q&&q.id===t.id&&q.pool===t.pool);if(q)return q;}catch{}
  try{return await this.gecko(t);}catch{return null;}
 }
 async rpc(method:string,params:any[]){const j=await this.get(env('SOLANA_RPC_URL')||'https://api.mainnet-beta.solana.com',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});if(j.error)throw new Error('RPC failure');return j.result.value;}
 async security(t:any){try{return t.chain==='solana'?await this.solana(t):await this.evm(t);}catch{return emptySecurity();}}
 async solana(t:any){
  const account=await this.rpc('getAccountInfo',[t.address,{encoding:'jsonParsed',commitment:'confirmed'}]),info=account.data.parsed.info;
  const accounts=await this.rpc('getTokenLargestAccounts',[t.address,{commitment:'confirmed'}]);const amounts=accounts.map(x=>num(x.amount)),supply=num(info.supply);
  let concentration=amounts.length&&amounts.every(x=>x!==null&&x>=0)&&supply>0?amounts.reduce((a,b)=>a+b,0)/supply:null;
  if(concentration!==null&&(concentration>1.001||concentration<0))concentration=null;
  const legacy=account.owner==='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',complete=['supply','mintAuthority','freezeAuthority'].every(k=>k in info)&&concentration!==null;
  const danger=!!(info.mintAuthority||info.freezeAuthority||!legacy||concentration>.5);
  return {source:'Solana RPC',checked:time(),complete,danger,risk:danger?95:complete?Math.max(30,concentration*100):null,concentration,facts:{'Mint authority':'mintAuthority' in info?(info.mintAuthority?'Enabled':'Revoked'):'Unavailable','Freeze authority':'freezeAuthority' in info?(info.freezeAuthority?'Enabled':'Revoked'):'Unavailable','Top 20 token accounts':concentration===null?'Unavailable':(concentration*100).toFixed(1)+'%','Token program':legacy?'Legacy SPL':'Unsupported / Token-2022','LP lock / sell simulation':'Unavailable'},warnings:['Token-account concentration includes pools; it is not unique-owner concentration.','LP lock, sell simulation and developer attribution unavailable.']};
 }
 async evm(t:any){
  const chain={ethereum:1,base:8453,bsc:56}[t.chain],token=env('GOPLUS_TOKEN');
  const r=await this.get(`https://api.gopluslabs.io/api/v1/token_security/${chain}?contract_addresses=${t.address}`,token?{headers:{Authorization:'Bearer '+token}}:{});
  const a=r.result?.[t.address.toLowerCase()];if(!a)throw new Error('No coverage');
  const checks=['is_honeypot','is_mintable','is_blacklisted','is_proxy','can_take_back_ownership','owner_change_balance','cannot_sell_all','transfer_pausable','slippage_modifiable','personal_slippage_modifiable','hidden_owner','selfdestruct','cannot_buy','anti_whale_modifiable','trading_cooldown'];
  const taxes=[num(a.buy_tax),num(a.sell_tax)],fractions=Array.isArray(a.holders)?a.holders.slice(0,10).map(x=>num(x.percent)):[];
  let concentration=fractions.length&&fractions.every(x=>x!==null&&x>=0&&x<=1)?fractions.reduce((a,b)=>a+b,0):null;if(concentration>1.001)concentration=null;
  const complete=checks.every(k=>['0','1'].includes(a[k]))&&a.is_open_source==='1'&&taxes.every(x=>x!==null&&x>=0&&x<=1)&&concentration!==null;
  const flags=checks.filter(k=>a[k]==='1'),danger=!!(flags.length||taxes.some(x=>x!==null&&x>.03)||concentration>.5);
  const facts:any=Object.fromEntries(checks.map(k=>[k.replaceAll('_',' '),a[k]==='1'?'Detected':a[k]==='0'?'Not reported':'Unavailable']));
  for(const k of ['buy_tax','sell_tax','holder_count','creator_percent','owner_percent','total_supply'])facts[k.replaceAll('_',' ')]=String(a[k]??'Unavailable');
  return {source:'GoPlus',checked:time(),complete,danger,risk:danger?95:complete?Math.max(25,concentration*100):null,concentration,facts,warnings:[...flags.map(k=>k.replaceAll('_',' ')),'Static checks cannot guarantee a sell. LP lock expiry and insider attribution are unverified.']};
 }
}
export function parse(p:any,category='Trending'){
 try{const chain=p.chainId,b=p.baseToken||{},address=b.address||'',price=num(p.priceUsd),liquidity=num(p.liquidity?.usd);
 if(!Object.keys(chains()).includes(chain)||!valid(chain,address)||!price||price<=0||liquidity===null||liquidity<0||!/^\w{20,90}$/.test(p.pairAddress||''))return null;
 if(['USDC','USDT','DAI','WETH','WBTC','WBNB','WSOL'].includes((b.symbol||'').toUpperCase()))return null;
 const tx=p.txns?.m5||{},v=p.volume||{},change=p.priceChange||{};
 return {id:chain+':'+(chain==='solana'?address:address.toLowerCase()),chain,address,pool:p.pairAddress,iconURL:typeof p.info?.imageUrl==='string'?p.info.imageUrl:null,name:String(b.name||'Unknown').slice(0,80),symbol:String(b.symbol||'?').slice(0,24),price,liquidity,marketCap:num(p.marketCap),fdv:num(p.fdv),created:num(p.pairCreatedAt)?Number(p.pairCreatedAt)/1000:null,volume5:Math.max(0,num(v.m5,0)),volumeHour:Math.max(0,num(v.h1,0)),buys:Math.max(0,Math.floor(num(tx.buys,0))),sells:Math.max(0,Math.floor(num(tx.sells,0))),change5:num(change.m5),changeHour:num(change.h1),fetched:time(),source:'DEX Screener',category,points:[],security:emptySecurity(),metrics:{},scores:{},reasons:[],risks:[],unavailable:[],status:'WAIT',entryLow:null,entryHigh:null,stop:null,target1:null,target2:null,holdSeconds:900,eligible:false};}catch{return null;}
}
export function parseGecko(data:any,chain:string,category:string){
 const included=Object.fromEntries((data.included||[]).map(x=>[x.id,x.attributes||{}]));const rows=Array.isArray(data.data)?data.data:[data.data];const out=[];
 for(const row of rows)try{const a=row.attributes,id=row.relationships.base_token.data.id,b=included[id]||{},address=b.address||id.slice(id.indexOf('_')+1);
 const t=parse({chainId:chain,baseToken:{address,name:b.name||a.name?.split('/')[0].trim(),symbol:b.symbol||a.name?.split('/')[0].trim()},pairAddress:a.address,info:{imageUrl:b.image_url},priceUsd:a.base_token_price_usd,liquidity:{usd:a.reserve_in_usd},marketCap:a.market_cap_usd,fdv:a.fdv_usd,volume:a.volume_usd,txns:a.transactions,priceChange:a.price_change_percentage,pairCreatedAt:a.pool_created_at?Date.parse(a.pool_created_at):null},category);
 if(t){t.source='GeckoTerminal';out.push(t);}}catch{}return out;
}
