import {env,same} from './_shared/db.mts';
import {runScanner} from './_shared/scanner.mts';
export default async (req:Request)=>{
 if(req.method!=='POST'||!same(req.headers.get('x-radar-worker')||'',env('RADAR_WORKER_KEY')))return new Response(null,{status:401});
 try{await runScanner();}catch(e){console.error('Scanner cycle failed',e instanceof Error?e.message:'unknown error');throw e;}
};
