import os, time, logging, uuid
import httpx, jwt
log=logging.getLogger(__name__)

class Push:
    def __init__(self,store):
        self.store=store; self.client=httpx.AsyncClient(http2=True,timeout=10)
        self.jwt=None; self.jwt_at=0
    @property
    def ready(self): return all(os.getenv(x) for x in ['APNS_KEY_ID','APNS_TEAM_ID','APNS_KEY_PATH','APNS_TOPIC'])
    def auth(self):
        if not self.jwt or time.time()-self.jwt_at>3000:
            with open(os.environ['APNS_KEY_PATH']) as f: key=f.read()
            self.jwt=jwt.encode({'iss':os.environ['APNS_TEAM_ID'],'iat':int(time.time())},key,algorithm='ES256',headers={'kid':os.environ['APNS_KEY_ID']}); self.jwt_at=time.time()
        return self.jwt
    async def flush(self):
        if not self.ready: return
        with self.store.connect() as c:
            rows=c.execute('SELECT d.*,e.signal_id,e.title,e.body,e.created FROM deliveries d JOIN events e ON e.id=d.event JOIN devices v ON v.token=d.device WHERE d.sent IS NULL AND d.next<? AND d.attempts<10 ORDER BY e.created LIMIT 20',(time.time(),)).fetchall()
        for r in rows:
            s=self.store.signal(r['signal_id'])
            age=time.time()-r['created']
            obsolete=age>300 or (r['title']=='NEW MEME SIGNAL' and (not s or s.closed or time.time()>s.opened+60 or s.recommendation!='BUY ZONE' or not s.entryLow<=s.token.price<=s.entryHigh)) or (s is not None and s.closed is not None and r['title'] in ('TAKE PROFIT','MOMENTUM WEAKENING'))
            delivered=False
            if not obsolete:
                try:
                    host='api.sandbox.push.apple.com' if r['environment']=='sandbox' else 'api.push.apple.com'
                    response=await self.client.post(f'https://{host}/3/device/{r["device"]}',headers={'authorization':'bearer '+self.auth(),'apns-topic':os.environ['APNS_TOPIC'],'apns-push-type':'alert','apns-priority':'10','apns-expiration':str(int(r['created']+300)),'apns-id':str(uuid.uuid5(uuid.NAMESPACE_URL,r['event']+r['device'])),'apns-collapse-id':r['signal_id'] or 'connection-test'},json={'aps':{'alert':{'title':r['title'],'body':r['body']},'sound':'default','thread-id':r['signal_id']},**({'signalId':r['signal_id']} if s else {})})
                    delivered=response.status_code==200
                    reason=response.json().get('reason') if response.content and not delivered else None
                    if response.status_code==410 or reason in ('BadDeviceToken','DeviceTokenNotForTopic'):
                        self.store.remove_device(r['device']); continue
                    if not delivered: log.warning('APNs rejected status=%s reason=%s',response.status_code,reason)
                except Exception as e: log.warning('Push attempt failed: %s',type(e).__name__)
            with self.store.connect() as c:
                c.execute('UPDATE deliveries SET attempts=attempts+1,next=?,sent=? WHERE event=? AND device=?',(time.time()+min(300,2**(r['attempts']+2)),time.time() if delivered or obsolete else None,r['event'],r['device']))
    async def close(self): await self.client.aclose()
