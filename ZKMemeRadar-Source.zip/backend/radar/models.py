from __future__ import annotations
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
import math

CHAINS = {"solana": "solana", "base": "base", "ethereum": "eth", "bsc": "bsc"}

def number(value, default=None):
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (ValueError, TypeError):
        return default

def identity(chain, address):
    return f"{chain}:{address if chain == 'solana' else address.lower()}"

class Point(BaseModel):
    time: float
    price: float
    liquidity: float
    volume5: float
    buys: int
    sells: int

class Security(BaseModel):
    source: str = "Unavailable"
    checked: float = 0
    complete: bool = False
    danger: bool = False
    risk: Optional[float] = None
    concentration: Optional[float] = None
    facts: dict[str, str] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)

class Token(BaseModel):
    id: str
    chain: str
    address: str
    pool: str
    name: str
    symbol: str
    price: float = Field(gt=0)
    liquidity: float = Field(ge=0)
    marketCap: Optional[float] = None
    fdv: Optional[float] = None
    created: Optional[float] = None
    volume5: float = 0
    volumeHour: float = 0
    buys: int = 0
    sells: int = 0
    change5: Optional[float] = None
    changeHour: Optional[float] = None
    fetched: float
    source: str
    category: str = "Trending"
    metrics: dict[str, Optional[float]] = Field(default_factory=dict)
    scores: dict[str, Optional[float]] = Field(default_factory=dict)
    security: Security = Field(default_factory=Security)
    points: list[Point] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    unavailable: list[str] = Field(default_factory=list)
    status: str = "WATCHING"
    entryLow: Optional[float] = None
    entryHigh: Optional[float] = None
    stop: Optional[float] = None
    target1: Optional[float] = None
    target2: Optional[float] = None
    holdSeconds: int = 900
    eligible: bool = False

class Signal(BaseModel):
    id: str
    token: Token
    status: str = "SIGNAL ACTIVE"
    recommendation: str = "BUY ZONE"
    opened: float
    expires: float
    initialExpires: float
    entry: float
    entryLow: float
    entryHigh: float
    reasons: list[str]
    stop: float
    target1: float
    target2: float
    confidence: float
    maxGain: float = 0
    maxLoss: float = 0
    target1Hit: bool = False
    closed: Optional[float] = None
    exit: Optional[float] = None
    closeReason: Optional[str] = None
    lastGood: float

class Device(BaseModel):
    model_config = ConfigDict(extra="forbid")
    token: str = Field(pattern=r"^[a-fA-F0-9]{64,200}$")
    environment: str = Field(pattern=r"^(sandbox|production)$")
