"""Public-provider adapters. Fetch timestamps are observation times, not exchange ticks."""
import asyncio, math, os, re, time
from datetime import datetime
from typing import Protocol
from urllib.parse import urlparse
import httpx
from .models import Token, Security, CHAINS, identity, number

class MarketProvider(Protocol):
    async def discover(self) -> list[Token]: ...
    async def quote(self, token: Token) -> Token | None: ...

class HTTP:
    def __init__(self):
        self.client=httpx.AsyncClient(timeout=12, follow_redirects=False)
        self.locks={}; self.next={}; self.health={}
    async def request(self,url,method='GET',**kwargs):
        host=urlparse(url).netloc
        lock=self.locks.setdefault(host,asyncio.Lock())
        # Gecko has the lowest quota; pace every request, including failures.
        interval=7.0 if 'geckoterminal' in host else 1.1
        async with lock:
            await asyncio.sleep(max(0,self.next.get(host,0)-time.monotonic()))
            self.next[host]=time.monotonic()+interval
            try:
                r=await self.client.request(method,url,**kwargs)
                if r.status_code==429:
                    delay=number(r.headers.get('retry-after'),60)
                    self.next[host]=time.monotonic()+min(300,max(30,delay))
                r.raise_for_status()
                if len(r.content)>5_000_000: raise ValueError('Oversized provider payload')
                result=r.json()
                self.health[host]={'ok':True,'at':time.time()}
                return result
            except Exception as e:
                self.health[host]={'ok':False,'at':time.time(),'error':type(e).__name__}
                raise
    async def close(self): await self.client.aclose()

def valid_address(chain,address):
    return bool(re.fullmatch(r'[1-9A-HJ-NP-Za-km-z]{32,44}' if chain=='solana' else r'0x[0-9a-fA-F]{40}',address or ''))

def _dex_token(p,category='Trending'):
    chain=p.get('chainId'); b=p.get('baseToken') or {}; address=b.get('address','')
    
    if not re.fullmatch(r'[a-zA-Z0-9]{20,90}',str(p.get('pairAddress',''))): return None
    if str(b.get('symbol','')).upper() in {'USDC','USDT','DAI','WETH','WBTC','WBNB','WSOL'}: return None
    price=number(p.get('priceUsd')); liq=number((p.get('liquidity') or {}).get('usd'))
    if chain not in CHAINS or not valid_address(chain,address) or not price or price<=0 or liq is None or liq<0: return None
    tx=(p.get('txns') or {}).get('m5') or {}; v=p.get('volume') or {}; change=p.get('priceChange') or {}
    return Token(id=identity(chain,address),chain=chain,address=address,pool=p['pairAddress'],name=str(b.get('name') or 'Unknown')[:80],symbol=str(b.get('symbol') or '?')[:24],price=price,liquidity=liq,
        marketCap=number(p.get('marketCap')),fdv=number(p.get('fdv')),created=(number(p.get('pairCreatedAt')) or 0)/1000 or None,
        volume5=max(0,number(v.get('m5'),0)),volumeHour=max(0,number(v.get('h1'),0)),buys=max(0,int(number(tx.get('buys'),0))),sells=max(0,int(number(tx.get('sells'),0))),change5=number(change.get('m5')),changeHour=number(change.get('h1')),fetched=time.time(),source='DEX Screener',category=category)

def dex_token(p,category='Trending'):
    try: return _dex_token(p,category)
    except (ValueError,KeyError,TypeError,OverflowError,AttributeError): return None

class Dex:
    def __init__(self,http): self.http=http
    async def discover(self):
        refs=[]
        for endpoint in ['token-profiles/latest/v1','token-boosts/top/v1']:
            try:
                data=await self.http.request('https://api.dexscreener.com/'+endpoint)
                if isinstance(data,list): refs.extend(data)
            except Exception: continue
        result=[]
        for chain in CHAINS:
            addresses=list(dict.fromkeys(x.get('tokenAddress') for x in refs if x.get('chainId')==chain and valid_address(chain,x.get('tokenAddress'))))[:30]
            if not addresses: continue
            try:
                rows=await self.http.request(f'https://api.dexscreener.com/tokens/v1/{chain}/'+','.join(addresses))
                for p in rows:
                    t=dex_token(p,'Trending')
                    if t: result.append(t)
            except Exception: continue
        return dedup(result)
    async def quote(self,t):
        rows=await self.http.request(f'https://api.dexscreener.com/latest/dex/pairs/{t.chain}/{t.pool}')
        for p in rows.get('pairs') or []:
            q=dex_token(p,t.category)
            if q and q.id==t.id and q.pool==t.pool: return q
        return None

def dedup(tokens):
    chosen={}
    for t in tokens:
        if t.id not in chosen or t.liquidity>chosen[t.id].liquidity: chosen[t.id]=t
    return list(chosen.values())

class Gecko:
    def __init__(self,http): self.http=http; self.rotation=0
    async def discover(self):
        # Rotate networks and new/trending endpoints: eight calls per 40 minutes.
        chain=list(CHAINS)[self.rotation%4]; kind='trending_pools' if (self.rotation//4)%2==0 else 'new_pools'; self.rotation+=1
        data=await self.http.request(f'https://api.geckoterminal.com/api/v2/networks/{CHAINS[chain]}/{kind}',params={'include':'base_token'})
        return self.parse(data,chain,'New' if kind=='new_pools' else 'Trending')
    def parse(self,data,chain,category):
        included={v['id']:v.get('attributes',{}) for v in data.get('included',[])}; out=[]
        rows=data.get('data') or []
        if isinstance(rows,dict): rows=[rows]
        for row in rows:
            try:
                a=row['attributes']; rel=row['relationships']['base_token']['data']['id']; b=included.get(rel,{})
                address=b.get('address') or rel.split('_',1)[1]
                created=a.get('pool_created_at')
                p={'chainId':chain,'baseToken':{'address':address,'name':b.get('name') or a.get('name','').split('/')[0].strip(),'symbol':b.get('symbol') or a.get('name','').split('/')[0].strip()},'pairAddress':a['address'],'priceUsd':a.get('base_token_price_usd'),'liquidity':{'usd':a.get('reserve_in_usd')},'marketCap':a.get('market_cap_usd'),'fdv':a.get('fdv_usd'),'volume':a.get('volume_usd'),'txns':a.get('transactions'),'priceChange':a.get('price_change_percentage'),'pairCreatedAt':datetime.fromisoformat(created.replace('Z','+00:00')).timestamp()*1000 if created else None}
                t=dex_token(p,category)
                if t: t.source='GeckoTerminal'; out.append(t)
            except (ValueError,KeyError,TypeError): continue
        return out
    async def quote(self,t):
        data=await self.http.request(f'https://api.geckoterminal.com/api/v2/networks/{CHAINS[t.chain]}/pools/{t.pool}',params={'include':'base_token'})
        return next((q for q in self.parse(data,t.chain,t.category) if q.id==t.id and q.pool==t.pool),None)

class SecurityProvider:
    def __init__(self,http): self.http=http
    async def check(self,t):
        try:
            return await (self.solana(t) if t.chain=='solana' else self.evm(t))
        except Exception:
            return Security(warnings=['Security provider unavailable — new signals blocked'])
    async def rpc(self,method,params):
        r=await self.http.request(os.getenv('SOLANA_RPC_URL','https://api.mainnet-beta.solana.com'),'POST',json={'jsonrpc':'2.0','id':1,'method':method,'params':params})
        if 'error' in r: raise ValueError('RPC error')
        return r['result']['value']
    async def solana(self,t):
        acc=await self.rpc('getAccountInfo',[t.address,{'encoding':'jsonParsed','commitment':'confirmed'}])
        info=acc['data']['parsed']['info']; legacy=acc['owner']=='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'
        supply=number(info.get('supply')); mint=info.get('mintAuthority'); freeze=info.get('freezeAuthority')
        largest=await self.rpc('getTokenLargestAccounts',[t.address,{'commitment':'confirmed'}])
        amounts=[number(x.get('amount')) for x in largest]
        concentration=sum(amounts)/supply if amounts and all(x is not None and x>=0 for x in amounts) and supply and supply>0 else None
        if concentration is not None and not 0<=concentration<=1.001: concentration=None
        danger=bool(mint or freeze or not legacy or concentration is not None and concentration>0.5)
        complete=all(k in info for k in ['supply','mintAuthority','freezeAuthority']) and concentration is not None
        return Security(source='Solana RPC',checked=time.time(),complete=complete,danger=danger,risk=95 if danger else max(30,concentration*100) if complete else None,concentration=concentration,
            facts={'Mint authority':('Enabled' if mint else 'Revoked') if 'mintAuthority' in info else 'Unavailable','Freeze authority':('Enabled' if freeze else 'Revoked') if 'freezeAuthority' in info else 'Unavailable','Token program':'Legacy SPL' if legacy else 'Unsupported / Token-2022','Top 20 token accounts':f'{concentration:.1%}' if concentration is not None else 'Unavailable','LP lock / burn':'Unavailable','Honeypot simulation':'Unavailable','Circulating supply':'Unavailable','Total raw supply':str(info.get('supply','Unavailable'))},
            warnings=['Account concentration includes pools; it is not unique-owner concentration.','LP lock, sell simulation and developer attribution unavailable.'])
    async def evm(self,t):
        chain={'ethereum':'1','base':'8453','bsc':'56'}[t.chain]
        headers={'Authorization':'Bearer '+os.environ['GOPLUS_TOKEN']} if os.getenv('GOPLUS_TOKEN') else {}
        r=await self.http.request(f'https://api.gopluslabs.io/api/v1/token_security/{chain}',params={'contract_addresses':t.address},headers=headers)
        a=(r.get('result') or {}).get(t.address.lower())
        if not a: raise ValueError('No security coverage')
        checks=['is_honeypot','is_mintable','is_blacklisted','is_proxy','can_take_back_ownership','owner_change_balance','cannot_sell_all','transfer_pausable','slippage_modifiable','personal_slippage_modifiable','hidden_owner','selfdestruct','cannot_buy','anti_whale_modifiable','trading_cooldown']
        complete=all(a.get(k) in ('0','1') for k in checks) and a.get('is_open_source')=='1'
        taxes=[number(a.get(k)) for k in ['buy_tax','sell_tax']]
        holders=a.get('holders'); fractions=[number(x.get('percent')) for x in holders[:10]] if isinstance(holders,list) else []
        concentration=sum(fractions) if fractions and all(x is not None and 0<=x<=1 for x in fractions) else None
        if concentration is not None and concentration>1.001: concentration=None
        complete=complete and all(x is not None and 0<=x<=1 for x in taxes) and concentration is not None
        flags=[k.replace('_',' ') for k in checks if a.get(k)=='1']
        danger=bool(flags or any(x is not None and x>0.03 for x in taxes) or concentration is not None and concentration>0.5)
        facts={k.replace('_',' ').capitalize(): {'0':'Not reported','1':'Detected'}.get(a.get(k),'Unavailable') for k in checks}
        for k in ['buy_tax','sell_tax','holder_count','creator_percent','owner_percent','total_supply']:
            facts[k.replace('_',' ').capitalize()]=str(a.get(k,'Unavailable'))
        lp=a.get('lp_holders'); locked=sum(number(x.get('percent'),0) for x in lp if x.get('is_locked')=='1') if isinstance(lp,list) and lp else None
        facts['Reported locked LP fraction']=f'{locked:.1%}' if locked is not None else 'Unavailable'
        return Security(source='GoPlus',checked=time.time(),complete=complete,danger=danger,risk=95 if danger else max(25,concentration*100) if complete else None,concentration=concentration,facts=facts,warnings=flags+['Static provider checks are not a sell guarantee. LP lock expiry and insider attribution are unverified.'])
