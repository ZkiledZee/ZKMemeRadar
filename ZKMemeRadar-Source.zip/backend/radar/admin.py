"""Local administration only. Run inside the backend container."""
import argparse, os, secrets, sqlite3, time, uuid
from .store import Store

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['backup','revoke','test-push'])
    parser.add_argument('destination',nargs='?')
    args=parser.parse_args(); store=Store(os.getenv('DATABASE_PATH','data/radar.sqlite3'))
    if args.command=='backup':
        if not args.destination: parser.error('backup requires a destination path')
        if os.path.abspath(args.destination)==os.path.abspath(store.path): parser.error('Backup destination must differ from the active database')
        with sqlite3.connect(store.path) as source, sqlite3.connect(args.destination) as target: source.backup(target)
        print('Consistent database backup created.')
    elif args.command=='revoke':
        with store.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            import json
            c.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',('accessToken',json.dumps(secrets.token_urlsafe(48))))
            c.execute('DELETE FROM devices'); c.execute('DELETE FROM deliveries')
        print('All device sessions revoked. Change PAIRING_CODE and re-pair your phone.')
    else:
        with store.connect() as c:
            count=c.execute('SELECT COUNT(*) FROM devices').fetchone()[0]
            if not count: raise SystemExit('No registered devices. Pair and enable notifications first.')
            event=str(uuid.uuid4())
            c.execute('INSERT INTO events VALUES (?,?,?,?,?)',(event,None,'ZK RADAR — CONNECTION TEST','Push delivery test only. This is not a market signal.',time.time()))
            c.execute('INSERT INTO deliveries(event,device,environment) SELECT ?,token,environment FROM devices',(event,))
        print('Connection test queued. The running scanner will send it through APNs.')
if __name__=='__main__': main()
