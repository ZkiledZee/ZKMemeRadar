import json, sqlite3, time, uuid
from pathlib import Path
from contextlib import contextmanager
from .models import Token, Signal

class Store:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self.connect() as c:
            c.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS tokens(id TEXT PRIMARY KEY, body TEXT NOT NULL, updated REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS signals(id TEXT PRIMARY KEY, body TEXT NOT NULL, closed REAL);
            CREATE UNIQUE INDEX IF NOT EXISTS one_active ON signals((1)) WHERE closed IS NULL;
            CREATE TABLE IF NOT EXISTS devices(token TEXT PRIMARY KEY, environment TEXT NOT NULL, updated REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY, signal_id TEXT, title TEXT, body TEXT, created REAL);
            CREATE TABLE IF NOT EXISTS deliveries(event TEXT, device TEXT, environment TEXT, attempts INTEGER DEFAULT 0, next REAL DEFAULT 0, sent REAL, PRIMARY KEY(event,device));
            CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            ''')
    @contextmanager
    def connect(self):
        c = sqlite3.connect(self.path, timeout=20)
        c.row_factory = sqlite3.Row
        try:
            with c: yield c
        finally: c.close()
    def get_meta(self, key, default=None):
        with self.connect() as c:
            r = c.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
            return json.loads(r[0]) if r else default
    def meta(self, key, value):
        with self.connect() as c:
            c.execute('INSERT OR REPLACE INTO meta VALUES (?,?)', (key,json.dumps(value,allow_nan=False)))
    def save_token(self,t):
        with self.connect() as c:
            c.execute('INSERT OR REPLACE INTO tokens VALUES (?,?,?)',(t.id,t.model_dump_json(),t.fetched))
    def token(self,id):
        with self.connect() as c:
            r=c.execute('SELECT body FROM tokens WHERE id=?',(id,)).fetchone()
            return Token.model_validate_json(r[0]) if r else None
    def tokens(self):
        with self.connect() as c:
            rows=c.execute('SELECT body FROM tokens WHERE updated>? ORDER BY updated DESC LIMIT 500',(time.time()-3600,)).fetchall()
            return [Token.model_validate_json(r[0]) for r in rows]
    def active(self):
        with self.connect() as c:
            r=c.execute('SELECT body FROM signals WHERE closed IS NULL').fetchone()
            return Signal.model_validate_json(r[0]) if r else None
    def signal(self,id):
        with self.connect() as c:
            r=c.execute('SELECT body FROM signals WHERE id=?',(id,)).fetchone()
            return Signal.model_validate_json(r[0]) if r else None
    def history(self):
        with self.connect() as c:
            return [Signal.model_validate_json(r[0]) for r in c.execute('SELECT body FROM signals WHERE closed IS NOT NULL ORDER BY closed DESC LIMIT 200')]
    def _event(self,c,s,title,body):
        event=str(uuid.uuid4())
        c.execute('INSERT INTO events VALUES (?,?,?,?,?)',(event,s.id,title,body,time.time()))
        c.execute('INSERT INTO deliveries(event,device,environment) SELECT ?,token,environment FROM devices',(event,))
    def activate(self,s):
        try:
            with self.connect() as c:
                c.execute('BEGIN IMMEDIATE')
                c.execute('INSERT INTO signals VALUES (?,?,NULL)',(s.id,s.model_dump_json()))
                self._event(c,s,'NEW MEME SIGNAL',f'{s.token.symbol} · BUY ZONE · score {s.confidence:.0f}/100 · expected {s.token.holdSeconds//60} min')
            return True
        except sqlite3.IntegrityError: return False
    def update_signal(self,s,title=None,body=None):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT closed FROM signals WHERE id=?',(s.id,)).fetchone()
            if not row or row[0] is not None: return
            c.execute('UPDATE signals SET body=?,closed=? WHERE id=?',(s.model_dump_json(),s.closed,s.id))
            if title: self._event(c,s,title,body or s.recommendation)
    def register(self,d):
        with self.connect() as c:
            c.execute('INSERT OR REPLACE INTO devices VALUES (?,?,?)',(d.token.lower(),d.environment,time.time()))
    def remove_device(self,token):
        with self.connect() as c:
            c.execute('DELETE FROM devices WHERE token=?',(token,))
            c.execute('DELETE FROM deliveries WHERE device=?',(token,))
    def cleanup(self):
        with self.connect() as c:
            c.execute('DELETE FROM tokens WHERE updated<?',(time.time()-86400,))
            c.execute('DELETE FROM devices WHERE updated<?',(time.time()-90*86400,))
            c.execute('DELETE FROM deliveries WHERE event IN (SELECT id FROM events WHERE created<?)',(time.time()-7*86400,))
            c.execute('DELETE FROM events WHERE created<?',(time.time()-7*86400,))
