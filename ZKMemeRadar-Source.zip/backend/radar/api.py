import asyncio, fcntl, hmac, logging, os, secrets, time
from contextlib import asynccontextmanager, suppress
from collections import defaultdict, deque
from fastapi import FastAPI, Depends, HTTPException, Header, Request, Response
from pydantic import BaseModel, Field
from .store import Store
from .push import Push
from .scanner import Scanner
from .models import Device

logging.basicConfig(level=os.getenv('LOG_LEVEL','INFO'),format='%(asctime)s %(levelname)s %(name)s %(message)s')
logging.getLogger('httpx').setLevel(logging.WARNING)
store=Store(os.getenv('DATABASE_PATH','data/radar.sqlite3'))
attempts=defaultdict(deque)

@asynccontextmanager
async def lifespan(app):
    code=os.getenv('PAIRING_CODE','')
    if len(code)<16: raise RuntimeError('PAIRING_CODE must contain at least 16 characters. Generate with openssl rand -hex 16.')
    # Single persistent local volume; refuse a second scanner process.
    lock=open(store.path+'.lock','w')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if not store.get_meta('accessToken'): store.meta('accessToken',secrets.token_urlsafe(48))
    scanner=Scanner(store,Push(store)); task=asyncio.create_task(scanner.run())
    try: yield
    finally:
        task.cancel()
        with suppress(asyncio.CancelledError): await task
        lock.close()

app=FastAPI(title='ZK Meme Radar',version='1.0.0',lifespan=lifespan,docs_url=None,redoc_url=None)

@app.middleware('http')
async def secure_response(request:Request,call_next):
    try: size=int(request.headers.get('content-length','0') or 0)
    except ValueError: return Response(status_code=400)
    if size>4096: return Response(status_code=413)
    r=await call_next(request); r.headers['Cache-Control']='no-store'; r.headers['X-Content-Type-Options']='nosniff'
    return r

def auth(authorization:str=Header(default='')):
    expected=store.get_meta('accessToken','')
    if not expected or not hmac.compare_digest(authorization,'Bearer '+expected): raise HTTPException(401,'Pair this device first')

class PairRequest(BaseModel): code:str=Field(min_length=16,max_length=256)
@app.post('/v1/pair')
def pair(body:PairRequest,request:Request):
    # Global + peer limits also protect against spoofed forwarding headers.
    now=time.time(); peer=request.client.host if request.client else 'unknown'
    for key in ['global',peer]:
        q=attempts[key]
        while q and q[0]<now-60: q.popleft()
        if len(q)>=(30 if key=='global' else 5): raise HTTPException(429,'Try again later')
        q.append(now)
    if not hmac.compare_digest(body.code,os.getenv('PAIRING_CODE','')): raise HTTPException(401,'Incorrect pairing code')
    token=store.get_meta('accessToken')
    if not token: raise HTTPException(503,'Starting')
    return {'token':token}

@app.get('/healthz')
def healthz():
    h=store.get_meta('health',{})
    if time.time()-h.get('heartbeat',0)>90: raise HTTPException(503,'Scanner heartbeat delayed')
    return {'status':'ok'}

@app.get('/v1/state',dependencies=[Depends(auth)])
def state():
    now=time.time(); h=store.get_meta('health',{}); discovery=store.get_meta('discovery',{})
    tokens=sorted(store.tokens(),key=lambda t:t.scores.get('Overall') or 0,reverse=True)
    fresh=[t for t in tokens if now-t.fetched<360]
    potential=[t for t in fresh if (t.scores.get('Overall') or 0)>=60]
    active=store.active()
    with store.connect() as c: devices=c.execute('SELECT COUNT(*) FROM devices').fetchone()[0]
    return {'serverTime':now,'live':now-h.get('heartbeat',0)<45 and now-discovery.get('at',0)<660 and discovery.get('ok',False),
        'scanned':len(fresh),'potential':len(potential),'rejected':len(fresh)-len(potential),'active':active,'candidates':tokens[:60],
        'pushConfigured':h.get('pushConfigured',False),'registeredDevices':devices,'lastScan':discovery.get('at'),
        'providers':[{'name':k,'ok':v.get('ok',False),'at':v.get('at',0)} for k,v in h.get('providers',{}).items()]}

@app.get('/v1/history',dependencies=[Depends(auth)])
def history(): return store.history()
@app.get('/v1/signals/{id}',dependencies=[Depends(auth)])
def signal(id:str):
    s=store.signal(id)
    if not s: raise HTTPException(404,'Signal not found')
    return s
@app.post('/v1/devices',dependencies=[Depends(auth)],status_code=204)
def register(device:Device): store.register(device); return Response(status_code=204)
@app.delete('/v1/devices/{token}',dependencies=[Depends(auth)],status_code=204)
def unregister(token:str): store.remove_device(token); return Response(status_code=204)
