import asyncio, logging, time
from .providers import HTTP,Dex,Gecko,SecurityProvider,dedup
from .engine import evaluate,activate,monitor

log=logging.getLogger(__name__)
class Scanner:
    def __init__(self,store,push):
        self.store=store; self.push=push; self.http=HTTP(); self.dex=Dex(self.http); self.gecko=Gecko(self.http); self.security=SecurityProvider(self.http)
        self.next_discovery=0; self.next_watch=0; self.started=time.time()
    async def quote(self,t):
        for provider in [self.dex,self.gecko]:
            try:
                q=await provider.quote(t)
                if q: return q
            except Exception: continue
        return None
    async def enrich(self,t,force=False):
        previous=self.store.token(t.id)
        if previous and previous.pool!=t.pool:
            # Preserve pool pin for active lifecycle; warm up the new pool afterward.
            active=self.store.active()
            if active and active.token.id==t.id: return previous
        if previous and previous.pool==t.pool and abs(t.price/previous.price-1)>.25:
            try:
                confirmation=await self.gecko.quote(t)
                if not confirmation or abs(t.price/confirmation.price-1)>.10:
                    t=evaluate(t,previous); t.eligible=False; t.status='WAIT'; t.risks.append('Large price change could not be independently confirmed')
                    self.store.save_token(t); return t
            except Exception:
                t=evaluate(t,previous); t.eligible=False; t.status='WAIT'; t.risks.append('Price confirmation unavailable')
                self.store.save_token(t); return t
        t=evaluate(t,previous)
        if force or t.scores['Overall']>=60 and time.time()-t.security.checked>120:
            t.security=await self.security.check(t)
            t=evaluate(t,t)
        self.store.save_token(t)
        return t
    async def active_tick(self):
        s=self.store.active()
        if not s: return
        q=await self.quote(s.token)
        if q:
            # Suspicious price jumps must agree with an independent provider.
            if abs(q.price/s.token.price-1)>.45:
                try:
                    other=await self.gecko.quote(s.token)
                    if not other or abs(q.price/other.price-1)>.1: q=None
                except Exception: q=None
            if q: q=await self.enrich(q,force=time.time()-s.token.security.checked>120)
        s,event=monitor(s,q)
        self.store.update_signal(s,event,f'{s.token.symbol} · {s.recommendation}')
    async def discovery_loop(self):
        while True:
            try:
                results=await self.dex.discover()
                try: results+=await self.gecko.discover()
                except Exception: pass
                results=dedup(results)
                for t in results:
                    # Discovery does not spend security budget. Candidates get priority later.
                    old=self.store.token(t.id)
                    if old and old.pool!=t.pool and self.store.active() and self.store.active().token.id==t.id: continue
                    self.store.save_token(evaluate(t,old))
                self.store.meta('discovery',{'at':time.time(),'count':len(results),'ok':bool(results)})
                self.store.cleanup()
            except Exception: log.exception('Discovery cycle failed')
            await asyncio.sleep(300)
    async def watch_loop(self):
        while True:
            try:
                ranked=sorted(self.store.tokens(),key=lambda t:t.scores.get('Overall') or 0,reverse=True)
                active=self.store.active()
                for t in ranked[:12]:
                    if active and active.token.id==t.id: continue
                    q=await self.quote(t)
                    if not q: continue
                    q=await self.enrich(q)
                    history=self.store.history()
                    cooling=any(s.token.id==q.id and time.time()-(s.closed or 0)<1800 for s in history)
                    globally_cooling=bool(history and time.time()-(history[0].closed or 0)<60)
                    if q.eligible and not cooling and not globally_cooling and not self.store.active():
                        self.store.activate(activate(q))
                self.store.meta('watchAt',time.time())
            except Exception: log.exception('Candidate cycle failed')
            await asyncio.sleep(30)
    async def run(self):
        discovery=asyncio.create_task(self.discovery_loop()); watch=asyncio.create_task(self.watch_loop())
        try:
            while True:
                start=time.time()
                try:
                    await self.active_tick()
                    await self.push.flush()
                    self.store.meta('health',{'heartbeat':time.time(),'started':self.started,'providers':self.http.health,'pushConfigured':self.push.ready})
                except Exception: log.exception('Active cycle failed')
                await asyncio.sleep(max(1,10-(time.time()-start)))
        finally:
            discovery.cancel(); watch.cancel()
            await asyncio.gather(discovery,watch,return_exceptions=True)
            await self.http.close(); await self.push.close()
