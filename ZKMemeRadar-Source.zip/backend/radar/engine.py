"""Versioned deterministic observation model, not calibrated trade probabilities."""
import math, statistics, time, uuid
from .models import Token, Point, Signal

MODEL_VERSION='1.0.0'
UNAVAILABLE=['Unique buyers / sellers','Buy / sell dollar volume','Whale and profitable-wallet flows','Developer wallet selling','Bundled / coordinated / sniper supply','Social mention growth and bot detection','Token creation time (pool age is available)','Cross-pool total liquidity','Rug-pull probability (not statistically calibrated)']

def clamp(v): return round(max(0,min(100,v)),1)

def evaluate(t:Token, previous:Token|None, now=None):
    now=now or time.time()
    # Pool migrations reset history. Never splice incompatible price histories.
    points=previous.points[:] if previous and previous.pool==t.pool else []
    if not points or t.fetched-points[-1].time>=8:
        points.append(Point(time=t.fetched,price=t.price,liquidity=t.liquidity,volume5=t.volume5,buys=t.buys,sells=t.sells))
    t.points=[p for p in points if p.time>=now-7200][-480:]
    t.security=previous.security if previous else t.security
    t.reasons=[]; t.risks=[]; t.unavailable=UNAVAILABLE[:]; t.eligible=False
    sec=t.security
    security_fresh=sec.complete and now-sec.checked<180
    t.risks.extend(sec.warnings)
    if not security_fresh: t.risks.append('Critical security checks missing or stale')
    if sec.danger: t.risks.append('Security gate failed')
    cap=t.marketCap or t.fdv
    ratio=t.liquidity/cap if cap and cap>0 else None
    liq=clamp(45+20*math.log10(max(1,t.liquidity)/100000)+(min(ratio,0.3)*100 if ratio else 0))
    activity=t.buys+t.sells; buy_share=t.buys/max(1,activity)
    volume_ratio=t.volume5/max(1,t.volumeHour/12)
    vol=clamp(30+min(volume_ratio,3)*15+min(activity,150)/6+max(0,buy_share-.5)*50)
    change=t.change5 or 0
    momentum=clamp(45+change*3+max(0,buy_share-.5)*60)
    if change>20: momentum=clamp(momentum-(change-20)*3); t.risks.append('Vertical move / overextension')
    history=t.points
    enough=len(history)>=10 and history[-1].time-history[0].time>=300
    entry=0.; setup=False
    if enough:
        old=[p for p in history if now-900<=p.time<now-90]
        recent=[p for p in history if p.time>=now-90]
        if len(old)>=5 and len(recent)>=3:
            resistance=max(p.price for p in old)
            retested=any(
                p.price>resistance*1.004 and any(
                    resistance*.992<=q.price<=resistance*1.01 and q.price<p.price*.998
                    for q in recent[i+1:-1])
                for i,p in enumerate(recent[:-2]))
            recovering=history[-1].price>history[-2].price
            setup=retested and recovering and resistance<=t.price<=resistance*1.018
            entry=92 if setup else 55 if abs(t.price/resistance-1)<.025 else 25
            t.entryLow=resistance*.998; t.entryHigh=resistance*1.018
            returns=[abs(history[i].price/history[i-1].price-1) for i in range(1,len(history))]
            width=max(.025,min(.08,statistics.median(returns)*5))
            t.stop=min(t.entryLow*.985,t.price*(1-width))
            risk=t.price-t.stop
            t.target1=t.price+2*risk; t.target2=t.price+3*risk
            t.holdSeconds=300 if width>=.06 else 900 if width>=.035 else 1800
            if setup: t.reasons.append('Sampled breakout + retest + recovery confirmed')
        if t.liquidity<history[0].liquidity*.8: t.risks.append('Liquidity down more than 20%'); setup=False
        if t.volume5>history[-2].volume5*1.1: t.reasons.append('Rolling 5-minute volume increasing')
        if t.buys>history[-2].buys: t.reasons.append('Buy transaction count increasing (not unique buyers)')
    else: t.risks.append('Warming up: at least 5 minutes of observations required')
    if volume_ratio>=1.5: t.reasons.append('Volume above hourly baseline')
    if t.liquidity>=100000: t.reasons.append('Selected pool liquidity above $100k')
    if buy_share>=.58: t.reasons.append('Buy transactions outweigh sells')
    if t.created is None: t.risks.append('Pool age unavailable')
    elif now-t.created<3600: t.risks.append('Pool younger than one hour')
    wash=t.volume5/max(t.liquidity,1)>3
    if wash: t.risks.append('Abnormal volume-to-liquidity ratio; possible wash activity')
    safety=clamp(100-sec.risk) if security_fresh and sec.risk is not None else None
    wallet=clamp(100-sec.concentration*100) if security_fresh and sec.concentration is not None else None
    # Missing social/flow evidence earns zero contribution, never renormalized upward.
    overall=clamp(.22*momentum+.16*liq+.20*vol+.10*(wallet or 0)+.16*(safety or 0)+.16*entry)
    t.scores={'Momentum':momentum,'Liquidity':liq,'Volume':vol,'Wallet':wallet,'Safety':safety,'Social':None,'Entry Quality':entry,'Rug Risk':sec.risk if security_fresh else None,'Overall':overall}
    t.eligible=bool(setup and security_fresh and not sec.danger and overall>=78 and t.liquidity>=100000 and ratio is not None and ratio>=.03 and t.created and now-t.created>=1800 and 30<=activity and buy_share>=.58 and 1.4<=volume_ratio<=8 and 0<change<=18 and not wash and now-t.fetched<45 and t.stop and t.target2)
    t.scores['Risk']=clamp(.55*(sec.risk if security_fresh and sec.risk is not None else 100)+.25*(100-liq)+.20*(100-entry))
    def observed_change(seconds):
        older=[p for p in t.points if p.time<=now-seconds]
        p=older[-1] if older else None
        return (t.price/p.price-1)*100 if p and now-seconds-p.time<=45 else None
    t.metrics={'Observed 1m change':observed_change(60),'Observed 15m change':observed_change(900),'Buy transaction share':buy_share*100,'Transactions per minute':activity/5,'Volume versus hourly baseline':volume_ratio,'Liquidity / cap percent':ratio*100 if ratio is not None else None,'Observed liquidity change percent':(t.liquidity/t.points[0].liquidity-1)*100 if len(t.points)>1 and t.points[0].liquidity>0 else None}
    t.status='ENTRY APPROACHING' if setup else 'WATCHING' if enough else 'WAIT'
    if sec.danger: t.status='RUG/DANGER'
    return t

def activate(t,now=None):
    now=now or time.time()
    return Signal(id=str(uuid.uuid4()),token=t,opened=now,expires=now+t.holdSeconds,initialExpires=now+t.holdSeconds,entry=t.price,entryLow=t.entryLow,entryHigh=t.entryHigh,reasons=t.reasons[:],stop=t.stop,target1=t.target1,target2=t.target2,confidence=t.scores['Overall'],lastGood=t.fetched)

def monitor(s:Signal,t:Token|None,now=None):
    """Returns (state,event title). Caller commits state and notification atomically."""
    now=now or time.time(); event=None
    if s.closed: return s,None
    def close(reason,price,title):
        s.closed=now; s.closeReason=reason; s.status='CLOSED — '+reason
        s.exit=price; s.recommendation='EXIT NOW' if price is not None else 'EXIT — DATA UNAVAILABLE'
        return s,title
    if t is None or now-t.fetched>60:
        if now-s.lastGood>=120: return close('DATA UNAVAILABLE',None,'MONITORING LOST — EXIT')
        if now>=s.expires: return close('HOLD EXPIRED',None,'SIGNAL EXPIRED')
        s.recommendation='DATA DELAYED — DO NOT ENTER'
        return s,None
    if t.pool!=s.token.pool: return close('POOL CHANGED',None,'SIGNAL INVALIDATED')
    previous=s.token
    s.token=t; s.lastGood=t.fetched
    gain=(t.price/s.entry-1)*100
    s.maxGain=max(s.maxGain,gain); s.maxLoss=min(s.maxLoss,gain)
    if t.security.danger or (t.security.risk is not None and previous.security.risk is not None and t.security.risk-previous.security.risk>=20): return close('RUG WARNING',t.price,'RUG WARNING — EXIT')
    if t.liquidity<previous.liquidity*.65 or t.liquidity<50000: return close('LIQUIDITY WARNING',t.price,'LIQUIDITY WARNING — EXIT')
    if t.price<=s.stop: return close('INVALIDATED',t.price,'EXIT SIGNAL')
    if t.price>=s.target2: return close('PROFIT TARGET',t.price,'TARGET HIT — EXIT')
    if now>=s.expires: return close('HOLD EXPIRED',t.price,'SIGNAL EXPIRED')
    if not t.security.complete or now-t.security.checked>300: return close('SECURITY DATA LOST',t.price,'SECURITY MONITORING LOST')
    if t.sells>max(15,t.buys*1.8) and (t.change5 or 0)<-3: return close('MOMENTUM LOST',t.price,'MOMENTUM LOST — EXIT')
    if not s.target1Hit and t.price>=s.target1:
        s.target1Hit=True; s.stop=max(s.stop,s.entry*1.003)
        s.recommendation='TAKE 50% PROFIT · INVALIDATION RAISED'; event='TAKE PROFIT'
    elif t.buys< t.sells and now-s.opened>60:
        new_expiry=min(s.expires,now+120)
        if s.recommendation!='MOMENTUM WEAKENING': event='MOMENTUM WEAKENING'
        s.expires=new_expiry; s.recommendation='MOMENTUM WEAKENING'
    else: s.recommendation='HOLD' if now-s.opened>30 else 'BUY ZONE'
    return s,event
