"""Synthetic fixtures live only in tests. Production starts empty."""
import asyncio, json, time, concurrent.futures
from copy import deepcopy
import pytest
from radar.models import Token,Security,Point,Device
from radar.store import Store
from radar.engine import evaluate,activate,monitor
from radar.providers import dex_token,dedup,Gecko,SecurityProvider

NOW=2_000_000_000.
def candidate(now=NOW):
    points=[Point(time=now-360+i*30,price=p,liquidity=400000,volume5=22000,buys=65,sells=25) for i,p in enumerate([.96,.97,.98,.99,1.,.99,.995,1.,.999,1.009,1.004,1.008])]
    return Token(id='base:0x'+'1'*40,chain='base',address='0x'+'1'*40,pool='0x'+'2'*40,name='Synthetic Test Fixture',symbol='TEST',price=1.01,liquidity=400000,marketCap=2000000,fdv=2000000,created=now-7200,volume5=40000,volumeHour=160000,buys=100,sells=30,change5=6,changeHour=12,fetched=now,source='TEST ONLY',points=points,security=Security(source='TEST ONLY',checked=now,complete=True,danger=False,risk=25,concentration=.2))

def ready(now=NOW):
    t=candidate(now); return evaluate(t,t,now)

def test_selective_entry():
    t=ready()
    assert t.eligible, t.model_dump()
    assert t.entryLow<t.price<t.entryHigh
    assert t.stop<t.price<t.target1<t.target2
    assert t.scores['Social'] is None
    assert t.scores['Overall']>=78

def test_missing_security_blocks():
    t=candidate(); t.security=Security()
    assert not evaluate(t,t,NOW).eligible

def test_old_security_blocks():
    t=candidate(); t.security.checked=NOW-181
    assert not evaluate(t,t,NOW).eligible

@pytest.mark.parametrize('field,value',[('liquidity',9000),('change5',45),('buys',2),('marketCap',1000000000),('created',NOW-100),('volume5',2000000)])
def test_gate_rejects(field,value):
    t=candidate(); setattr(t,field,value)
    assert not evaluate(t,t,NOW).eligible

def test_warmup_and_pool_migration():
    t=candidate(); p=t.model_copy(deep=True); p.pool='different'
    assert not evaluate(t,p,NOW).eligible
    assert len(t.points)==1

def test_database_lock_is_atomic_and_restart_safe(tmp_path):
    path=str(tmp_path/'db.sqlite'); store=Store(path)
    store.register(Device(token='a'*64,environment='production'))
    signals=[activate(ready(),NOW) for _ in range(12)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        results=list(pool.map(lambda s: Store(path).activate(s),signals))
    assert sum(results)==1
    restart=Store(path); active=restart.active()
    assert active and active.expires==NOW+active.token.holdSeconds
    with restart.connect() as c:
        assert c.execute('SELECT COUNT(*) FROM events').fetchone()[0]==1
        assert c.execute('SELECT COUNT(*) FROM deliveries').fetchone()[0]==1
    active.closed=NOW+60; active.closeReason='TEST'; restart.update_signal(active,'EXIT')
    assert restart.active() is None
    assert len(restart.history())==1
    assert restart.activate(activate(ready(),NOW+61))

def test_targets_and_trailing_invalidation():
    s=activate(ready(),NOW); q=s.token.model_copy(deep=True); q.price=s.target1; q.fetched=NOW+10
    s,event=monitor(s,q,NOW+10)
    assert event=='TAKE PROFIT' and s.target1Hit and s.stop>s.entry
    s,event=monitor(s,q,NOW+20)
    assert event is None
    q.price=s.target2; q.fetched=NOW+30
    s,event=monitor(s,q,NOW+30)
    assert s.closed and s.closeReason=='PROFIT TARGET'

@pytest.mark.parametrize('case,reason',[('liquidity','LIQUIDITY WARNING'),('danger','RUG WARNING'),('stop','INVALIDATED'),('momentum','MOMENTUM LOST'),('security','SECURITY DATA LOST')])
def test_exit_reasons(case,reason):
    s=activate(ready(),NOW); q=s.token.model_copy(deep=True); q.fetched=NOW+20
    if case=='liquidity': q.liquidity=100
    if case=='danger': q.security.danger=True
    if case=='stop': q.price=s.stop*.9
    if case=='momentum': q.buys=5; q.sells=100; q.change5=-8
    if case=='security': q.security=Security()
    s,event=monitor(s,q,NOW+20)
    assert s.closed and s.closeReason==reason

def test_data_outage_does_not_invent_exit():
    s=activate(ready(),NOW)
    s,_=monitor(s,None,NOW+60)
    assert s.closed is None and s.recommendation=='DATA DELAYED — DO NOT ENTER'
    s,event=monitor(s,None,NOW+121)
    assert s.closed and s.exit is None and event

def test_timer_expires_after_restart():
    s=activate(ready(),NOW); q=s.token.model_copy(deep=True); q.fetched=s.expires+1; q.security.checked=q.fetched
    out,event=monitor(s,q,q.fetched)
    assert out.closeReason=='HOLD EXPIRED'

def test_dynamic_timer_shortens_only():
    s=activate(ready(),NOW); initial=s.expires; q=s.token.model_copy(deep=True); q.fetched=NOW+100; q.buys=30; q.sells=35
    s,event=monitor(s,q,NOW+100)
    assert NOW+100<s.expires<initial and event=='MOMENTUM WEAKENING'

def test_pool_change_exits_unpriced():
    s=activate(ready(),NOW); q=s.token.model_copy(deep=True); q.pool='different'; q.fetched=NOW+10
    s,_=monitor(s,q,NOW+10)
    assert s.closeReason=='POOL CHANGED' and s.exit is None

def test_invalid_price_and_dedup():
    row={'chainId':'base','baseToken':{'address':'0x'+'1'*40,'symbol':'TEST'},'pairAddress':'0x'+'2'*40,'priceUsd':'NaN','liquidity':{'usd':200000}}
    assert dex_token(row) is None
    row['priceUsd']='1.0'; t=dex_token(row)
    bigger=t.model_copy(update={'liquidity':400000})
    assert dedup([t,bigger])==[bigger]

@pytest.mark.asyncio
async def test_goplus_missing_fields_fail_closed():
    class FakeHTTP:
        async def request(self,*args,**kwargs): return {'result':{'0x'+'1'*40:{'is_honeypot':'0'}}}
    s=await SecurityProvider(FakeHTTP()).check(candidate())
    assert not s.complete

@pytest.mark.asyncio
async def test_solana_mint_authority_is_danger():
    class FakeHTTP:
        async def request(self,*args,**kwargs):
            method=kwargs['json']['method']
            value={'owner':'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA','data':{'parsed':{'info':{'supply':'1000','mintAuthority':'enabled','freezeAuthority':None}}}} if method=='getAccountInfo' else [{'amount':'100'}]
            return {'result':{'value':value}}
    t=candidate(); t.chain='solana'; t.address='1'*32
    s=await SecurityProvider(FakeHTTP()).check(t)
    assert s.complete and s.danger

@pytest.mark.asyncio
async def test_push_durable_retry_and_obsolete_entry(tmp_path,monkeypatch):
    from radar.push import Push
    st=Store(str(tmp_path/'db')); st.register(Device(token='a'*64,environment='production'))
    real=time.time(); s=activate(ready(real),real); st.activate(s)
    p=Push(st)
    for key in ['APNS_KEY_ID','APNS_TEAM_ID','APNS_KEY_PATH','APNS_TOPIC']: monkeypatch.setenv(key,'test')
    p.auth=lambda:'test'
    class Reply:
        status_code=503; content=b'{}'
        def json(self): return {'reason':'ServiceUnavailable'}
    class Client:
        async def post(self,*a,**kw): return Reply()
        async def aclose(self): pass
    await p.client.aclose(); p.client=Client()
    await p.flush()
    with st.connect() as c:
        row=c.execute('SELECT * FROM deliveries').fetchone(); assert row['attempts']==1 and row['sent'] is None
    s.closed=real+1; st.update_signal(s)
    with st.connect() as c: c.execute('UPDATE deliveries SET next=0')
    await p.flush()
    with st.connect() as c: assert c.execute('SELECT sent FROM deliveries').fetchone()[0] is not None
    await p.close()

def test_breakout_requires_later_retest():
    t=candidate()
    # Monotonic ascent cannot use one point as both breakout and retest.
    for i,p in enumerate(t.points[-3:]): p.price=1.004+i*.002
    t.price=1.012
    assert not evaluate(t,t,NOW).eligible

@pytest.mark.asyncio
async def test_invalid_holder_fractions_are_unknown():
    class FakeHTTP:
        async def request(self,*args,**kwargs):
            flags=['is_honeypot','is_mintable','is_blacklisted','is_proxy','can_take_back_ownership','owner_change_balance','cannot_sell_all','transfer_pausable','slippage_modifiable','personal_slippage_modifiable','hidden_owner','selfdestruct','cannot_buy','anti_whale_modifiable','trading_cooldown']
            data={k:'0' for k in flags}; data.update(is_open_source='1',buy_tax='0',sell_tax='0',holders=[{'percent':'bad'}])
            return {'result':{'0x'+'1'*40:data}}
    s=await SecurityProvider(FakeHTTP()).check(candidate())
    assert not s.complete and s.concentration is None and s.risk is None
