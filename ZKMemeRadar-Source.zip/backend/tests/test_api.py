from fastapi.testclient import TestClient
from radar.models import Device
from radar.store import Store
import pytest

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('DATABASE_PATH',str(tmp_path/'initial.sqlite'))
    monkeypatch.setenv('PAIRING_CODE','a-secure-test-pairing-code')
    from radar import api
    st=Store(str(tmp_path/'test.sqlite')); st.meta('accessToken','test-access')
    monkeypatch.setattr(api,'store',st); api.attempts.clear()
    # No lifespan here: deterministic API tests must not call market providers.
    return TestClient(api.app),st

def test_authentication_and_empty_state(client):
    c,st=client
    assert c.get('/v1/state').status_code==401
    assert c.post('/v1/pair',json={'code':'wrong-pairing-code'}).status_code==401
    r=c.post('/v1/pair',json={'code':'a-secure-test-pairing-code'})
    assert r.json()['token']=='test-access'
    r=c.get('/v1/state',headers={'Authorization':'Bearer test-access'})
    assert r.status_code==200 and r.json()['active'] is None
    assert r.json()['scanned']==0 and not r.json()['live']
    assert r.headers['cache-control']=='no-store'

def test_device_auth_and_validation(client):
    c,st=client; h={'Authorization':'Bearer test-access'}
    assert c.post('/v1/devices',json={'token':'a'*64,'environment':'production'}).status_code==401
    assert c.post('/v1/devices',headers=h,json={'token':'bad','environment':'production'}).status_code==422
    assert c.post('/v1/devices',headers=h,json={'token':'a'*64,'environment':'production'}).status_code==204
    assert c.get('/v1/state',headers=h).json()['registeredDevices']==1
    assert c.delete('/v1/devices/'+'a'*64,headers=h).status_code==204
    assert c.get('/v1/state',headers=h).json()['registeredDevices']==0

def test_pairing_rate_limit(client):
    c,_=client
    for _ in range(5): assert c.post('/v1/pair',json={'code':'wrong-pairing-code'}).status_code==401
    assert c.post('/v1/pair',json={'code':'wrong-pairing-code'}).status_code==429

def test_missing_signal_and_expired_health(client):
    c,_=client
    assert c.get('/v1/signals/missing',headers={'Authorization':'Bearer test-access'}).status_code==404
    assert c.get('/healthz').status_code==503
